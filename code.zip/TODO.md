# TODO — Barbearia

- [ ] **Cópia funcional da base:** preservar autenticação, login, saída, recuperação de conta, cadastro de usuários e validações equivalentes ao sistema original.
- [ ] **Gestão de barbeiros:** permitir cadastrar, editar, visualizar e organizar barbeiros, com perfis públicos e agendamento direcionado ao profissional escolhido.
- [ ] **Serviços e agenda:** manter cadastro de serviços de corte, barba e cuidados masculinos, horários individuais, disponibilidade e bloqueios para folgas, pausas e indisponibilidades.
- [ ] **Agendamento público:** permitir escolher serviço, data e horário disponíveis mantendo o barbeiro previamente selecionado, com confirmação coerente com a barbearia.
- [ ] **Experiência de barbearia:** aplicar rebranding completo, textos e exemplos de corte/barba, identidade masculina sofisticada e layout responsivo para celular.
- [ ] **Entrega técnica:** manter o manifesto `manus-routes.json`, checagem TypeScript, build e integração com o banco configurado do projeto.
- [ ] **Sorteios administrativos:** permitir ao administrador ativar um sorteio, definir data, horário e serviço, listar inscrições, puxar um vencedor aleatório e finalizar o sorteio com segurança.
- [ ] **Inscrição pública no sorteio:** exibir o sorteio ativo fixado no site, cadastrar nome e telefone, atribuir número, oferecer um número extra por compartilhamento e permitir consultar números pelo telefone.
- [ ] **Histórico público de sorteios:** disponibilizar a página `/sorteios` com sorteios realizados, serviço e vencedor exibido somente com nome abreviado, sem sobrenome completo.

import crypto from 'crypto';
import mysql from 'mysql2/promise';

const hashPassword = (password) => crypto.createHash('sha256').update(password).digest('hex');

async function main() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  // Verificar admin existente
  const [admins] = await connection.execute('SELECT * FROM admins WHERE username = ?', ['navalha']);
  console.log('Admin encontrado:', admins);
  
  // Verificar hash da senha
  const expectedHash = hashPassword('1889@gByu/1m');
  console.log('Hash esperado:', expectedHash);
  
  if (admins.length > 0) {
    console.log('Hash no banco:', admins[0].passwordHash);
    console.log('Hashes iguais:', admins[0].passwordHash === expectedHash);
  }
  
  await connection.end();
}

main().catch(console.error);

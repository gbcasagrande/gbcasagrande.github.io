import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Agenda from "./pages/Agenda";
import PostDetail from "./pages/PostDetail";
import ArticlesPage from "./pages/ArticlesPage";
import ProfessionalProfile from "./pages/ProfessionalProfile";
import RafflesPage from "./pages/RafflesPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/artigos" component={ArticlesPage} />
      <Route path="/post/:id" component={PostDetail} />
      <Route path="/barbeiro/:id" component={ProfessionalProfile} />
      <Route path="/sorteios" component={RafflesPage} />
      <Route path="/sorteios/:id" component={RafflesPage} />
      <Route path="/login" component={Login} />
      <Route path="/agenda" component={Agenda} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable={false}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

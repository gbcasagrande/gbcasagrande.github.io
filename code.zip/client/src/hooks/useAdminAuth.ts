import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useEffect } from "react";

export function useAdminAuth(requireAuth = true) {
  const [, setLocation] = useLocation();
  const { data: admin, isLoading, error } = trpc.adminAuth.me.useQuery();
  const logoutMutation = trpc.adminAuth.logout.useMutation({
    onSuccess: () => {
      setLocation("/login");
    },
  });

  useEffect(() => {
    if (!isLoading && !admin && requireAuth) {
      setLocation("/login");
    }
  }, [admin, isLoading, requireAuth, setLocation]);

  return {
    admin,
    isLoading,
    isAuthenticated: !!admin,
    error,
    logout: () => logoutMutation.mutate(),
    isLoggingOut: logoutMutation.isPending,
  };
}

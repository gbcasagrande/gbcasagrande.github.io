export const CLINIC_WHATSAPP_NUMBER = "5554991399264";

export type WhatsAppProfessional = {
  id: number;
  name: string;
  phone?: string | null;
};

export function buildWhatsAppUrl(message: string, phone = CLINIC_WHATSAPP_NUMBER) {
  const normalizedPhone = phone.replace(/\D/g, "");
  return `https://wa.me/${normalizedPhone}?text=${encodeURIComponent(message)}`;
}

export function normalizeBrazilianPhone(phone: string): string | null {
  const digits = phone.replace(/\D/g, "");
  if (!digits) return null;

  const withCountryCode = digits.startsWith("55") ? digits : `55${digits}`;
  const nationalNumber = withCountryCode.slice(2);

  if (nationalNumber.length < 10 || nationalNumber.length > 11) return null;
  return withCountryCode;
}

export function resolveProfessionalWhatsAppTarget(professionals: WhatsAppProfessional[], professionalId?: number | null) {
  const professional = professionalId == null ? undefined : professionals.find((item) => item.id === professionalId);
  return {
    professionalName: professional?.name ?? null,
    phone: professional?.phone ? normalizeBrazilianPhone(professional.phone) : null,
  };
}

export function formatCivilDateForWhatsApp(date: string) {
  const [year, month, day] = date.split("-");
  if (!year || !month || !day) return date;
  return `${day}/${month}/${year}`;
}

export function formatTimeForWhatsApp(time: string) {
  return time.slice(0, 5);
}

export function buildServiceBookingMessage(serviceName: string, appointmentDate?: string, appointmentTime?: string) {
  if (appointmentDate && appointmentTime) {
    return `Olá! Gostaria de agendar o serviço de ${serviceName} no dia ${formatCivilDateForWhatsApp(appointmentDate)}, às ${formatTimeForWhatsApp(appointmentTime)}, na Gb Barbearia. Vim pelo site.`;
  }
  return `Olá! Gostaria de agendar um serviço de ${serviceName} na Gb Barbearia. Vim pelo site.`;
}

type AppointmentMessageDetails = {
  clientName: string;
  serviceName: string;
  appointmentDate: string;
  appointmentTime: string;
  professionalName?: string | null;
};

function formatAppointmentDetails({ serviceName, appointmentDate, appointmentTime, professionalName }: Pick<AppointmentMessageDetails, "serviceName" | "appointmentDate" | "appointmentTime" | "professionalName">) {
  const professionalPart = professionalName ? ` com o barbeiro ${professionalName}` : "";
  return `${serviceName}${professionalPart} no dia ${formatCivilDateForWhatsApp(appointmentDate)}, às ${formatTimeForWhatsApp(appointmentTime)}`;
}

export function buildAppointmentConfirmationMessage({
  clientName,
  serviceName,
  appointmentDate,
  appointmentTime,
  professionalName,
}: AppointmentMessageDetails) {
  return `Olá, ${clientName}! Você tem um horário marcado para ${formatAppointmentDetails({ serviceName, appointmentDate, appointmentTime, professionalName })}. Posso confirmar?`;
}

export function buildAppointmentConfirmedMessage({
  clientName,
  serviceName,
  appointmentDate,
  appointmentTime,
  professionalName,
}: AppointmentMessageDetails) {
  return `Olá, ${clientName}! Seu horário para ${formatAppointmentDetails({ serviceName, appointmentDate, appointmentTime, professionalName })} foi confirmado. Até lá!`;
}

export function buildAppointmentRescheduledMessage({
  clientName,
  serviceName,
  appointmentDate,
  appointmentTime,
  professionalName,
}: AppointmentMessageDetails) {
  const professionalPart = professionalName ? ` O atendimento será realizado por ${professionalName}.` : "";
  return `Olá, ${clientName}! Seu horário para ${serviceName} foi alterado. O novo horário ficou para o dia ${formatCivilDateForWhatsApp(appointmentDate)}, às ${formatTimeForWhatsApp(appointmentTime)}.${professionalPart} Por favor, confirme o recebimento desta mensagem.`;
}

export function buildAppointmentCancelledMessage({
  clientName,
  serviceName,
  appointmentDate,
  appointmentTime,
  professionalName,
}: AppointmentMessageDetails) {
  return `Olá, ${clientName}! Informamos que seu horário para ${formatAppointmentDetails({ serviceName, appointmentDate, appointmentTime, professionalName })} foi cancelado. Entre em contato conosco caso queira escolher um novo horário.`;
}

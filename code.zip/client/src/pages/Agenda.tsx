import { useAdminAuth } from "@/hooks/useAdminAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { 
  Leaf,
  MessageCircle, 
  LogOut, 
  Plus, 
  Calendar as CalendarIcon, 
  Clock, 
  User, 
  UsersRound,
  Phone, 
  DollarSign,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Loader2,
  ArrowUpRight,
  Settings,
  BarChart3,
  Menu,
  X,
  Sparkles,
  Droplets,
  Heart,
  Activity,
  Shield,
  Zap,
  Snowflake,
  Sun,

  Flower2,
  Waves,
  HandHeart,
  Instagram,
  MapPin,
  Upload,
  Link2,
  History,
  Mail,
  Check,
  ExternalLink,
  Gift
} from "lucide-react";
import { useState, useMemo, useEffect } from "react";

import { toast } from "sonner";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths, isToday, startOfWeek, endOfWeek } from "date-fns";
import { ptBR } from "date-fns/locale";
import { SITE_CONTENT_DEFAULTS } from "@shared/siteContent";
import { DEFAULT_SERVICE_ICON, SERVICE_ICON_OPTIONS, getServicePromotionalPrice, serializeServiceBenefits } from "@shared/serviceCatalog";
import { getAppointmentStatusLabel } from "@shared/appointmentStatus";
import { filterAgendaAppointments } from "@shared/agendaFilters";
import { ADMIN_NAV_LAYOUT_CLASSES, getPendingBadgeLabel, getVisibleAdminNavItems, type AdminTab } from "@shared/adminNavigation";
import {
  buildAppointmentCancelledMessage,
  buildAppointmentConfirmedMessage,
  buildAppointmentConfirmationMessage,
  buildAppointmentRescheduledMessage,
  buildWhatsAppUrl,
  formatCivilDateForWhatsApp,
  formatTimeForWhatsApp,
  normalizeBrazilianPhone,
} from "@/lib/whatsapp";

type Appointment = {
  id: number;
  clientName: string;
  clientPhone: string;
  clientEmail: string | null;
  serviceName: string;
  serviceId: number | null;
  // Data retornada pelo banco no formato civil YYYY-MM-DD.
  appointmentDate: string;
  appointmentTime: string;
  price: string;
  status: "confirmado" | "cancelado" | "pendente";
  source?: "admin" | "public";
  notes: string | null;
  professionalId: number | null;
  professionalName?: string | null;
  reason?: string | null;
};

type Professional = {
  id: number;
  name: string;
  specialty: string | null;
  bio: string | null;
  phone: string | null;
  instagramUrl: string | null;
  profileSlug: string | null;
  coverUrl: string | null;
  verified: number;
  avatarUrl: string | null;
  active: number;
};

type Service = {
  id: number;
  name: string;
  description: string | null;
  defaultPrice: string;
  duration: number | null;
  benefits: string | null;
  icon: string;
  priceDisplayMode?: string;
  discountPercent?: number;
  promotionLabel?: string | null;
  sortOrder?: number;
  isFeatured?: number;
};

type AppointmentNotificationKind = "confirmed" | "rescheduled" | "cancelled";

const serviceIconByKey: Record<string, typeof Sparkles> = {
  Sparkles,
  Droplets,
  Heart,
  Activity,
  Shield,
  Zap,
  Snowflake,
  Sun,

  Flower2,
  Waves,
  HandHeart,
  Leaf,
};

function getAppointmentNotificationUrl(appointment: Appointment, kind: AppointmentNotificationKind) {
  const phone = normalizeBrazilianPhone(appointment.clientPhone);
  if (!phone) return null;

  const details = {
    clientName: appointment.clientName,
    serviceName: appointment.serviceName,
    appointmentDate: appointment.appointmentDate,
    appointmentTime: appointment.appointmentTime,
    professionalName: appointment.professionalName,
  };
  const message = kind === "confirmed"
    ? buildAppointmentConfirmedMessage(details)
    : kind === "rescheduled"
      ? buildAppointmentRescheduledMessage(details)
      : buildAppointmentCancelledMessage(details);

  return buildWhatsAppUrl(message, phone);
}

function getAppointmentConfirmationUrl(appointment: Appointment) {
  const phone = normalizeBrazilianPhone(appointment.clientPhone);
  if (!phone) return null;

  return buildWhatsAppUrl(
    buildAppointmentConfirmationMessage({
      clientName: appointment.clientName,
      serviceName: appointment.serviceName,
      appointmentDate: appointment.appointmentDate,
      appointmentTime: appointment.appointmentTime,
      professionalName: appointment.professionalName,
    }),
    phone,
  );
}

const statusConfig = {
  confirmado: { label: "Confirmado", color: "bg-green-100 text-green-800", icon: CheckCircle },
  cancelado: { label: "Cancelado", color: "bg-red-100 text-red-800", icon: XCircle },
  pendente: { label: "Pendente", color: "bg-yellow-100 text-yellow-800", icon: AlertCircle },
};

export default function Agenda() {
  const { admin, isLoading: authLoading, logout, isLoggingOut } = useAdminAuth();
  const isStrictAdmin = admin?.role === "admin";
  const visibleNavItems = useMemo(() => getVisibleAdminNavItems(admin?.role), [admin?.role]);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date>(() => new Date());
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>("agenda");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [appointmentToNotify, setAppointmentToNotify] = useState<{ appointment: Appointment; kind: AppointmentNotificationKind } | null>(null);
  const [appointmentSearch, setAppointmentSearch] = useState("");
  const [appointmentStatusFilter, setAppointmentStatusFilter] = useState<"all" | Appointment["status"]>("all");
  const [appointmentProfessionalFilter, setAppointmentProfessionalFilter] = useState("all");
  const [agendaView, setAgendaView] = useState<"month" | "week" | "day">("month");

  useEffect(() => {
    if (!isStrictAdmin && !["agenda", "pendentes", "relatorios", "meu-usuario"].includes(activeTab)) {
      setActiveTab("agenda");
    }
  }, [activeTab, isStrictAdmin]);

  useEffect(() => {
    if (!isSidebarOpen) return;

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setIsSidebarOpen(false);
    };

    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [isSidebarOpen]);

  // Form state
  const [formData, setFormData] = useState({
    clientName: "",
    clientPhone: "",
    clientEmail: "",
    serviceName: "",
    serviceId: null as number | null,
    appointmentDate: "",
    appointmentTime: "",
    price: "",
    status: "pendente" as "confirmado" | "cancelado" | "pendente",
    notes: "",
    professionalId: null as number | null,
  });

  const utils = trpc.useUtils();

  // Queries
  const { data: appointments = [], isLoading: appointmentsLoading } = trpc.appointments.list.useQuery(
    undefined,
    { enabled: !!admin }
  );
  const { data: services = [] } = trpc.services.list.useQuery();
  const { data: professionals = [] } = trpc.professionals.listActive.useQuery(undefined, { enabled: !!admin });
  const { data: pendingAppointments = [] } = trpc.appointments.pendingPublic.useQuery(undefined, {
    enabled: !!admin,
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
  });
  const pendingRequestsCount = pendingAppointments.length;
  const appointmentsWithProfessional = useMemo(() => appointments.map((appointment) => ({
    ...appointment,
    professionalName: professionals.find((professional) => professional.id === appointment.professionalId)?.name ?? null,
  })) as Appointment[], [appointments, professionals]);

  const filteredAppointments = useMemo(() => {
    return filterAgendaAppointments(appointmentsWithProfessional, {
      search: appointmentSearch,
      status: appointmentStatusFilter,
      professionalId: appointmentProfessionalFilter,
    });
  }, [appointmentProfessionalFilter, appointmentSearch, appointmentStatusFilter, appointmentsWithProfessional]);

  // Mutations
  const createAppointment = trpc.appointments.create.useMutation({
    onSuccess: () => {
      toast.success("Agendamento criado com sucesso!");
      utils.appointments.list.invalidate();
      setIsNewAppointmentOpen(false);
      resetForm();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateAppointment = trpc.appointments.update.useMutation({
    onSuccess: () => {
      toast.success("Agendamento atualizado!");
      utils.appointments.list.invalidate();
      setEditingAppointment(null);
      resetForm();
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteAppointment = trpc.appointments.delete.useMutation({
    onSuccess: () => {
      toast.success("Agendamento excluído!");
      utils.appointments.list.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateStatus = trpc.appointments.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Status atualizado!");
      utils.appointments.list.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const handleAppointmentStatusChange = (appointment: Appointment, status: Appointment["status"]) => {
    updateStatus.mutate(
      { id: appointment.id, status },
      {
        onSuccess: () => {
          if (status === "confirmado" || status === "cancelado") {
            setAppointmentToNotify({
              appointment: { ...appointment, status },
              kind: status === "confirmado" ? "confirmed" : "cancelled",
            });
          }
        },
      },
    );
  };

  const resetForm = () => {
    setFormData({
      clientName: "",
      clientPhone: "",
      clientEmail: "",
      serviceName: "",
      serviceId: null,
      appointmentDate: "",
      appointmentTime: "",
      price: "",
      status: "pendente",
      notes: "",
      professionalId: null,
    });
  };

  // Calendar data
  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const appointmentsByDate = useMemo(() => {
    const map = new Map<string, Appointment[]>();
    filteredAppointments.forEach((apt) => {
      // A coluna é date/string; nunca passar por new Date(), pois isso pode voltar um dia no fuso local.
      const dateStr = apt.appointmentDate;
      if (!map.has(dateStr)) {
        map.set(dateStr, []);
      }
      map.get(dateStr)!.push(apt as Appointment);
    });
    return map;
  }, [filteredAppointments]);

  const selectedDateAppointments = useMemo(() => {
    if (!selectedDate) return [];
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    return appointmentsByDate.get(dateStr) || [];
  }, [selectedDate, appointmentsByDate]);

  const upcomingAppointments = useMemo(() => {
    const now = new Date();
    const today = format(now, "yyyy-MM-dd");
    const currentTime = format(now, "HH:mm");

    return filteredAppointments
      .filter((appointment) => {
        if (appointment.status === "cancelado") return false;
        const appointmentTime = appointment.appointmentTime.slice(0, 5);
        return appointment.appointmentDate > today ||
          (appointment.appointmentDate === today && appointmentTime >= currentTime);
      })
      .sort((first, second) =>
        `${first.appointmentDate}T${first.appointmentTime}`.localeCompare(
          `${second.appointmentDate}T${second.appointmentTime}`,
        ),
      )
      ;
  }, [filteredAppointments]);

  const periodAppointments = useMemo(() => {
    const referenceDate = selectedDate ?? currentMonth;
    const periodStart = agendaView === "day"
      ? referenceDate
      : agendaView === "week"
        ? startOfWeek(referenceDate, { weekStartsOn: 1 })
        : startOfMonth(currentMonth);
    const periodEnd = agendaView === "day"
      ? referenceDate
      : agendaView === "week"
        ? endOfWeek(referenceDate, { weekStartsOn: 1 })
        : endOfMonth(currentMonth);
    const start = format(periodStart, "yyyy-MM-dd");
    const end = format(periodEnd, "yyyy-MM-dd");
    return filteredAppointments
      .filter((appointment) => appointment.appointmentDate >= start && appointment.appointmentDate <= end)
      .sort((first, second) => `${first.appointmentDate}T${first.appointmentTime}`.localeCompare(`${second.appointmentDate}T${second.appointmentTime}`));
  }, [agendaView, currentMonth, filteredAppointments, selectedDate]);

  // Service selection handler
  const handleServiceSelect = (serviceId: string) => {
    if (serviceId === "custom") {
      setFormData(prev => ({ ...prev, serviceId: null, serviceName: "", price: "" }));
    } else {
      const service = services.find(s => s.id === parseInt(serviceId));
      if (service) {
        setFormData(prev => ({
          ...prev,
          serviceId: service.id,
          serviceName: service.name,
          price: getServicePromotionalPrice(service.defaultPrice, service.discountPercent).toFixed(2),
        }));
      }
    }
  };

  // Form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.clientName || !formData.clientPhone || !formData.serviceName || 
        !formData.appointmentDate || !formData.appointmentTime || !formData.price) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    const data = {
      clientName: formData.clientName,
      clientPhone: formData.clientPhone,
      clientEmail: formData.clientEmail || undefined,
      serviceName: formData.serviceName,
      serviceId: formData.serviceId || undefined,
      appointmentDate: formData.appointmentDate,
      appointmentTime: formData.appointmentTime,
      price: formData.price,
      status: formData.status,
      notes: formData.notes || undefined,
      professionalId: formData.professionalId || undefined,
    };

    if (editingAppointment) {
      const updatedAppointment = {
        ...editingAppointment,
        ...data,
        clientEmail: data.clientEmail ?? null,
        serviceId: data.serviceId ?? null,
        notes: data.notes ?? null,
      } as Appointment;
      updateAppointment.mutate(
        { id: editingAppointment.id, ...data },
        { onSuccess: () => setAppointmentToNotify({ appointment: updatedAppointment, kind: "rescheduled" }) },
      );
    } else {
      createAppointment.mutate(data);
    }
  };

  // Edit appointment
  const handleEdit = (appointment: Appointment) => {
    // O valor já está no formato do input type="date" e deve ser preservado literalmente.
    const dateStr = appointment.appointmentDate;
    
    setFormData({
      clientName: appointment.clientName,
      clientPhone: appointment.clientPhone,
      clientEmail: appointment.clientEmail || "",
      serviceName: appointment.serviceName,
      serviceId: appointment.serviceId,
      appointmentDate: dateStr,
      appointmentTime: appointment.appointmentTime,
      price: appointment.price,
      status: appointment.status,
        notes: appointment.notes || "",
      professionalId: appointment.professionalId,
    });
    setEditingAppointment(appointment);
  };

  // Open new appointment with selected date
  const handleNewAppointmentForDate = (date: Date) => {
    setFormData(prev => ({
      ...prev,
      appointmentDate: format(date, 'yyyy-MM-dd'),
      professionalId: isStrictAdmin ? prev.professionalId : (admin?.professionalId ?? null),
    }));
    setIsNewAppointmentOpen(true);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[oklch(0.99_0.008_80)]">
        <Loader2 className="h-8 w-8 animate-spin text-[oklch(0.63_0.12_53)]" />
      </div>
    );
  }

  if (!admin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-[oklch(0.99_0.008_80)] md:flex">
      {isSidebarOpen && (
        <button
          type="button"
          aria-label="Fechar menu lateral"
          className="fixed inset-0 z-40 bg-black/55 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <aside
        aria-label="Menu administrativo"
        className={`fixed inset-y-0 left-0 z-50 flex w-[min(88vw,20rem)] -translate-x-full flex-col border-r border-[oklch(0.86_0.025_75)] bg-white shadow-2xl transition-transform duration-200 md:sticky md:top-0 md:z-auto md:h-screen md:w-64 md:translate-x-0 md:shadow-none ${isSidebarOpen ? "translate-x-0" : ""}`}
      >
        <div className="flex items-center justify-between gap-3 border-b border-[oklch(0.93_0.04_15)] px-4 py-4 md:px-5">
          <div className="flex min-w-0 items-center gap-3">
            <div className="rounded-full bg-[oklch(0.93_0.03_75)] p-2"><Leaf className="h-6 w-6 text-[oklch(0.63_0.12_53)]" /></div>
            <div className="min-w-0">
              <h1 className="truncate text-lg font-medium text-[oklch(0.22_0.025_70)]" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Gb Barbearia</h1>
              <p className="truncate text-xs text-[oklch(0.43_0.025_70)]">Olá, {admin.name || admin.username}</p>
            </div>
          </div>

          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="shrink-0 md:hidden"
            aria-label="Fechar menu lateral"
            onClick={() => setIsSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        <nav aria-label="Navegação administrativa" className={`${ADMIN_NAV_LAYOUT_CLASSES.container} flex-1`}>
          {visibleNavItems.map((item) => {
            const Icon = item.icon;
            if (item.type === "link") {
              return (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={() => setIsSidebarOpen(false)}
                  className="flex w-full items-center gap-3 rounded-lg border border-[oklch(0.86_0.025_75)] px-3 py-2 text-sm font-medium text-[oklch(0.35_0.03_70)] transition hover:bg-[oklch(0.95_0.02_75)]"
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  {item.label}
                </a>
              );
            }
            return (
              <Button
                key={item.tab}
                variant={activeTab === item.tab ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  setActiveTab(item.tab);
                  setIsSidebarOpen(false);
                }}
                className={`${ADMIN_NAV_LAYOUT_CLASSES.item} ${activeTab === item.tab ? "bg-[oklch(0.63_0.12_53)]" : ""}`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="min-w-0 flex-1 truncate text-left">{item.label}</span>
                {item.tab === "pendentes" && pendingRequestsCount > 0 && (
                  <span
                    aria-label={`${pendingRequestsCount} solicitações pendentes`}
                    className={`inline-flex min-w-6 shrink-0 items-center justify-center rounded-full px-2 py-0.5 text-xs font-bold leading-none ${activeTab === item.tab ? "bg-white text-[oklch(0.63_0.12_53)]" : "bg-[oklch(0.63_0.12_53)] text-white"}`}
                  >
                    {getPendingBadgeLabel(pendingRequestsCount)}
                  </span>
                )}
              </Button>
            );
          })}
        </nav>
        <div className="border-t border-[oklch(0.93_0.04_15)] bg-white p-4">
          <Button variant="outline" size="sm" onClick={logout} disabled={isLoggingOut} className="w-full justify-start border-[oklch(0.86_0.025_75)]">
            {isLoggingOut ? <Loader2 className="h-4 w-4 animate-spin" /> : <><LogOut className="mr-2 h-4 w-4" />Sair</>}
          </Button>
        </div>
      </aside>

      <main className="min-w-0 flex-1 px-4 py-5 md:px-8 md:py-6">
        <div className="mb-5 flex items-center gap-3 md:hidden">
          <Button
            type="button"
            variant="outline"
            size="icon"
            aria-label="Abrir menu lateral"
            aria-expanded={isSidebarOpen}
            onClick={() => setIsSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[oklch(0.63_0.12_53)]">Gb Barbearia</p>
            <p className="text-sm text-[oklch(0.35_0.03_70)]">Painel administrativo</p>
          </div>

        </div>
        {activeTab === "pendentes" && (
          <PendingAppointmentsTab />
        )}

        {activeTab === "agenda" && (
          <>
            <Card className="mb-6 border-none shadow-sm">
              <CardContent className="space-y-4 p-4 md:p-5">
                <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
                  <div>
                    <p className="text-sm font-semibold text-[oklch(0.22_0.025_70)]">Encontrar agendamentos</p>
                    <p className="text-xs text-[oklch(0.43_0.025_70)]">Use os filtros para localizar clientes e organizar sua agenda.</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[oklch(0.43_0.025_70)]">
                    <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-green-500" />Confirmado</span>
                    <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-yellow-500" />Pendente</span>
                    <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-red-500" />Cancelado</span>
                  </div>
                </div>
                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-[minmax(220px,1.5fr)_minmax(160px,1fr)_minmax(180px,1fr)_auto]">
                  <Input value={appointmentSearch} onChange={(event) => setAppointmentSearch(event.target.value)} placeholder="Buscar cliente, telefone, serviço..." aria-label="Buscar agendamentos" />
                  <Select value={appointmentStatusFilter} onValueChange={(value: typeof appointmentStatusFilter) => setAppointmentStatusFilter(value)}>
                    <SelectTrigger aria-label="Filtrar por status"><SelectValue placeholder="Todos os status" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os status</SelectItem>
                      <SelectItem value="pendente">Pendentes</SelectItem>
                      <SelectItem value="confirmado">Confirmados</SelectItem>
                      <SelectItem value="cancelado">Cancelados</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={appointmentProfessionalFilter} onValueChange={setAppointmentProfessionalFilter}>
                    <SelectTrigger aria-label="Filtrar por barbeiro"><SelectValue placeholder="Todas os barbeiros" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas os barbeiros</SelectItem>
                      <SelectItem value="none">Sem barbeiro definida</SelectItem>
                      {professionals.map((professional) => <SelectItem key={professional.id} value={String(professional.id)}>{professional.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <div className="flex rounded-lg border border-[oklch(0.86_0.025_75)] bg-white p-1" role="group" aria-label="Visualização da agenda">
                    {(["day", "week", "month"] as const).map((view) => (
                      <Button key={view} type="button" variant={agendaView === view ? "default" : "ghost"} size="sm" onClick={() => setAgendaView(view)} className={agendaView === view ? "bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]" : "text-[oklch(0.35_0.03_70)]"}>
                        {view === "day" ? "Dia" : view === "week" ? "Semana" : "Mês"}
                      </Button>
                    ))}
                  </div>
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[oklch(0.43_0.025_70)]">
                  <span>{filteredAppointments.length} {filteredAppointments.length === 1 ? "agendamento encontrado" : "agendamentos encontrados"}</span>
                  {(appointmentSearch || appointmentStatusFilter !== "all" || appointmentProfessionalFilter !== "all") && (
                    <Button type="button" variant="ghost" size="sm" onClick={() => { setAppointmentSearch(""); setAppointmentStatusFilter("all"); setAppointmentProfessionalFilter("all"); }} className="h-7 px-2 text-[oklch(0.63_0.12_53)]">Limpar filtros</Button>
                  )}
                </div>
              </CardContent>
            </Card>
            <Card className="border-none shadow-sm mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-xl font-semibold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
                  Todos os próximos horários
                </CardTitle>
              </CardHeader>
              <CardContent>
                {upcomingAppointments.length === 0 ? (
                  <p className="text-sm text-[oklch(0.43_0.025_70)] py-3">
                    Não há próximos horários ativos cadastrados.
                  </p>
                ) : (
                  <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
                    {upcomingAppointments.map((appointment) => {
                      const confirmationUrl = getAppointmentConfirmationUrl(appointment);
                      return (
                        <div key={appointment.id} className="rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.01_20)] p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <p className="font-semibold text-[oklch(0.22_0.025_70)]">{appointment.clientName}</p>
                              <p className="text-sm text-[oklch(0.43_0.025_70)]">{appointment.serviceName}</p>
                              <p className="mt-1 text-xs text-[oklch(0.63_0.12_53)]">{appointment.professionalName ? `Barbeiro: ${appointment.professionalName}` : "Sem preferência"}</p>
                            </div>
                            <Badge className={statusConfig[appointment.status].color}>
                              {getAppointmentStatusLabel(appointment.status, appointment.source ?? "admin")}
                            </Badge>
                          </div>
                          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-[oklch(0.35_0.03_70)]">
                            <span className="inline-flex items-center gap-1.5"><CalendarIcon className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />{formatCivilDateForWhatsApp(appointment.appointmentDate)}</span>
                            <span className="inline-flex items-center gap-1.5"><Clock className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />{formatTimeForWhatsApp(appointment.appointmentTime)}</span>
                          </div>
                          {confirmationUrl ? (
                            <Button asChild size="sm" variant="outline" className="mt-3 w-full border-[oklch(0.63_0.12_53)] text-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.63_0.12_53)] hover:text-white focus-visible:ring-2 focus-visible:ring-[oklch(0.63_0.12_53)] focus-visible:ring-offset-2">
                              <a href={confirmationUrl} target="_blank" rel="noreferrer">
                                <MessageCircle className="mr-2 h-4 w-4" />
                                Confirmar pelo WhatsApp
                              </a>
                            </Button>
                          ) : (
                            <p className="mt-3 text-xs text-red-600">Telefone inválido para confirmação.</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="grid lg:grid-cols-3 gap-6">
            {/* Calendar */}
            <Card className="lg:col-span-2 border-none shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-xl font-semibold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
                  Calendário de Agendamentos
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-medium min-w-[140px] text-center">
                    {format(currentMonth, "MMMM yyyy", { locale: ptBR })}
                  </span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {appointmentsLoading ? (
                  <div className="flex items-center justify-center h-64">
                    <Loader2 className="h-8 w-8 animate-spin text-[oklch(0.63_0.12_53)]" />
                  </div>
                ) : agendaView === "month" ? (
                  <div className="grid grid-cols-7 gap-1">
                    {/* Week days header */}
                    {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => (
                      <div key={day} className="text-center text-xs font-medium text-[oklch(0.43_0.025_70)] py-2">
                        {day}
                      </div>
                    ))}
                    
                    {/* Empty cells for days before month start */}
                    {Array.from({ length: monthStart.getDay() }).map((_, i) => (
                      <div key={`empty-${i}`} className="aspect-square" />
                    ))}
                    
                    {/* Days */}
                    {daysInMonth.map((day) => {
                      const dateStr = format(day, 'yyyy-MM-dd');
                      const dayAppointments = appointmentsByDate.get(dateStr) || [];
                      const hasAppointments = dayAppointments.length > 0;
                      const isSelected = selectedDate && isSameDay(day, selectedDate);
                      
                      return (
                        <button
                          key={dateStr}
                          onClick={() => setSelectedDate(day)}
                          className={`
                            aspect-square p-1 rounded-lg text-sm relative transition-all
                            ${isToday(day) ? "ring-2 ring-[oklch(0.63_0.12_53)]" : ""}
                            ${isSelected ? "bg-[oklch(0.63_0.12_53)] text-white" : "hover:bg-[oklch(0.95_0.025_20)]"}
                          `}
                        >
                          <span className={isSelected ? "text-white" : "text-[oklch(0.22_0.025_70)]"}>
                            {format(day, "d")}
                          </span>
                          {hasAppointments && (
                            <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5">
                              {dayAppointments.slice(0, 3).map((apt, i) => (
                                <div
                                  key={i}
                                  className={`w-1.5 h-1.5 rounded-full ${
                                    apt.status === "confirmado" ? "bg-green-500" :
                                    apt.status === "cancelado" ? "bg-red-500" : "bg-yellow-500"
                                  }`}
                                />
                              ))}
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="mb-3 text-sm text-[oklch(0.43_0.025_70)]">
                      {agendaView === "day"
                        ? format(selectedDate ?? new Date(), "EEEE, dd 'de' MMMM", { locale: ptBR })
                        : `${format(startOfWeek(selectedDate ?? currentMonth, { weekStartsOn: 1 }), "dd/MM")} a ${format(endOfWeek(selectedDate ?? currentMonth, { weekStartsOn: 1 }), "dd/MM/yyyy")}`}
                    </p>
                    {periodAppointments.length === 0 ? (
                      <p className="rounded-xl border border-dashed border-[oklch(0.86_0.025_75)] p-8 text-center text-sm text-[oklch(0.43_0.025_70)]">Nenhum agendamento neste período com os filtros atuais.</p>
                    ) : periodAppointments.map((appointment) => (
                      <div key={appointment.id} className="flex flex-col gap-3 rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.01_20)] p-3 sm:flex-row sm:items-center sm:justify-between">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-semibold text-[oklch(0.22_0.025_70)]">{appointment.clientName}</span>
                            <Badge className={statusConfig[appointment.status].color}>{getAppointmentStatusLabel(appointment.status, appointment.source ?? "admin")}</Badge>
                          </div>
                          <p className="mt-1 text-sm text-[oklch(0.43_0.025_70)]">{appointment.serviceName} · {appointment.professionalName || "Sem preferência"}</p>
                        </div>
                        <div className="shrink-0 text-left text-sm text-[oklch(0.35_0.03_70)] sm:text-right">
                          <p className="font-semibold text-[oklch(0.63_0.12_53)]">{formatCivilDateForWhatsApp(appointment.appointmentDate)}</p>
                          <p>{formatTimeForWhatsApp(appointment.appointmentTime)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Selected Date Appointments */}
            <Card className="border-none shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-lg font-semibold" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
                  {selectedDate ? format(selectedDate, "dd 'de' MMMM", { locale: ptBR }) : "Selecione uma data"}
                </CardTitle>
                {selectedDate && (
                  <Dialog open={isNewAppointmentOpen} onOpenChange={setIsNewAppointmentOpen}>
                    <DialogTrigger asChild>
                      <Button
                        size="sm"
                        className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]"
                        onClick={() => handleNewAppointmentForDate(selectedDate)}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Novo
                      </Button>
                    </DialogTrigger>
                    <AppointmentDialog
                      formData={formData}
                      setFormData={setFormData}
                      services={services}
                      professionals={professionals}
                      onServiceSelect={handleServiceSelect}
                      onSubmit={handleSubmit}
                      isLoading={createAppointment.isPending}
                      isEditing={false}
                      isAdmin={isStrictAdmin}
                      userProfessionalId={admin?.professionalId}
                    />
                  </Dialog>
                )}
              </CardHeader>
              <CardContent>
                {!selectedDate ? (
                  <p className="text-sm text-[oklch(0.43_0.025_70)] text-center py-8">
                    Clique em um dia no calendário para ver os agendamentos
                  </p>
                ) : selectedDateAppointments.length === 0 ? (
                  <p className="text-sm text-[oklch(0.43_0.025_70)] text-center py-8">
                    Nenhum agendamento para esta data
                  </p>
                ) : (
                  <div className="space-y-3 max-h-[500px] overflow-y-auto">
                    {selectedDateAppointments
                      .sort((a, b) => a.appointmentTime.localeCompare(b.appointmentTime))
                      .map((apt) => (
                        <AppointmentCard
                          key={apt.id}
                          appointment={apt}
                          onEdit={() => handleEdit(apt)}
                          onDelete={() => deleteAppointment.mutate({ id: apt.id })}
                          onStatusChange={(status) => handleAppointmentStatusChange(apt, status)}
                          confirmationUrl={apt.status === "cancelado" ? null : getAppointmentConfirmationUrl(apt)}
                        />
                      ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          </>
        )}

        {activeTab === "servicos" && isStrictAdmin && (
          <ServicesTab services={services} />
        )}

        {activeTab === "profissionais" && isStrictAdmin && (
          <ProfessionalsTab />
        )}

        {activeTab === "usuarios" && isStrictAdmin && (
          <AdminUsersTab />
        )}

        {activeTab === "clientes" && isStrictAdmin && (
          <ClientsTab services={services} />
        )}

        {activeTab === "meu-usuario" && (
          <MyUserTab />
        )}

        {activeTab === "pagina" && isStrictAdmin && (
          <HomeHeroTab />
        )}

        {activeTab === "sobre" && isStrictAdmin && (
          <AboutTab />
        )}

        {activeTab === "imagens" && isStrictAdmin && (
          <SiteImagesTab />
        )}

        {activeTab === "horarios" && isStrictAdmin && (
          <AvailabilityTab />
        )}

        {activeTab === "relatorios" && (
          <ReportsTab isAdmin={isStrictAdmin} user={admin} />
        )}

        {activeTab === "postagens" && (
          <PostsTab authorDefaultName={admin?.name || "Equipe Gb Barbearia"} />
        )}

        {activeTab === "sorteios" && isStrictAdmin && (
          <RafflesTab services={services} />
        )}
      </main>

      {/* Edit Dialog */}
      <Dialog open={!!editingAppointment} onOpenChange={(open) => !open && setEditingAppointment(null)}>
        <AppointmentDialog
          formData={formData}
          setFormData={setFormData}
          services={services}
          professionals={professionals}
          onServiceSelect={handleServiceSelect}
          onSubmit={handleSubmit}
          isLoading={updateAppointment.isPending}
          isEditing={true}
        />
      </Dialog>

      {appointmentToNotify && (
        <WhatsAppNotificationDialog
          appointment={appointmentToNotify.appointment}
          kind={appointmentToNotify.kind}
          open={!!appointmentToNotify}
          onOpenChange={(open) => !open && setAppointmentToNotify(null)}
        />
      )}
    </div>
  );
}

function WhatsAppNotificationDialog({
  appointment,
  kind,
  open,
  onOpenChange,
}: {
  appointment: Appointment;
  kind: AppointmentNotificationKind;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const notificationUrl = getAppointmentNotificationUrl(appointment, kind);
  const title = kind === "confirmed"
    ? "Horário confirmado"
    : kind === "rescheduled"
      ? "Alteração salva"
      : "Horário cancelado";
  const description = kind === "confirmed"
    ? `O horário de ${appointment.clientName} foi confirmado. Deseja notificar o cliente pelo WhatsApp?`
    : kind === "rescheduled"
      ? `A alteração do horário de ${appointment.clientName} foi salva. Deseja notificar o cliente pelo WhatsApp?`
      : `O horário de ${appointment.clientName} foi cancelado. Deseja notificar o cliente pelo WhatsApp?`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="rounded-lg bg-[oklch(0.96_0.02_75)] p-3 text-sm text-[oklch(0.35_0.03_70)]">
          {formatCivilDateForWhatsApp(appointment.appointmentDate)} às {formatTimeForWhatsApp(appointment.appointmentTime)} · {appointment.serviceName}{appointment.professionalName ? ` · ${appointment.professionalName}` : " · Sem preferência"}
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Agora não</Button>
          {notificationUrl ? (
            <Button asChild type="button" className="bg-emerald-600 hover:bg-emerald-700">
              <a href={notificationUrl} target="_blank" rel="noreferrer" onClick={() => onOpenChange(false)}>
                <MessageCircle className="mr-2 h-4 w-4" />Enviar mensagem
              </a>
            </Button>
          ) : (
            <Button type="button" disabled>Telefone inválido</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Appointment Dialog Component
function AppointmentDialog({
  formData,
  setFormData,
  services,
  professionals,
  onServiceSelect,
  onSubmit,
  isLoading,
  isEditing,
  isAdmin = true,
  userProfessionalId = null,
}: {
  formData: any;
  setFormData: (fn: (prev: any) => any) => void;
  services: Service[];
  professionals: Professional[];
  onServiceSelect: (id: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  isLoading: boolean;
  isEditing: boolean;
  isAdmin?: boolean;
  userProfessionalId?: number | null;
}) {
  const linkedProfessionalName = professionals.find(p => p.id === userProfessionalId)?.name || "Seu perfil barbeiro";
  return (
    <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
          {isEditing ? "Editar Agendamento" : "Novo Agendamento"}
        </DialogTitle>
        <DialogDescription>
          {isEditing ? "Atualize as informações do agendamento" : "Preencha os dados para criar um novo agendamento"}
        </DialogDescription>
      </DialogHeader>

      <form onSubmit={onSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <Label>Cliente *</Label>
            <Input
              placeholder="Nome do cliente"
              value={formData.clientName}
              onChange={(e) => setFormData((prev: any) => ({ ...prev, clientName: e.target.value }))}
            />
          </div>

          <div>
            <Label>Telefone *</Label>
            <Input
              placeholder="(00) 00000-0000"
              value={formData.clientPhone}
              onChange={(e) => setFormData((prev: any) => ({ ...prev, clientPhone: e.target.value }))}
            />
          </div>

          <div>
            <Label>Email</Label>
            <Input
              type="email"
              placeholder="email@exemplo.com"
              value={formData.clientEmail}
              onChange={(e) => setFormData((prev: any) => ({ ...prev, clientEmail: e.target.value }))}
            />
          </div>

          <div className="col-span-2">
            <Label>Serviço *</Label>
            <Select
              value={formData.serviceId?.toString() || "custom"}
              onValueChange={onServiceSelect}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione um serviço" />
              </SelectTrigger>
              <SelectContent>
                {services.map((service) => (
                  <SelectItem key={service.id} value={service.id.toString()}>
                    {service.name} - {service.discountPercent ? `R$ ${getServicePromotionalPrice(service.defaultPrice, service.discountPercent).toFixed(2)} (−${service.discountPercent}%)` : `R$ ${service.defaultPrice}`}
                  </SelectItem>
                ))}
                <SelectItem value="custom">Outro (digitar)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="col-span-2">
            <Label>Barbeiro responsável</Label>
            {isAdmin ? (
              <Select
                value={formData.professionalId?.toString() || "none"}
                onValueChange={(value) => setFormData((prev: any) => ({ ...prev, professionalId: value === "none" ? null : Number(value) }))}
              >
                <SelectTrigger><SelectValue placeholder="Sem preferência" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sem preferência</SelectItem>
                  {professionals.map((professional) => (
                    <SelectItem key={professional.id} value={professional.id.toString()}>
                      {professional.name}{professional.specialty ? ` · ${professional.specialty}` : ""}{professional.active !== 1 ? " (inativo)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <div className="rounded-lg bg-[oklch(0.96_0.02_75)] p-3 text-sm text-[oklch(0.22_0.025_70)] border border-[oklch(0.91_0.03_20)]">
                Barbeiro vinculada: <strong className="text-[oklch(0.63_0.12_53)]">{linkedProfessionalName}</strong>
                <p className="mt-1 text-xs text-muted-foreground">Novos agendamentos criados por sua conta são atribuídos automaticamente à barbeiro.</p>
              </div>
            )}
            {isAdmin && <p className="mt-1 text-xs text-muted-foreground">Você pode definir o barbeiro agora ou deixar para depois.</p>}
          </div>

          {!formData.serviceId && (
            <div className="col-span-2">
              <Label>Nome do Serviço *</Label>
              <Input
                placeholder="Digite o nome do serviço"
                value={formData.serviceName}
                onChange={(e) => setFormData((prev: any) => ({ ...prev, serviceName: e.target.value }))}
              />
            </div>
          )}

          <div>
            <Label>Data *</Label>
            <Input
              type="date"
              value={formData.appointmentDate}
              onChange={(e) => setFormData((prev: any) => ({ ...prev, appointmentDate: e.target.value }))}
            />
          </div>

          <div>
            <Label>Horário *</Label>
            <Input
              type="time"
              value={formData.appointmentTime}
              onChange={(e) => setFormData((prev: any) => ({ ...prev, appointmentTime: e.target.value }))}
            />
          </div>

          <div>
            <Label>Valor (R$) *</Label>
            <Input
              type="number"
              step="0.01"
              placeholder="0.00"
              value={formData.price}
              onChange={(e) => setFormData((prev: any) => ({ ...prev, price: e.target.value }))}
            />
          </div>

          <div>
            <Label>Status</Label>
            <Select
              value={formData.status}
              onValueChange={(value: "confirmado" | "cancelado" | "pendente") => 
                setFormData((prev: any) => ({ ...prev, status: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="confirmado">Confirmado</SelectItem>
                <SelectItem value="cancelado">Cancelado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="col-span-2">
            <Label>Observações</Label>
            <Textarea
              placeholder="Observações adicionais..."
              value={formData.notes}
              onChange={(e) => setFormData((prev: any) => ({ ...prev, notes: e.target.value }))}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            type="submit"
            className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Salvando...
              </>
            ) : (
              isEditing ? "Salvar Alterações" : "Criar Agendamento"
            )}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}

// Appointment Card Component
function AppointmentCard({
  appointment,
  onEdit,
  onDelete,
  onStatusChange,
  confirmationUrl,
}: {
  appointment: Appointment;
  onEdit: () => void;
  onDelete: () => void;
  onStatusChange: (status: "confirmado" | "cancelado" | "pendente") => void;
  confirmationUrl: string | null;
}) {
  const status = statusConfig[appointment.status];
  const StatusIcon = status.icon;

  return (
    <div className="p-3 rounded-lg bg-[oklch(0.96_0.02_75)] border border-[oklch(0.94_0.035_15)]">
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />
          <span className="font-medium text-[oklch(0.22_0.025_70)]">
            {formatTimeForWhatsApp(appointment.appointmentTime)}
          </span>
        </div>
        <Badge className={status.color}>
          <StatusIcon className="h-3 w-3 mr-1" />
          {getAppointmentStatusLabel(appointment.status, appointment.source ?? "admin")}
        </Badge>
      </div>

      <div className="space-y-1 text-sm">
        <div className="flex items-center gap-2">
          <User className="h-3.5 w-3.5 text-[oklch(0.43_0.025_70)]" />
          <span className="text-[oklch(0.36_0.04_10)]">{appointment.clientName}</span>
        </div>
        <div className="flex items-center gap-2">
          <Phone className="h-3.5 w-3.5 text-[oklch(0.43_0.025_70)]" />
          <span className="text-[oklch(0.43_0.025_70)]">{appointment.clientPhone}</span>
        </div>
        <div className="flex items-center gap-2">
          <Leaf className="h-3.5 w-3.5 text-[oklch(0.43_0.025_70)]" />
          <span className="text-[oklch(0.43_0.025_70)]">{appointment.serviceName}</span>
        </div>
        <div className="flex items-center gap-2">
          <User className="h-3.5 w-3.5 text-[oklch(0.43_0.025_70)]" />
          <span className="text-[oklch(0.43_0.025_70)]">{appointment.professionalName || "Sem preferência"}</span>
        </div>
        <div className="flex items-center gap-2">
          <DollarSign className="h-3.5 w-3.5 text-[oklch(0.43_0.025_70)]" />
          <span className="text-[oklch(0.43_0.025_70)]">R$ {appointment.price}</span>
        </div>
        {appointment.reason && (
          <div className="mt-2 rounded-md bg-[oklch(0.95_0.03_20)] p-2 text-xs text-[oklch(0.36_0.04_10)] border border-[oklch(0.90_0.03_20)]">
            <span className="font-semibold text-[oklch(0.63_0.12_53)] block mb-0.5">Motivo informado:</span>
            "{appointment.reason}"
          </div>
        )}
      </div>

      {confirmationUrl && (
        <Button asChild size="sm" variant="outline" className="mt-3 w-full border-[oklch(0.63_0.12_53)] text-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.63_0.12_53)] hover:text-white focus-visible:ring-2 focus-visible:ring-[oklch(0.63_0.12_53)] focus-visible:ring-offset-2">
          <a href={confirmationUrl} target="_blank" rel="noreferrer">
            <MessageCircle className="mr-2 h-4 w-4" />
            Confirmar horário pelo WhatsApp
          </a>
        </Button>
      )}

      <div className="flex items-center gap-2 mt-3 pt-3 border-t border-[oklch(0.94_0.035_15)]">
        <Select
          value={appointment.status}
          onValueChange={onStatusChange}
        >
          <SelectTrigger className="h-8 text-xs flex-1">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="pendente">Pendente</SelectItem>
            <SelectItem value="confirmado">Confirmado</SelectItem>
            <SelectItem value="cancelado">Cancelado</SelectItem>
          </SelectContent>
        </Select>

        <Button variant="outline" size="icon" className="h-8 w-8" onClick={onEdit}>
          <Edit className="h-3.5 w-3.5" />
        </Button>

        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline" size="icon" className="h-8 w-8 text-red-600 hover:text-red-700">
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Excluir Agendamento</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir este agendamento? Esta ação não pode ser desfeita.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={onDelete} className="bg-red-600 hover:bg-red-700">
                Excluir
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

function PendingAppointmentsTab() {
  const utils = trpc.useUtils();
  const { data: pendingAppointments = [], isLoading } = trpc.appointments.pendingPublic.useQuery();
  const { data: activeProfessionals = [] } = trpc.professionals.listActive.useQuery();
  const [appointmentToNotify, setAppointmentToNotify] = useState<{ appointment: Appointment; kind: AppointmentNotificationKind } | null>(null);
  const updateStatus = trpc.appointments.updateStatus.useMutation({
    onSuccess: (_, variables) => {
      toast.success(variables.status === "confirmado" ? "Solicitação confirmada!" : "Solicitação cancelada.");
      utils.appointments.pendingPublic.invalidate();
      utils.appointments.list.invalidate();
      utils.availability.slots.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const handleStatusChange = (appointment: Appointment, status: Appointment["status"], professionalId?: number | null) => {
    updateStatus.mutate(
      { id: appointment.id, status, professionalId: professionalId ?? null },
      {
        onSuccess: () => {
          if (status === "confirmado" || status === "cancelado") {
            setAppointmentToNotify({
              appointment: { ...appointment, status, professionalId: professionalId ?? appointment.professionalId, professionalName: activeProfessionals.find((professional) => professional.id === (professionalId ?? appointment.professionalId))?.name ?? null },
              kind: status === "confirmado" ? "confirmed" : "cancelled",
            });
          }
        },
      },
    );
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Agendamentos Pendentes</CardTitle>
          <p className="text-sm text-[oklch(0.43_0.025_70)] mt-1">
            Solicitações enviadas pela Home aguardando confirmação. Ao confirmar, o horário passa a integrar a agenda normalmente.
          </p>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-[oklch(0.63_0.12_53)]" /></div>
          ) : pendingAppointments.length === 0 ? (
            <div className="rounded-xl border border-dashed border-[oklch(0.86_0.025_75)] px-6 py-10 text-center">
              <AlertCircle className="mx-auto h-8 w-8 text-[oklch(0.68_0.08_15)]" />
              <p className="mt-3 font-medium text-[oklch(0.36_0.04_10)]">Nenhum horário pendente</p>
              <p className="mt-1 text-sm text-muted-foreground">Novas solicitações feitas pela página inicial aparecerão aqui.</p>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {pendingAppointments.map((appointment) => (
                <PendingAppointmentCard
                  key={appointment.id}
                  appointment={appointment as Appointment}
                  onStatusChange={(status, professionalId) => handleStatusChange(appointment as Appointment, status, professionalId)}
                  professionals={activeProfessionals}
                  isStatusUpdating={updateStatus.isPending}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      {appointmentToNotify && (
        <WhatsAppNotificationDialog
          appointment={appointmentToNotify.appointment}
          kind={appointmentToNotify.kind}
          open={!!appointmentToNotify}
          onOpenChange={(open) => !open && setAppointmentToNotify(null)}
        />
      )}
    </div>
  );
}

function PendingAppointmentCard({
  appointment,
  onStatusChange,
  professionals,
  isStatusUpdating,
}: {
  appointment: Appointment;
  onStatusChange: (status: Appointment["status"], professionalId?: number | null) => void;
  professionals: Professional[];
  isStatusUpdating: boolean;
}) {
  const utils = trpc.useUtils();
  const [isEditing, setIsEditing] = useState(false);
  const [editDate, setEditDate] = useState(appointment.appointmentDate);
  const [editTime, setEditTime] = useState(appointment.appointmentTime.slice(0, 5));
  const [selectedProfessionalId, setSelectedProfessionalId] = useState<number | null>(appointment.professionalId);
  const [appointmentToNotify, setAppointmentToNotify] = useState<Appointment | null>(null);
  const selectedProfessional = professionals.find((professional) => professional.id === selectedProfessionalId) ?? null;
  const appointmentForMessage = { ...appointment, professionalName: selectedProfessional?.name ?? null };
  const confirmationUrl = getAppointmentConfirmationUrl(appointmentForMessage);

  const updateAppointment = trpc.appointments.update.useMutation({
    onSuccess: () => {
      toast.success("Data e horário da solicitação atualizados.");
      setIsEditing(false);
      utils.appointments.pendingPublic.invalidate();
      utils.appointments.list.invalidate();
      utils.availability.slots.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const startEditing = () => {
    setEditDate(appointment.appointmentDate);
    setEditTime(appointment.appointmentTime.slice(0, 5));
    setSelectedProfessionalId(appointment.professionalId);
    setIsEditing(true);
  };

  const saveEditing = () => {
    if (!editDate || !editTime) {
      toast.error("Informe a nova data e o novo horário.");
      return;
    }
    const updatedAppointment = {
      ...appointment,
      appointmentDate: editDate,
      appointmentTime: editTime,
      professionalId: selectedProfessionalId,
      professionalName: selectedProfessional?.name ?? null,
    };
    updateAppointment.mutate(
      {
        id: appointment.id,
        appointmentDate: editDate,
        appointmentTime: editTime,
        professionalId: selectedProfessionalId,
      },
      { onSuccess: () => setAppointmentToNotify(updatedAppointment) },
    );
  };

  return (
    <div className="rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.01_20)] p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-semibold text-[oklch(0.22_0.025_70)]">{appointment.clientName}</p>
          <p className="text-sm text-[oklch(0.43_0.025_70)]">{appointment.serviceName}</p>
        </div>
        <Badge className={statusConfig.pendente.color}>{getAppointmentStatusLabel("pendente", "public")}</Badge>
      </div>
      {isEditing ? (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div><Label htmlFor={`pending-date-${appointment.id}`}>Nova data</Label><Input id={`pending-date-${appointment.id}`} type="date" value={editDate} onChange={(event) => setEditDate(event.target.value)} /></div>
          <div><Label htmlFor={`pending-time-${appointment.id}`}>Novo horário</Label><Input id={`pending-time-${appointment.id}`} type="time" value={editTime} onChange={(event) => setEditTime(event.target.value)} /></div>
        </div>
      ) : (
        <div className="mt-3 grid gap-2 text-sm text-[oklch(0.35_0.03_70)]">
          <span className="inline-flex items-center gap-2"><CalendarIcon className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />{formatCivilDateForWhatsApp(appointment.appointmentDate)}</span>
          <span className="inline-flex items-center gap-2"><Clock className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />{formatTimeForWhatsApp(appointment.appointmentTime)}</span>
        </div>
      )}
      <div className="mt-3 grid gap-2 text-sm text-[oklch(0.35_0.03_70)]">
        <span className="inline-flex items-center gap-2"><Phone className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />{appointment.clientPhone}</span>
        <span className="inline-flex items-center gap-2"><DollarSign className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />R$ {appointment.price}</span>
        <span className="inline-flex items-center gap-2"><User className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />{selectedProfessional?.name || "Sem preferência de barbeiro"}</span>
        {appointment.reason && (
          <div className="mt-1 rounded-lg bg-[oklch(0.95_0.03_20)] p-2.5 text-xs text-[oklch(0.36_0.04_10)] border border-[oklch(0.90_0.03_20)]">
            <span className="font-semibold text-[oklch(0.63_0.12_53)] block mb-0.5">Motivo informado pela cliente:</span>
            "{appointment.reason}"
          </div>
        )}
      </div>
      {isEditing ? (
        <div className="mt-4 space-y-3">
          <div><Label>Barbeiro que atenderá</Label><Select value={selectedProfessionalId?.toString() || "none"} onValueChange={(value) => setSelectedProfessionalId(value === "none" ? null : Number(value))}><SelectTrigger><SelectValue placeholder="Sem preferência" /></SelectTrigger><SelectContent><SelectItem value="none">Sem preferência</SelectItem>{professionals.map((professional) => <SelectItem key={professional.id} value={professional.id.toString()}>{professional.name}{professional.specialty ? ` · ${professional.specialty}` : ""}</SelectItem>)}</SelectContent></Select></div>
        <div className="grid gap-2 sm:grid-cols-2">
          <Button type="button" onClick={saveEditing} disabled={updateAppointment.isPending} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">
            {updateAppointment.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><CheckCircle className="mr-2 h-4 w-4" />Salvar alteração</>}
          </Button>
          <Button type="button" variant="outline" onClick={() => setIsEditing(false)} disabled={updateAppointment.isPending}>Cancelar edição</Button>
        </div>
        </div>
      ) : (
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          <div className="sm:col-span-2"><Label>Barbeiro que atenderá</Label><Select value={selectedProfessionalId?.toString() || "none"} onValueChange={(value) => setSelectedProfessionalId(value === "none" ? null : Number(value))}><SelectTrigger><SelectValue placeholder="Sem preferência" /></SelectTrigger><SelectContent><SelectItem value="none">Sem preferência</SelectItem>{professionals.map((professional) => <SelectItem key={professional.id} value={professional.id.toString()}>{professional.name}{professional.specialty ? ` · ${professional.specialty}` : ""}</SelectItem>)}</SelectContent></Select></div>
          <Button type="button" onClick={() => onStatusChange("confirmado", selectedProfessionalId)} disabled={isStatusUpdating} className="bg-emerald-600 hover:bg-emerald-700">
            <CheckCircle className="mr-2 h-4 w-4" />Agendar neste horário
          </Button>
          <Button type="button" variant="outline" onClick={startEditing} disabled={isStatusUpdating}>
            <Edit className="mr-2 h-4 w-4" />Editar data e horário
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button type="button" variant="outline" disabled={isStatusUpdating} className="border-red-200 text-red-700 hover:bg-red-50">
                <XCircle className="mr-2 h-4 w-4" />Cancelar horário
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Cancelar horário solicitado?</AlertDialogTitle>
                <AlertDialogDescription>O pedido ficará marcado como cancelado e sairá da aba de pendentes.</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Voltar</AlertDialogCancel>
                <AlertDialogAction onClick={() => onStatusChange("cancelado", selectedProfessionalId)} className="bg-red-600 hover:bg-red-700">Cancelar horário</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      )}
      {confirmationUrl && (
        <Button asChild type="button" variant="outline" className="mt-2 w-full border-[oklch(0.63_0.12_53)] text-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.63_0.12_53)] hover:text-white">
          <a href={confirmationUrl} target="_blank" rel="noreferrer"><MessageCircle className="mr-2 h-4 w-4" />Falar pelo WhatsApp</a>
        </Button>
      )}
      {appointmentToNotify && (
        <WhatsAppNotificationDialog
          appointment={{ ...appointmentToNotify, professionalName: professionals.find((professional) => professional.id === appointmentToNotify.professionalId)?.name ?? null }}
          kind="rescheduled"
          open={!!appointmentToNotify}
          onOpenChange={(open) => !open && setAppointmentToNotify(null)}
        />
      )}
    </div>
  );
}

type BusinessHourRow = {
  id?: number;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  active: number;
};

type BlockedSlotRow = {
  id: number;
  blockedDate: string;
  startTime: string;
  endTime: string;
  reason: string | null;
};

const dayLabels = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
const EMPTY_LIST: never[] = [];

function AvailabilityTab() {
  const utils = trpc.useUtils();
  const { data: businessHoursData, isLoading: hoursLoading } = trpc.availability.businessHours.useQuery();
  const businessHours = businessHoursData ?? EMPTY_LIST;
  const { data: professionalsData } = trpc.professionals.list.useQuery();
  const professionals = professionalsData ?? EMPTY_LIST;
  const [selectedProfessionalId, setSelectedProfessionalId] = useState<string>("global");

  const numericProfessionalId = selectedProfessionalId === "global" ? 0 : Number(selectedProfessionalId);
  const { data: proSchedulesData, isLoading: proHoursLoading } = trpc.professionals.schedules.useQuery(
    { professionalId: numericProfessionalId },
    { enabled: selectedProfessionalId !== "global" && Number.isInteger(numericProfessionalId) && numericProfessionalId > 0 }
  );
  const proSchedules = proSchedulesData ?? EMPTY_LIST;

  const { data: blockedSlotsData, isLoading: blocksLoading } = trpc.availability.blockedSlots.useQuery();
  const blockedSlots = blockedSlotsData ?? EMPTY_LIST;
  const [hourRows, setHourRows] = useState<BusinessHourRow[]>([]);
  const [blockForm, setBlockForm] = useState({ blockedDate: "", startTime: "07:30", endTime: "08:30", reason: "" });

  useEffect(() => {
    if (selectedProfessionalId === "global") {
      if (businessHours.length > 0) {
        setHourRows(businessHours.map((slot) => ({
          id: slot.id,
          dayOfWeek: slot.dayOfWeek,
          startTime: slot.startTime.slice(0, 5),
          endTime: slot.endTime.slice(0, 5),
          active: slot.active,
        })));
      } else {
        setHourRows([]);
      }
    } else {
      if (proSchedules.length > 0) {
        setHourRows(proSchedules.map((slot) => ({
          id: slot.id,
          dayOfWeek: slot.dayOfWeek,
          startTime: slot.startTime.slice(0, 5),
          endTime: slot.endTime.slice(0, 5),
          active: slot.active,
        })));
      } else {
        setHourRows([]);
      }
    }
  }, [selectedProfessionalId, businessHours, proSchedules]);

  const updateGlobalHours = trpc.availability.updateBusinessHours.useMutation({
    onSuccess: () => {
      toast.success("Horário geral de atendimento atualizado!");
      utils.availability.businessHours.invalidate();
      utils.availability.slots.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateProHours = trpc.professionals.updateSchedules.useMutation({
    onSuccess: () => {
      toast.success("Horário personalizado do barbeiro atualizado!");
      utils.professionals.schedules.invalidate({ professionalId: numericProfessionalId });
      utils.availability.slots.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const createBlock = trpc.availability.createBlockedSlot.useMutation({
    onSuccess: () => {
      toast.success("Horário bloqueado!");
      setBlockForm({ blockedDate: "", startTime: "07:30", endTime: "08:30", reason: "" });
      utils.availability.blockedSlots.invalidate();
      utils.availability.slots.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteBlock = trpc.availability.deleteBlockedSlot.useMutation({
    onSuccess: () => {
      toast.success("Bloqueio removido!");
      utils.availability.blockedSlots.invalidate();
      utils.availability.slots.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateRow = (index: number, patch: Partial<BusinessHourRow>) => {
    setHourRows((previous) => previous.map((row, rowIndex) => rowIndex === index ? { ...row, ...patch } : row));
  };

  const addRow = () => {
    setHourRows((previous) => [...previous, { dayOfWeek: 1, startTime: "07:30", endTime: "12:00", active: 1 }]);
  };

  const removeRow = (index: number) => {
    setHourRows((previous) => previous.map((row, rowIndex) => rowIndex === index ? { ...row, active: 0 } : row));
  };

  const activeRows = hourRows.filter((row) => row.active === 1);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <Card className="border-none shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Horário de atendimento</CardTitle>
            <p className="text-sm text-[oklch(0.43_0.025_70)] mt-1">Configure os intervalos em que a agenda pode receber novos horários.</p>
          </div>
          <Button type="button" variant="outline" onClick={addRow}><Plus className="h-4 w-4 mr-2" />Adicionar intervalo</Button>
        </CardHeader>
        <CardContent className="space-y-3">
          {hoursLoading ? <p className="text-sm text-muted-foreground">Carregando expediente...</p> : hourRows.length === 0 ? <p className="text-sm text-muted-foreground">Nenhum intervalo configurado.</p> : hourRows.map((row, index) => (
            <div key={`${row.id ?? "new"}-${index}`} className={`grid grid-cols-1 sm:grid-cols-[1fr_1fr_1fr_auto_auto] gap-3 items-end rounded-lg border p-3 ${row.active ? "bg-white" : "bg-slate-50 opacity-60"}`}>
              <div><Label>Dia</Label><select value={row.dayOfWeek} onChange={(event) => updateRow(index, { dayOfWeek: Number(event.target.value) })} className="mt-1 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">{dayLabels.map((label, day) => <option key={day} value={day}>{label}</option>)}</select></div>
              <div><Label>Início</Label><Input type="time" value={row.startTime} onChange={(event) => updateRow(index, { startTime: event.target.value })} /></div>
              <div><Label>Fim</Label><Input type="time" value={row.endTime} onChange={(event) => updateRow(index, { endTime: event.target.value })} /></div>
              <label className="flex items-center gap-2 text-sm pb-2"><input type="checkbox" checked={row.active === 1} onChange={(event) => updateRow(index, { active: event.target.checked ? 1 : 0 })} />Ativo</label>
              <Button type="button" variant="outline" size="icon" onClick={() => removeRow(index)} aria-label="Desativar intervalo"><Trash2 className="h-4 w-4" /></Button>
            </div>
          ))}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-2">
            <div className="w-full sm:w-72">
              <Label className="text-xs mb-1 block">Aplicar horário para:</Label>
              <Select value={selectedProfessionalId} onValueChange={setSelectedProfessionalId}>
                <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="global">Expediente Geral da Barbearia</SelectItem>
                  {professionals.map((pro) => (
                    <SelectItem key={pro.id} value={String(pro.id)}>{pro.name} ({pro.specialty || "Barbeiro"})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between w-full sm:w-auto gap-4">
              <span className="text-xs text-muted-foreground">{activeRows.length} intervalo(s) ativo(s)</span>
              <Button type="button" onClick={() => {
                if (selectedProfessionalId === "global") {
                  updateGlobalHours.mutate({ slots: hourRows });
                } else {
                  updateProHours.mutate({ professionalId: numericProfessionalId, slots: hourRows });
                }
              }} disabled={updateGlobalHours.isPending || updateProHours.isPending || hoursLoading || proHoursLoading} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">
                {updateGlobalHours.isPending || updateProHours.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar expediente"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader><CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Bloquear um horário</CardTitle><p className="text-sm text-[oklch(0.43_0.025_70)] mt-1">Use para férias, pausas especiais ou compromissos que não devem aparecer como disponíveis.</p></CardHeader>
        <CardContent>
          <form className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[1.2fr_1fr_1fr_1.5fr_auto] gap-3 items-end" onSubmit={(event) => { event.preventDefault(); if (!blockForm.blockedDate) { toast.error("Escolha a data do bloqueio."); return; } createBlock.mutate(blockForm); }}>
            <div><Label htmlFor="blocked-date">Data</Label><Input id="blocked-date" type="date" value={blockForm.blockedDate} onChange={(event) => setBlockForm((previous) => ({ ...previous, blockedDate: event.target.value }))} /></div>
            <div><Label htmlFor="blocked-start">Início</Label><Input id="blocked-start" type="time" value={blockForm.startTime} onChange={(event) => setBlockForm((previous) => ({ ...previous, startTime: event.target.value }))} /></div>
            <div><Label htmlFor="blocked-end">Fim</Label><Input id="blocked-end" type="time" value={blockForm.endTime} onChange={(event) => setBlockForm((previous) => ({ ...previous, endTime: event.target.value }))} /></div>
            <div><Label htmlFor="blocked-reason">Motivo</Label><Input id="blocked-reason" placeholder="Ex.: compromisso pessoal" value={blockForm.reason} onChange={(event) => setBlockForm((previous) => ({ ...previous, reason: event.target.value }))} /></div>
            <Button type="submit" disabled={createBlock.isPending} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">{createBlock.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Bloquear"}</Button>
          </form>
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader><CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Bloqueios cadastrados</CardTitle></CardHeader>
        <CardContent>{blocksLoading ? <p className="text-sm text-muted-foreground">Carregando bloqueios...</p> : blockedSlots.length === 0 ? <p className="text-sm text-muted-foreground">Nenhum bloqueio específico cadastrado.</p> : <div className="space-y-2">{blockedSlots.map((block) => <div key={block.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 rounded-lg border p-3"><div><p className="font-medium">{block.blockedDate} · {block.startTime.slice(0, 5)}–{block.endTime.slice(0, 5)}</p><p className="text-sm text-muted-foreground">{block.reason || "Sem motivo informado"}</p></div><Button type="button" variant="outline" size="sm" onClick={() => deleteBlock.mutate({ id: block.id })} disabled={deleteBlock.isPending}><Trash2 className="h-4 w-4 mr-2" />Remover</Button></div>)}</div>}</CardContent>
      </Card>
    </div>
  );
}

type SiteContentForm = {
  heroName: string;
  heroSubtitle: string;
  heroDescription: string;
  aboutTitle: string;
  aboutParagraph1: string;
  aboutParagraph2: string;
  aboutHighlightTitle: string;
  aboutHighlightDescription: string;
  aboutImageUrl: string;
  logoUrl: string;
  heroImageUrl: string;
  teamImageUrl: string;
  announcementText: string;
  announcementActive: string;
  announcementLinkText: string;
};

function useSiteContentEditor() {
  const { data: content, isLoading } = trpc.siteContent.get.useQuery();
  const utils = trpc.useUtils();
  const [formData, setFormData] = useState<SiteContentForm>(() => ({ ...SITE_CONTENT_DEFAULTS }));

  useEffect(() => {
    if (content) setFormData(content);
  }, [content]);

  const updateContent = trpc.siteContent.update.useMutation({
    onSuccess: () => {
      toast.success("Conteúdo da página inicial atualizado!");
      utils.siteContent.get.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateField = (field: keyof SiteContentForm, value: string) => {
    setFormData((previous) => ({ ...previous, [field]: value }));
  };

  return { formData, updateField, updateContent, isLoading };
}

function HomeHeroTab() {
  const { formData, updateField, updateContent, isLoading } = useSiteContentEditor();

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    updateContent.mutate({
      heroName: formData.heroName,
      heroSubtitle: formData.heroSubtitle,
      heroDescription: formData.heroDescription,
      announcementText: formData.announcementText,
      announcementActive: formData.announcementActive,
      announcementLinkText: formData.announcementLinkText,
    });
  };

  return (
    <div className="max-w-3xl mx-auto">
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Editar Página Inicial</CardTitle>
          <p className="text-sm text-[oklch(0.43_0.025_70)]">Atualize o título e a apresentação exibidos no topo da Home.</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <Label htmlFor="hero-name">Título principal</Label>
              <Input id="hero-name" value={formData.heroName} onChange={(event) => updateField("heroName", event.target.value)} />
            </div>
            <div>
              <Label htmlFor="hero-subtitle">Subtítulo</Label>
              <Input id="hero-subtitle" value={formData.heroSubtitle} onChange={(event) => updateField("heroSubtitle", event.target.value)} />
            </div>
            <div>
              <Label htmlFor="hero-description">Descrição principal</Label>
              <Textarea id="hero-description" rows={5} value={formData.heroDescription} onChange={(event) => updateField("heroDescription", event.target.value)} />
            </div>
            <div className="pt-4 border-t border-[oklch(0.90_0.03_15)] space-y-4">
              <h3 className="font-serif text-lg font-medium text-[oklch(0.25_0.02_15)]">Barra de Avisos e Campanhas (Topo do Site)</h3>
              <div>
                <Label htmlFor="announcement-text">Texto do aviso</Label>
                <Input id="announcement-text" value={formData.announcementText} onChange={(event) => updateField("announcementText", event.target.value)} placeholder="Ex.: Horários especiais para esta semana..." />
              </div>
              <div>
                <Label htmlFor="announcement-link">Texto do botão de agendamento rápido</Label>
                <Input id="announcement-link" value={formData.announcementLinkText} onChange={(event) => updateField("announcementLinkText", event.target.value)} placeholder="Ex.: Agendar horário" />
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="announcement-active"
                  checked={formData.announcementActive === "1"}
                  onChange={(event) => updateField("announcementActive", event.target.checked ? "1" : "0")}
                  className="h-4 w-4 rounded border-input text-[oklch(0.63_0.12_53)] focus:ring-[oklch(0.63_0.12_53)]"
                />
                <Label htmlFor="announcement-active" className="cursor-pointer">Exibir barra de avisos no topo do site</Label>
              </div>
            </div>
            <Button type="submit" className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]" disabled={isLoading || updateContent.isPending}>
              {updateContent.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar conteúdo da Home"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function SiteImagesTab() {
  const { formData, updateField, updateContent, isLoading } = useSiteContentEditor();
  const utils = trpc.useUtils();

  const uploadLogoImage = trpc.siteContent.uploadLogoImage.useMutation({
    onSuccess: (content) => {
      updateField("logoUrl", content.logoUrl);
      utils.siteContent.get.invalidate();
      toast.success("Logo atualizada com sucesso!");
    },
    onError: (error) => toast.error(error.message),
  });

  const uploadHeroImage = trpc.siteContent.uploadHeroImage.useMutation({
    onSuccess: (content) => {
      updateField("heroImageUrl", content.heroImageUrl);
      utils.siteContent.get.invalidate();
      toast.success("Imagem do Hero atualizada com sucesso!");
    },
    onError: (error) => toast.error(error.message),
  });

  const uploadAboutImage = trpc.siteContent.uploadAboutImage.useMutation({
    onSuccess: (content) => {
      updateField("aboutImageUrl", content.aboutImageUrl);
      utils.siteContent.get.invalidate();
      toast.success("Imagem da seção Sobre atualizada com sucesso!");
    },
    onError: (error) => toast.error(error.message),
  });

  const uploadTeamImage = trpc.siteContent.uploadTeamImage.useMutation({
    onSuccess: (content) => {
      updateField("teamImageUrl", content.teamImageUrl);
      utils.siteContent.get.invalidate();
      toast.success("Imagem da equipe atualizada com sucesso!");
    },
    onError: (error) => toast.error(error.message),
  });

  const createHandler = (mutation: typeof uploadHeroImage) => (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      toast.error("Envie uma imagem JPG, PNG ou WEBP.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataBase64 = String(reader.result || "").split(",")[1];
      if (!dataBase64) {
        toast.error("Não foi possível ler o arquivo.");
        return;
      }
      mutation.mutate({ fileName: file.name, contentType: file.type as any, dataBase64 });
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    updateContent.mutate({
      logoUrl: formData.logoUrl,
      heroImageUrl: formData.heroImageUrl,
      aboutImageUrl: formData.aboutImageUrl,
      teamImageUrl: formData.teamImageUrl,
    });
  };

  const imagesConfig = [
    {
      key: "logoUrl" as const,
      title: "Logo da Barbearia",
      location: "Exibida no cabeçalho fixo do site, no desktop e no mobile.",
      value: formData.logoUrl,
      uploadMutation: uploadLogoImage,
      handler: createHandler(uploadLogoImage),
    },
    {
      key: "heroImageUrl" as const,
      title: "Imagem Principal (Hero)",
      location: "Exibida no cartão de destaque da página inicial (topo do site).",
      value: formData.heroImageUrl,
      uploadMutation: uploadHeroImage,
      handler: createHandler(uploadHeroImage),
    },
    {
      key: "aboutImageUrl" as const,
      title: "Imagem da Seção Sobre",
      location: "Exibida ao lado do texto institucional na seção 'Sobre a barbearia'.",
      value: formData.aboutImageUrl,
      uploadMutation: uploadAboutImage,
      handler: createHandler(uploadAboutImage),
    },
    {
      key: "teamImageUrl" as const,
      title: "Imagem da Seção de Barbeiros",
      location: "Exibida no bloco institucional da equipe e nas apresentações da barbearia.",
      value: formData.teamImageUrl,
      uploadMutation: uploadTeamImage,
      handler: createHandler(uploadTeamImage),
    },
  ];

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Gerenciador de Imagens do Site</CardTitle>
          <p className="text-sm text-muted-foreground">Visualize onde cada imagem é exibida, altere por URL ou envie novos arquivos diretamente para o armazenamento da barbearia.</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-8">
            {imagesConfig.map((img) => (
              <div key={img.key} className="rounded-2xl border border-[oklch(0.86_0.025_75)] bg-white p-6 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                  <div>
                    <h3 className="font-serif text-lg font-medium text-[oklch(0.25_0.02_15)]">{img.title}</h3>
                    <p className="text-xs text-muted-foreground">{img.location}</p>
                  </div>
                  <Badge className="w-fit bg-[oklch(0.94_0.03_15)] text-[oklch(0.63_0.12_53)]">Chave: {img.key}</Badge>
                </div>
                <div className="grid gap-4 md:grid-cols-[1fr_auto] items-center">
                  <div className="space-y-3">
                    <div>
                      <Label>URL da imagem</Label>
                      <Input
                        type="url"
                        value={img.value}
                        onChange={(event) => updateField(img.key, event.target.value)}
                        placeholder="https://..."
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>Enviar arquivo do computador</Label>
                      <Input
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={img.handler}
                        disabled={img.uploadMutation.isPending}
                        className="mt-1 max-w-sm"
                      />
                      <p className="mt-1 text-xs text-muted-foreground">Formatos JPG, PNG ou WebP até 5 MB.</p>
                    </div>
                  </div>
                  <div className="flex justify-center">
                    <div className="h-32 w-32 overflow-hidden rounded-xl border border-[oklch(0.86_0.025_75)] bg-slate-50 shadow-sm flex items-center justify-center">
                      {img.value ? (
                        <img src={img.value} alt={img.title} className="h-full w-full object-cover" />
                      ) : (
                        <span className="text-xs text-muted-foreground">Sem imagem</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            <Button type="submit" className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]" disabled={isLoading || updateContent.isPending}>
              {updateContent.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Salvar todas as alterações de imagens
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function AboutTab() {
  const { formData, updateField, updateContent, isLoading } = useSiteContentEditor();
  const utils = trpc.useUtils();
  const uploadAboutImage = trpc.siteContent.uploadAboutImage.useMutation({
    onSuccess: (content) => {
      updateField("aboutImageUrl", content.aboutImageUrl);
      utils.siteContent.get.invalidate();
      toast.success("Imagem da seção Sobre atualizada!");
    },
    onError: (error) => toast.error(error.message),
  });

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!(["image/jpeg", "image/png", "image/webp"] as string[]).includes(file.type)) {
      toast.error("Escolha uma imagem JPG, PNG ou WebP.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("A imagem deve ter no máximo 5 MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? "");
      const dataBase64 = result.split(",")[1];
      if (!dataBase64) {
        toast.error("Não foi possível ler a imagem selecionada.");
        return;
      }
      uploadAboutImage.mutate({ fileName: file.name, contentType: file.type as "image/jpeg" | "image/png" | "image/webp", dataBase64 });
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    updateContent.mutate({
      aboutTitle: formData.aboutTitle,
      aboutParagraph1: formData.aboutParagraph1,
      aboutParagraph2: formData.aboutParagraph2,
      aboutHighlightTitle: formData.aboutHighlightTitle,
      aboutHighlightDescription: formData.aboutHighlightDescription,
      aboutImageUrl: formData.aboutImageUrl,
    });
  };

  return (
    <div className="max-w-3xl mx-auto">
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Editar seção Sobre</CardTitle>
          <p className="text-sm text-[oklch(0.43_0.025_70)]">Atualize a apresentação barbeiro exibida na seção Sobre da Home.</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <Label htmlFor="about-title">Título da seção</Label>
              <Input id="about-title" value={formData.aboutTitle} onChange={(event) => updateField("aboutTitle", event.target.value)} />
            </div>
            <div>
              <Label htmlFor="about-paragraph-1">Primeiro parágrafo</Label>
              <Textarea id="about-paragraph-1" rows={6} value={formData.aboutParagraph1} onChange={(event) => updateField("aboutParagraph1", event.target.value)} />
            </div>
            <div>
              <Label htmlFor="about-paragraph-2">Segundo parágrafo</Label>
              <Textarea id="about-paragraph-2" rows={6} value={formData.aboutParagraph2} onChange={(event) => updateField("aboutParagraph2", event.target.value)} />
            </div>
            <div>
              <Label htmlFor="about-image-url">URL da imagem</Label>
              <Input id="about-image-url" type="url" value={formData.aboutImageUrl} onChange={(event) => updateField("aboutImageUrl", event.target.value)} placeholder="https://..." />
              <p className="mt-1 text-xs text-muted-foreground">Você também pode colar uma URL pública de imagem e salvar a seção.</p>
            </div>
            <div className="grid gap-4 md:grid-cols-[auto_1fr] items-start">
              <div>
                <Label htmlFor="about-image-file">Substituir imagem</Label>
                <Input id="about-image-file" type="file" accept="image/jpeg,image/png,image/webp" onChange={handleImageChange} disabled={uploadAboutImage.isPending} className="max-w-xs" />
                <p className="mt-1 text-xs text-muted-foreground">JPG, PNG ou WebP, até 5 MB.</p>
              </div>
              <div className="rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.98_0.02_20)] p-2">
                <img src={formData.aboutImageUrl} alt="Prévia da seção Sobre" className="h-28 w-full max-w-xs rounded-lg object-cover" />
              </div>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="about-highlight-title">Destaque</Label>
                <Input id="about-highlight-title" value={formData.aboutHighlightTitle} onChange={(event) => updateField("aboutHighlightTitle", event.target.value)} />
              </div>
              <div>
                <Label htmlFor="about-highlight-description">Descrição do destaque</Label>
                <Input id="about-highlight-description" value={formData.aboutHighlightDescription} onChange={(event) => updateField("aboutHighlightDescription", event.target.value)} />
              </div>
            </div>
            <Button type="submit" className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]" disabled={isLoading || updateContent.isPending}>
              {updateContent.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar seção Sobre"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function ProfessionalMultiSelect({
  professionals,
  value,
  onChange,
}: {
  professionals: Professional[];
  value: number[];
  onChange: (ids: number[]) => void;
}) {
  return (
    <div className="space-y-2 rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.008_80)] p-3">
      <div>
        <Label>Barbeiros que atendem este serviço</Label>
        <p className="mt-1 text-xs text-muted-foreground">Selecione um ou mais barbeiros. Se nenhum for selecionado, o cliente verá apenas “Sem preferência”.</p>
      </div>
      {professionals.length === 0 ? (
        <p className="text-sm text-muted-foreground">Cadastre barbeiros na aba Barbeiros primeiro.</p>
      ) : (
        <div className="grid gap-2 sm:grid-cols-2">
          {professionals.map((professional) => (
            <label key={professional.id} className="flex cursor-pointer items-center gap-2 rounded-lg border border-transparent px-2 py-2 text-sm hover:border-[oklch(0.86_0.025_75)] hover:bg-white">
              <input
                type="checkbox"
                checked={value.includes(professional.id)}
                onChange={(event) => onChange(event.target.checked ? Array.from(new Set([...value, professional.id])) : value.filter((id) => id !== professional.id))}
                className="h-4 w-4 accent-[oklch(0.63_0.12_53)]"
              />
              <span className="min-w-0 truncate">{professional.name}{professional.specialty ? ` · ${professional.specialty}` : ""}{professional.active !== 1 ? " (inativo)" : ""}</span>
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

// Services Tab Component
function ServicesTab({ services }: { services: Service[] }) {
  const [isNewServiceOpen, setIsNewServiceOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [formData, setFormData] = useState<{
    name: string;
    description: string;
    defaultPrice: string;
    duration: string;
    benefits: string;
    icon: string;
    priceDisplayMode: "price" | "evaluation";
    discountPercent: string;
    promotionLabel: string;
    sortOrder: string;
    isFeatured: boolean;
    professionalIds: number[];
  }>({
    name: "",
    description: "",
    defaultPrice: "",
    duration: "",
    benefits: "",
    icon: DEFAULT_SERVICE_ICON,
    priceDisplayMode: "price",
    discountPercent: "0",
    promotionLabel: "",
    sortOrder: "0",
    isFeatured: false,
    professionalIds: [],
  });

  const utils = trpc.useUtils();
  const { data: allProfessionals = [] } = trpc.professionals.list.useQuery();
  const { data: editingProfessionalIds, isFetching: isLoadingEditingProfessionals } = trpc.professionals.serviceIds.useQuery(
    { serviceId: editingService?.id ?? 0 },
    { enabled: Boolean(editingService) },
  );

  useEffect(() => {
    if (!editingService || isLoadingEditingProfessionals || !editingProfessionalIds) return;
    setFormData((previous) => {
      const currentIds = previous.professionalIds.join(",");
      const loadedIds = editingProfessionalIds.join(",");
      return currentIds === loadedIds ? previous : { ...previous, professionalIds: editingProfessionalIds };
    });
  }, [editingService?.id, editingProfessionalIds, isLoadingEditingProfessionals]);

  const createService = trpc.services.create.useMutation({
    onSuccess: () => {
      toast.success("Serviço criado com sucesso!");
      utils.services.list.invalidate();
      setIsNewServiceOpen(false);
      resetForm();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateService = trpc.services.update.useMutation({
    onSuccess: () => {
      toast.success("Serviço atualizado com sucesso!", { duration: 3500 });
      utils.services.list.invalidate();
      setEditingService(null);
      resetForm();
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteService = trpc.services.delete.useMutation({
    onSuccess: () => {
      toast.success("Serviço excluído!");
      utils.services.list.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const resetForm = () => {
    setFormData({ name: "", description: "", defaultPrice: "", duration: "", benefits: "", icon: DEFAULT_SERVICE_ICON, priceDisplayMode: "price", discountPercent: "0", promotionLabel: "", sortOrder: "0", isFeatured: false, professionalIds: [] });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.defaultPrice) {
      toast.error("Preencha nome e valor do serviço");
      return;
    }

    const data = {
      name: formData.name,
      description: formData.description || undefined,
      defaultPrice: formData.defaultPrice,
      duration: formData.duration ? parseInt(formData.duration) : undefined,
      benefits: serializeServiceBenefits(formData.benefits) || undefined,
      icon: formData.icon,
      priceDisplayMode: formData.priceDisplayMode,
      discountPercent: Math.min(100, Math.max(0, Number(formData.discountPercent) || 0)),
      promotionLabel: formData.promotionLabel.trim() || null,
      sortOrder: Math.max(0, parseInt(formData.sortOrder, 10) || 0),
      isFeatured: formData.isFeatured ? 1 : 0,
      professionalIds: formData.professionalIds,
    };

    if (editingService) {
      updateService.mutate({ id: editingService.id, ...data });
    } else {
      createService.mutate(data);
    }
  };

  const handleEdit = (service: Service) => {
    setFormData({
      name: service.name,
      description: service.description || "",
      defaultPrice: service.defaultPrice,
      duration: service.duration?.toString() || "",
      benefits: service.benefits || "",
      icon: service.icon || DEFAULT_SERVICE_ICON,
      priceDisplayMode: (service.priceDisplayMode as "price" | "evaluation") || "price",
      discountPercent: String(service.discountPercent || 0),
      promotionLabel: service.promotionLabel || "",
      sortOrder: String(service.sortOrder || 0),
      isFeatured: service.isFeatured === 1,
      professionalIds: [],
    });
    setEditingService(service);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="border-none shadow-sm">
        <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
            Gerenciar Serviços
          </CardTitle>
          <Dialog open={isNewServiceOpen} onOpenChange={setIsNewServiceOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">
                <Plus className="h-4 w-4 mr-2" />
                Novo Serviço
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Novo Serviço</DialogTitle>
                <DialogDescription>
                  Cadastre um novo serviço com seu valor padrão
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label>Nome do Serviço *</Label>
                  <Input
                    placeholder="Ex: Massagem Relaxante"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Descrição</Label>
                  <Textarea
                    placeholder="Descrição do serviço..."
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <Label>Valor Padrão (R$) *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={formData.defaultPrice}
                      onChange={(e) => setFormData(prev => ({ ...prev, defaultPrice: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label>Duração (min)</Label>
                    <Input
                      type="number"
                      placeholder="60"
                      value={formData.duration}
                      onChange={(e) => setFormData(prev => ({ ...prev, duration: e.target.value }))}
                    />
                  </div>
                </div>
                <div className="rounded-2xl border border-[#e7c5cb] bg-[#f8f2e9] p-4">
                  <p className="mb-3 text-sm font-semibold text-[#8f5a35]">Promoção do serviço</p>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div><Label>Desconto (%)</Label><Input type="number" min="0" max="100" step="1" value={formData.discountPercent} onChange={(e) => setFormData(prev => ({ ...prev, discountPercent: e.target.value }))} placeholder="Ex.: 15" /></div>
                    <div><Label>Nome da promoção</Label><Input value={formData.promotionLabel} onChange={(e) => setFormData(prev => ({ ...prev, promotionLabel: e.target.value }))} placeholder="Ex.: Semana do corte" /></div>
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">A promoção aparecerá em destaque nos cards públicos quando o desconto for maior que zero.</p>
                </div>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div><Label>Ordem de exibição</Label><Input type="number" min="0" step="1" value={formData.sortOrder} onChange={(e) => setFormData(prev => ({ ...prev, sortOrder: e.target.value }))} /><p className="mt-1 text-xs text-muted-foreground">Menores números aparecem primeiro.</p></div>
                  <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-[#d8cbbd] bg-white p-3"><input type="checkbox" checked={formData.isFeatured} onChange={(e) => setFormData(prev => ({ ...prev, isFeatured: e.target.checked }))} className="mt-1 h-4 w-4 accent-[oklch(0.63_0.12_53)]" /><span><span className="block text-sm font-semibold text-[#624e51]">Fixar em destaque</span><span className="mt-1 block text-xs text-muted-foreground">Este serviço ficará no topo visualmente destacado.</span></span></label>
                </div>
                <div>
                  <Label>Benefícios</Label>
                  <Textarea
                    rows={4}
                    placeholder="Um benefício por linha"
                    value={formData.benefits}
                    onChange={(e) => setFormData(prev => ({ ...prev, benefits: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Exibição de Preço na Página Inicial</Label>
                  <Select value={formData.priceDisplayMode} onValueChange={(mode: "price" | "evaluation") => setFormData(prev => ({ ...prev, priceDisplayMode: mode }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="price">Exibir valor (R$)</SelectItem>
                      <SelectItem value="evaluation">Exibir "Agendar uma avaliação"</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-1 items-end gap-4 sm:grid-cols-[1fr_auto]">
                  <div>
                    <Label>Ícone do serviço</Label>
                    <Select value={formData.icon} onValueChange={(icon) => setFormData(prev => ({ ...prev, icon }))}>
                      <SelectTrigger><SelectValue placeholder="Escolha um ícone" /></SelectTrigger>
                      <SelectContent>
                        {SERVICE_ICON_OPTIONS.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[oklch(0.93_0.03_75)] text-[oklch(0.63_0.12_53)]">
                    {(() => { const Icon = serviceIconByKey[formData.icon] ?? Sparkles; return <Icon className="h-5 w-5" />; })()}
                  </div>
                </div>
                <ProfessionalMultiSelect professionals={allProfessionals} value={formData.professionalIds} onChange={(professionalIds) => setFormData((previous) => ({ ...previous, professionalIds }))} />
                <DialogFooter className="sticky bottom-0 -mx-6 -mb-6 border-t bg-background/95 px-6 py-4 backdrop-blur">
                  <Button
                    type="submit"
                    className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]"
                    disabled={createService.isPending}
                  >
                    {createService.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      "Criar Serviço"
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          {services.length === 0 ? (
            <p className="text-center text-[oklch(0.43_0.025_70)] py-8">
              Nenhum serviço cadastrado. Clique em "Novo Serviço" para começar.
            </p>
          ) : (
            <div className="space-y-3">
              {services.map((service) => (
                <div
                  key={service.id}
                  className={`flex flex-col gap-4 rounded-lg border p-4 sm:flex-row sm:items-center sm:justify-between ${service.isFeatured === 1 ? "border-[oklch(0.63_0.12_53)] bg-[oklch(0.96_0.02_75)] shadow-[0_8px_24px_rgba(200,164,93,0.14)]" : "border-[oklch(0.94_0.035_15)] bg-[oklch(0.96_0.02_75)]"}`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      {(() => { const Icon = serviceIconByKey[service.icon] ?? Sparkles; return <Icon className="h-4 w-4 text-[oklch(0.63_0.12_53)]" />; })()}
                      <h4 className="text-lg text-[oklch(0.22_0.025_70)]" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>{service.name}</h4>
                      {service.isFeatured === 1 ? <Badge className="bg-[oklch(0.63_0.12_53)] text-white">Serviço em destaque</Badge> : null}
                      <span className="text-xs text-muted-foreground">Ordem: {service.sortOrder ?? 0}</span>
                    </div>
                    {service.description && (
                      <p className="text-sm text-[oklch(0.43_0.025_70)]">{service.description}</p>
                    )}
                    {service.benefits && (
                      <p className="mt-1 text-xs text-[oklch(0.43_0.025_70)]">Benefícios: {service.benefits.split(/\r?\n/).filter(Boolean).join(" · ")}</p>
                    )}
                    <div className="flex flex-wrap items-center gap-4 mt-1 text-sm">
                      <span className="text-[oklch(0.63_0.12_53)] font-medium">
                        {service.priceDisplayMode === "evaluation" ? "Agendar uma avaliação" : service.discountPercent ? <><span className="mr-2 text-xs text-muted-foreground line-through">R$ {service.defaultPrice}</span>R$ {(Number(service.defaultPrice) * (1 - service.discountPercent / 100)).toFixed(2)}</> : `R$ ${service.defaultPrice}`}
                      </span>
                      {service.discountPercent ? <Badge className="bg-rose-100 text-rose-700">{service.promotionLabel || "Promoção"} · -{service.discountPercent}%</Badge> : null}
                      {service.duration && (
                        <span className="text-[oklch(0.43_0.025_70)]">
                          {service.duration} min
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleEdit(service)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Excluir Serviço</AlertDialogTitle>
                          <AlertDialogDescription>
                            Tem certeza que deseja excluir "{service.name}"?
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => deleteService.mutate({ id: service.id })}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Excluir
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Service Dialog */}
      <Dialog open={!!editingService} onOpenChange={(open) => !open && setEditingService(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Editar Serviço</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>Nome do Serviço *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <Label>Descrição</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <Label>Valor Padrão (R$) *</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.defaultPrice}
                  onChange={(e) => setFormData(prev => ({ ...prev, defaultPrice: e.target.value }))}
                />
              </div>
              <div>
                <Label>Duração (min)</Label>
                <Input
                  type="number"
                  value={formData.duration}
                  onChange={(e) => setFormData(prev => ({ ...prev, duration: e.target.value }))}
                />
              </div>
            </div>
            <div className="rounded-2xl border border-[#e7c5cb] bg-[#f8f2e9] p-4">
              <p className="mb-3 text-sm font-semibold text-[#8f5a35]">Promoção do serviço</p>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div><Label>Desconto (%)</Label><Input type="number" min="0" max="100" step="1" value={formData.discountPercent} onChange={(e) => setFormData(prev => ({ ...prev, discountPercent: e.target.value }))} placeholder="Ex.: 15" /></div>
                <div><Label>Nome da promoção</Label><Input value={formData.promotionLabel} onChange={(e) => setFormData(prev => ({ ...prev, promotionLabel: e.target.value }))} placeholder="Ex.: Semana do corte" /></div>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">O desconto será exibido em destaque no serviço publicado.</p>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div><Label>Ordem de exibição</Label><Input type="number" min="0" step="1" value={formData.sortOrder} onChange={(e) => setFormData(prev => ({ ...prev, sortOrder: e.target.value }))} /><p className="mt-1 text-xs text-muted-foreground">Menores números aparecem primeiro.</p></div>
              <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-[#d8cbbd] bg-white p-3"><input type="checkbox" checked={formData.isFeatured} onChange={(e) => setFormData(prev => ({ ...prev, isFeatured: e.target.checked }))} className="mt-1 h-4 w-4 accent-[oklch(0.63_0.12_53)]" /><span><span className="block text-sm font-semibold text-[#624e51]">Fixar em destaque</span><span className="mt-1 block text-xs text-muted-foreground">Este serviço ficará no topo visualmente destacado.</span></span></label>
            </div>
            <div>
              <Label>Benefícios</Label>
              <Textarea
                rows={4}
                placeholder="Um benefício por linha"
                value={formData.benefits}
                onChange={(e) => setFormData(prev => ({ ...prev, benefits: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-1 items-end gap-4 sm:grid-cols-[1fr_auto]">
              <div>
                <Label>Ícone do serviço</Label>
                <Select value={formData.icon} onValueChange={(icon) => setFormData(prev => ({ ...prev, icon }))}>
                  <SelectTrigger><SelectValue placeholder="Escolha um ícone" /></SelectTrigger>
                  <SelectContent>
                    {SERVICE_ICON_OPTIONS.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[oklch(0.93_0.03_75)] text-[oklch(0.63_0.12_53)]">
                {(() => { const Icon = serviceIconByKey[formData.icon] ?? Sparkles; return <Icon className="h-5 w-5" />; })()}
              </div>
            </div>
            <ProfessionalMultiSelect professionals={allProfessionals} value={formData.professionalIds} onChange={(professionalIds) => setFormData((previous) => ({ ...previous, professionalIds }))} />
            <DialogFooter className="sticky bottom-0 -mx-6 -mb-6 border-t bg-background/95 px-6 py-4 backdrop-blur">
              <Button
                type="submit"
                className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]"
                disabled={updateService.isPending}
              >
                {updateService.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  "Salvar Alterações"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ProfessionalsTab() {
  const utils = trpc.useUtils();
  const { data: professionals = [], isLoading } = trpc.professionals.list.useQuery();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProfessional, setEditingProfessional] = useState<Professional | null>(null);
  const [formData, setFormData] = useState({ name: "", specialty: "", phone: "", instagramUrl: "", profileSlug: "", coverUrl: "", verified: 1, bio: "", avatarUrl: "" });

  const resetForm = () => setFormData({ name: "", specialty: "", phone: "", instagramUrl: "", profileSlug: "", coverUrl: "", verified: 1, bio: "", avatarUrl: "" });
  const createProfessional = trpc.professionals.create.useMutation({
    onSuccess: () => { toast.success("Barbeiro cadastrado!"); utils.professionals.list.invalidate(); setIsDialogOpen(false); resetForm(); },
    onError: (error) => toast.error(error.message),
  });
  const updateProfessional = trpc.professionals.update.useMutation({
    onSuccess: () => { toast.success("Barbeiro atualizado!"); utils.professionals.list.invalidate(); setEditingProfessional(null); resetForm(); },
    onError: (error) => toast.error(error.message),
  });
  const deleteProfessional = trpc.professionals.delete.useMutation({
    onSuccess: () => { toast.success("Barbeiro excluído definitivamente."); utils.professionals.list.invalidate(); utils.services.list.invalidate(); },
    onError: (error) => toast.error(error.message),
  });
  const uploadAvatar = trpc.professionals.uploadAvatar.useMutation({
    onSuccess: ({ url }) => { setFormData((previous) => ({ ...previous, avatarUrl: url })); toast.success("Foto enviada com sucesso."); },
    onError: (error) => toast.error(error.message),
  });
  const uploadCover = trpc.professionals.uploadCover.useMutation({
    onSuccess: ({ url }) => { setFormData((previous) => ({ ...previous, coverUrl: url })); toast.success("Capa enviada com sucesso."); },
    onError: (error) => toast.error(error.message),
  });
  const removeAvatar = trpc.professionals.removeAvatar.useMutation({
    onSuccess: () => {
      setFormData((previous) => ({ ...previous, avatarUrl: "" }));
      utils.professionals.list.invalidate();
      toast.success("Foto removida com sucesso.");
    },
    onError: (error) => toast.error(error.message),
  });

  const openCreate = () => { setEditingProfessional(null); resetForm(); setIsDialogOpen(true); };
  const openEdit = (professional: Professional) => {
    setEditingProfessional(professional);
    setFormData({ name: professional.name, specialty: professional.specialty || "", phone: professional.phone || "", instagramUrl: professional.instagramUrl || "", profileSlug: professional.profileSlug || "", coverUrl: professional.coverUrl || "", verified: professional.verified ?? 1, bio: professional.bio || "", avatarUrl: professional.avatarUrl || "" });
  };
  const handleAvatarUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) { toast.error("Envie uma imagem JPG, PNG ou WEBP."); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || "");
      const dataBase64 = dataUrl.split(",")[1];
      if (!dataBase64) { toast.error("Não foi possível ler a imagem."); return; }
      uploadAvatar.mutate({ fileName: file.name, contentType: file.type as "image/jpeg" | "image/png" | "image/webp", dataBase64 });
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  };

  const handleCoverUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) { toast.error("Envie uma imagem JPG, PNG ou WEBP."); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const dataBase64 = String(reader.result || "").split(",")[1];
      if (!dataBase64) { toast.error("Não foi possível ler a imagem."); return; }
      uploadCover.mutate({ fileName: file.name, contentType: file.type as "image/jpeg" | "image/png" | "image/webp", dataBase64 });
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  };
  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!formData.name.trim()) { toast.error("Informe o nome do barbeiro."); return; }
    if (editingProfessional) updateProfessional.mutate({ id: editingProfessional.id, ...formData, active: editingProfessional.active });
    else createProfessional.mutate(formData);
  };

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <Card className="border-none shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div><CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Barbeiros</CardTitle><p className="mt-1 text-sm text-muted-foreground">Cadastre a equipe e depois vincule cado barbeiro aos serviços que realiza.</p></div>
          <Button onClick={openCreate} className="shrink-0 bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]"><Plus className="mr-2 h-4 w-4" />Novo barbeiro</Button>
        </CardHeader>
        <CardContent>
          {isLoading ? <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-[oklch(0.63_0.12_53)]" /></div> : professionals.length === 0 ? <div className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">Nenhum barbeiro cadastrado.</div> : <div className="grid gap-4 md:grid-cols-2">{professionals.map((professional) => <div key={professional.id} className="rounded-2xl border border-[oklch(0.86_0.025_75)] bg-white p-5 shadow-sm"><div className="flex items-start justify-between gap-3"><div className="flex min-w-0 items-center gap-3">{professional.avatarUrl ? <img src={professional.avatarUrl} alt={professional.name} className="h-12 w-12 rounded-full object-cover" /> : <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[oklch(0.93_0.03_75)] text-[oklch(0.63_0.12_53)]"><User className="h-5 w-5" /></div>}<div className="min-w-0"><p className="truncate font-semibold">{professional.name}</p><p className="truncate text-sm text-muted-foreground">{professional.specialty || "Barbeiro da barbearia"}</p></div></div><Badge className={professional.active === 1 ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-600"}>{professional.active === 1 ? "Ativo" : "Inativo"}</Badge></div>{professional.bio && <p className="mt-4 line-clamp-3 text-sm leading-6 text-muted-foreground">{professional.bio}</p>}{professional.phone && <p className="mt-3 text-xs text-muted-foreground">Telefone: {professional.phone}</p>}{professional.instagramUrl && <p className="mt-2 inline-flex items-center gap-1.5 text-xs text-[oklch(0.63_0.12_53)]"><Instagram className="h-3.5 w-3.5" /> Instagram cadastrado</p>}<div className="mt-4 flex flex-wrap gap-2"><a href={`/barbeiro/${professional.profileSlug || professional.id}`} target="_blank" rel="noreferrer" className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[oklch(0.76_0.09_5)] px-3 text-sm font-medium text-[oklch(0.50_0.12_45)] transition hover:bg-[oklch(0.95_0.02_75)]"><ArrowUpRight className="h-4 w-4" />Perfil público</a><Button variant="outline" size="sm" onClick={() => openEdit(professional)}><Edit className="mr-2 h-4 w-4" />Editar</Button><AlertDialog><AlertDialogTrigger asChild><Button variant="outline" size="sm" className="text-red-600"><Trash2 className="mr-2 h-4 w-4" />Excluir</Button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Excluir barbeiro?</AlertDialogTitle><AlertDialogDescription>O barbeiro será removido definitivamente dos serviços vinculados. Os agendamentos anteriores serão mantidos, mas ficarão sem barbeiro atribuído.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => deleteProfessional.mutate({ id: professional.id })}>Excluir definitivamente</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog></div></div>)}</div>}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen || Boolean(editingProfessional)} onOpenChange={(open) => { if (!open) { setIsDialogOpen(false); setEditingProfessional(null); resetForm(); } }}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editingProfessional ? "Editar barbeiro" : "Novo barbeiro"}</DialogTitle><DialogDescription>Esses dados ficam disponíveis para os serviços vinculados e para a escolha do cliente.</DialogDescription></DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div><Label>Nome *</Label><Input value={formData.name} onChange={(event) => setFormData((previous) => ({ ...previous, name: event.target.value }))} placeholder="Nome completo" /></div>
            <div className="grid gap-4 sm:grid-cols-2"><div><Label>Especialidade</Label><Input value={formData.specialty} onChange={(event) => setFormData((previous) => ({ ...previous, specialty: event.target.value }))} placeholder="Ex.: Fisioterapia" /></div><div><Label>Telefone</Label><Input value={formData.phone} onChange={(event) => setFormData((previous) => ({ ...previous, phone: event.target.value }))} placeholder="(54) 99999-9999" /></div></div>
            <div><Label>Instagram</Label><Input value={formData.instagramUrl} onChange={(event) => setFormData((previous) => ({ ...previous, instagramUrl: event.target.value }))} placeholder="https://instagram.com/seu perfil ou @usuario" /><p className="mt-1 text-xs text-muted-foreground">Esse link aparecerá no perfil público do barbeiro.</p></div>
            <div className="grid gap-4 sm:grid-cols-2"><div><Label>URL do perfil</Label><Input value={formData.profileSlug} onChange={(event) => setFormData((previous) => ({ ...previous, profileSlug: event.target.value }))} placeholder="ketlen-antunes" /><p className="mt-1 text-xs text-muted-foreground">A página ficará em /barbeiro/ketlen-antunes.</p></div><label className="flex items-center gap-3 rounded-xl border border-[#d8cbbd] bg-[#f8f2e9] px-3 py-2 text-sm"><input type="checkbox" checked={formData.verified === 1} onChange={(event) => setFormData((previous) => ({ ...previous, verified: event.target.checked ? 1 : 0 }))} className="h-4 w-4 accent-[#198fe0]" /><span><strong>Perfil verificado</strong><small className="block text-xs text-muted-foreground">Exibe o selo azul no perfil público.</small></span></label></div>
            <div className="space-y-2"><Label>Capa do perfil</Label><div className="overflow-hidden rounded-xl border border-[#d8cbbd] bg-[#f5dfd6]">{formData.coverUrl ? <img src={formData.coverUrl} alt="Pré-visualização da capa" className="h-28 w-full object-cover" /> : <div className="flex h-28 items-center justify-center text-sm text-muted-foreground">Nenhuma capa definida</div>}</div><label className="inline-flex cursor-pointer items-center rounded-lg border border-[oklch(0.76_0.09_5)] px-3 py-2 text-sm font-medium text-[oklch(0.50_0.12_45)] transition hover:bg-[oklch(0.95_0.02_75)]">{uploadCover.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}Enviar capa<input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={handleCoverUpload} disabled={uploadCover.isPending} /></label><p className="text-xs text-muted-foreground">Prefira uma imagem horizontal, semelhante a 16:9.</p></div>
            <div className="space-y-2"><Label>Foto do barbeiro</Label><div className="flex flex-wrap items-center gap-3">{formData.avatarUrl ? <img src={formData.avatarUrl} alt="Pré-visualização do barbeiro" className="h-14 w-14 rounded-full object-cover" /> : <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[oklch(0.93_0.03_75)] text-[oklch(0.63_0.12_53)]"><User className="h-5 w-5" /></div>}<label className="inline-flex cursor-pointer items-center rounded-lg border border-[oklch(0.76_0.09_5)] px-3 py-2 text-sm font-medium text-[oklch(0.50_0.12_45)] transition hover:bg-[oklch(0.95_0.02_75)]">{uploadAvatar.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}Enviar foto<input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={handleAvatarUpload} disabled={uploadAvatar.isPending || removeAvatar.isPending} /></label>{editingProfessional && formData.avatarUrl && (<AlertDialog><AlertDialogTrigger asChild><Button type="button" variant="outline" size="sm" className="text-red-600" disabled={removeAvatar.isPending}><X className="mr-2 h-4 w-4" />{removeAvatar.isPending ? "Removendo..." : "Remover foto"}</Button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Remover foto do barbeiro?</AlertDialogTitle><AlertDialogDescription>A foto será removida do perfil, da equipe e dos serviços. O cadastro do barbeiro continuará ativo.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => removeAvatar.mutate({ id: editingProfessional.id })}>Remover foto</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog>)}</div><p className="text-xs text-muted-foreground">Formatos aceitos: JPG, PNG ou WEBP. Você pode remover a foto sem excluir o barbeiro.</p></div>
            <div><Label>Mini bio</Label><Textarea rows={4} value={formData.bio} onChange={(event) => setFormData((previous) => ({ ...previous, bio: event.target.value }))} placeholder="Apresentação breve do barbeiro" /></div>
            <DialogFooter><Button type="submit" disabled={createProfessional.isPending || updateProfessional.isPending} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">{createProfessional.isPending || updateProfessional.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar barbeiro"}</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function MyUserTab() {
  const { admin, logout } = useAdminAuth();
  const utils = trpc.useUtils();
  const { data: workspace, isLoading } = trpc.adminAuth.workspace.useQuery();
  const { data: connections = [] } = trpc.adminAuth.connections.useQuery();
  const { data: allServices = [] } = trpc.services.list.useQuery();
  const [profileForm, setProfileForm] = useState({ name: "", username: "", email: "" });
  const [publicForm, setPublicForm] = useState({ bio: "", address: "", instagramUrl: "", profileSlug: "", avatarUrl: "", coverUrl: "" });
  const [serviceIds, setServiceIds] = useState<number[]>([]);
  const [passwordForm, setPasswordForm] = useState({ currentPassword: "", newPassword: "", confirmPassword: "" });
  useEffect(() => {
    if (!workspace) return;
    setProfileForm({ name: workspace.admin.name || "", username: workspace.admin.username || "", email: workspace.admin.email || "" });
    setPublicForm({ bio: workspace.professional?.bio || "", address: workspace.professional?.address || "", instagramUrl: workspace.professional?.instagramUrl || "", profileSlug: workspace.professional?.profileSlug || workspace.admin.username || "", avatarUrl: workspace.professional?.avatarUrl || "", coverUrl: workspace.professional?.coverUrl || "" });
    setServiceIds(workspace.services.map((service) => service.id));
  }, [workspace]);
  const updateProfile = trpc.adminAuth.updateProfile.useMutation({ onSuccess: () => { toast.success("Dados da conta atualizados."); utils.adminAuth.me.invalidate(); utils.adminAuth.workspace.invalidate(); }, onError: (error) => toast.error(error.message) });
  const updateOwnProfile = trpc.adminAuth.updateOwnProfile.useMutation({ onSuccess: () => { toast.success("Perfil público atualizado."); utils.adminAuth.workspace.invalidate(); }, onError: (error) => toast.error(error.message) });
  const changePassword = trpc.adminAuth.changePassword.useMutation({ onSuccess: () => { toast.success("Senha alterada com sucesso."); setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" }); }, onError: (error) => toast.error(error.message) });
  const acceptProfile = trpc.adminAuth.acceptProfile.useMutation({ onSuccess: () => { toast.success("Perfil aceito e publicado."); utils.adminAuth.workspace.invalidate(); }, onError: (error) => toast.error(error.message) });
  const uploadAvatar = trpc.adminAuth.uploadOwnAvatar.useMutation({ onSuccess: ({ url }) => setPublicForm((previous) => ({ ...previous, avatarUrl: url })), onError: (error) => toast.error(error.message) });
  const uploadCover = trpc.adminAuth.uploadOwnCover.useMutation({ onSuccess: ({ url }) => setPublicForm((previous) => ({ ...previous, coverUrl: url })), onError: (error) => toast.error(error.message) });
  const deleteAccount = trpc.adminAuth.deleteAccount.useMutation({ onSuccess: async () => { toast.success("Sua conta foi excluída."); await logout(); }, onError: (error) => toast.error(error.message) });
  const readImage = (file: File, callback: (dataBase64: string, contentType: "image/jpeg" | "image/png" | "image/webp") => void) => {
    if (!file.type.match(/^image\/(jpeg|png|webp)$/)) { toast.error("Escolha uma imagem JPG, PNG ou WebP."); return; }
    const reader = new FileReader(); reader.onload = () => callback(String(reader.result).split(",")[1] || "", file.type as "image/jpeg" | "image/png" | "image/webp"); reader.readAsDataURL(file);
  };
  if (isLoading) return <div className="flex justify-center py-16"><Loader2 className="h-7 w-7 animate-spin text-[oklch(0.63_0.12_53)]" /></div>;
  const professional = workspace?.professional;
  const saveAccount = (event: React.FormEvent) => { event.preventDefault(); if (!profileForm.name.trim() || !profileForm.username.trim()) return toast.error("Informe nome e nome de usuário."); updateProfile.mutate({ name: profileForm.name.trim(), username: profileForm.username.trim(), email: profileForm.email.trim() || null }); };
  const savePublic = (event: React.FormEvent) => { event.preventDefault(); if (!professional) return toast.error("Seu usuário ainda não possui um perfil barbeiro."); updateOwnProfile.mutate({ ...publicForm, bio: publicForm.bio || null, address: publicForm.address || null, instagramUrl: publicForm.instagramUrl || null, avatarUrl: publicForm.avatarUrl || null, coverUrl: publicForm.coverUrl || null, serviceIds }); };
  const savePassword = (event: React.FormEvent) => { event.preventDefault(); if (passwordForm.newPassword.length < 8 || passwordForm.newPassword !== passwordForm.confirmPassword) return toast.error("Confira a nova senha e sua confirmação."); changePassword.mutate({ currentPassword: passwordForm.currentPassword, newPassword: passwordForm.newPassword }); };
  return <div className="mx-auto max-w-6xl space-y-6">
    <div><p className="text-xs font-bold uppercase tracking-[0.2em] text-[oklch(0.63_0.12_53)]">Conta pessoal</p><h2 className="mt-2 font-serif text-4xl text-[oklch(0.22_0.025_70)]">Meu Usuário</h2><p className="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">Gerencie seus dados de acesso e o perfil público que aparece na Gb Barbearia.</p></div>
    <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
      <Card className="border-none shadow-sm"><CardHeader><CardTitle className="flex items-center gap-2"><User className="h-5 w-5 text-[oklch(0.63_0.12_53)]" />Dados da conta</CardTitle></CardHeader><CardContent><form onSubmit={saveAccount} className="space-y-4"><div><Label>Nome de exibição *</Label><Input value={profileForm.name} onChange={(event) => setProfileForm((previous) => ({ ...previous, name: event.target.value }))} /></div><div><Label>Nome de usuário / URL pública *</Label><Input value={profileForm.username} onChange={(event) => setProfileForm((previous) => ({ ...previous, username: event.target.value }))} /><p className="mt-1 text-xs text-muted-foreground">Ao alterar, o slug do seu perfil público também é sincronizado.</p></div><div><Label><Mail className="mr-1 inline h-4 w-4" />Email</Label><Input type="email" value={profileForm.email} onChange={(event) => setProfileForm((previous) => ({ ...previous, email: event.target.value }))} /></div><div className="rounded-lg bg-[oklch(0.96_0.02_75)] p-3 text-sm text-muted-foreground">Acesso: <strong className="text-[oklch(0.35_0.035_10)]">{admin?.role === "admin" ? "Administrador" : "Barbeiro"}</strong></div><Button type="submit" disabled={updateProfile.isPending} className="w-full bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">{updateProfile.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar dados da conta"}</Button></form></CardContent></Card>
      <Card className="border-none shadow-sm"><CardHeader><CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5 text-[oklch(0.63_0.12_53)]" />Segurança</CardTitle></CardHeader><CardContent><form onSubmit={savePassword} className="space-y-4"><div><Label>Senha atual *</Label><Input type="password" value={passwordForm.currentPassword} onChange={(event) => setPasswordForm((previous) => ({ ...previous, currentPassword: event.target.value }))} /></div><div><Label>Nova senha *</Label><Input type="password" value={passwordForm.newPassword} onChange={(event) => setPasswordForm((previous) => ({ ...previous, newPassword: event.target.value }))} placeholder="Mínimo de 8 caracteres" /></div><div><Label>Confirmar nova senha *</Label><Input type="password" value={passwordForm.confirmPassword} onChange={(event) => setPasswordForm((previous) => ({ ...previous, confirmPassword: event.target.value }))} /></div><Button type="submit" variant="outline" disabled={changePassword.isPending} className="w-full border-[oklch(0.76_0.09_5)] text-[oklch(0.50_0.12_45)]">Alterar senha</Button></form><div className="mt-6 border-t pt-4"><p className="mb-3 flex items-center gap-2 text-sm font-semibold"><History className="h-4 w-4" />Últimas conexões</p>{connections.length === 0 ? <p className="text-sm text-muted-foreground">Nenhuma conexão registrada ainda.</p> : <div className="space-y-2">{connections.slice(0, 5).map((connection) => <div key={connection.id} className="rounded-lg bg-muted/40 p-3 text-xs"><div className="flex items-center justify-between gap-2"><span>{connection.disconnectedAt ? "Encerrada" : "Conexão ativa"}</span><span className="text-muted-foreground">{new Date(connection.lastSeenAt).toLocaleString("pt-BR")}</span></div><p className="mt-1 text-muted-foreground">{connection.ipAddress || "IP não identificado"}</p></div>)}</div>}</div></CardContent></Card>
    </div>
    <Card className="border-none shadow-sm"><CardHeader><CardTitle className="flex items-center justify-between gap-3"><span className="flex items-center gap-2"><ExternalLink className="h-5 w-5 text-[oklch(0.63_0.12_53)]" />Editar perfil público</span>{professional?.profileAccepted ? <Badge className="bg-emerald-100 text-emerald-800"><Check className="mr-1 h-3 w-3" />Perfil aceito</Badge> : <Button type="button" size="sm" variant="outline" onClick={() => acceptProfile.mutate()} disabled={acceptProfile.isPending}>Aceitar meu perfil</Button>}</CardTitle></CardHeader><CardContent><form onSubmit={savePublic} className="space-y-5"><div className="grid gap-4 md:grid-cols-2"><div><Label>Descrição pública</Label><Textarea rows={5} value={publicForm.bio} onChange={(event) => setPublicForm((previous) => ({ ...previous, bio: event.target.value }))} placeholder="Apresente seu trabalho e sua abordagem." /></div><div className="space-y-4"><div><Label><MapPin className="mr-1 inline h-4 w-4" />Endereço exibido no Google Maps</Label><Input value={publicForm.address} onChange={(event) => setPublicForm((previous) => ({ ...previous, address: event.target.value }))} placeholder="Rua, número, bairro, Marau - RS" /></div><div><Label><Instagram className="mr-1 inline h-4 w-4" />Instagram</Label><Input value={publicForm.instagramUrl} onChange={(event) => setPublicForm((previous) => ({ ...previous, instagramUrl: event.target.value }))} placeholder="https://instagram.com/usuario" /></div><div><Label><Link2 className="mr-1 inline h-4 w-4" />Slug do perfil público</Label><Input value={publicForm.profileSlug} onChange={(event) => setPublicForm((previous) => ({ ...previous, profileSlug: event.target.value }))} /></div></div></div><div className="grid gap-4 md:grid-cols-2"><div className="rounded-xl border border-dashed p-4"><Label>Foto de perfil</Label><div className="mt-3 flex items-center gap-4"><img src={publicForm.avatarUrl || "/placeholder-avatar.svg"} className="h-20 w-20 rounded-full object-cover" onError={(event) => { event.currentTarget.style.visibility = "hidden"; }} /><label className="inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-muted"><Upload className="h-4 w-4" />Enviar foto<input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(event) => { const file = event.target.files?.[0]; if (file) readImage(file, (dataBase64, contentType) => uploadAvatar.mutate({ dataBase64, contentType })); }} /></label></div></div><div className="rounded-xl border border-dashed p-4"><Label>Capa do perfil</Label><div className="mt-3 flex items-center gap-4">{publicForm.coverUrl ? <img src={publicForm.coverUrl} className="h-16 w-28 rounded-lg object-cover" /> : <div className="h-16 w-28 rounded-lg bg-muted" />}<label className="inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-muted"><Upload className="h-4 w-4" />Enviar capa<input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(event) => { const file = event.target.files?.[0]; if (file) readImage(file, (dataBase64, contentType) => uploadCover.mutate({ dataBase64, contentType })); }} /></label></div></div></div><div><Label>Serviços apresentados no perfil</Label><div className="mt-2 flex flex-wrap gap-2">{allServices.map((service) => <button type="button" key={service.id} onClick={() => setServiceIds((previous) => previous.includes(service.id) ? previous.filter((id) => id !== service.id) : [...previous, service.id])} className={`rounded-full border px-3 py-1.5 text-sm transition ${serviceIds.includes(service.id) ? "border-[oklch(0.63_0.12_53)] bg-[oklch(0.96_0.04_10)] text-[oklch(0.42_0.12_5)]" : "text-muted-foreground hover:bg-muted"}`}>{serviceIds.includes(service.id) ? "✓ " : ""}{service.name}</button>)}</div></div><div className="flex flex-wrap items-center justify-between gap-3"><p className="text-sm text-muted-foreground">Seu perfil: <strong>/barbeiro/{publicForm.profileSlug || "..."}</strong></p><Button type="submit" disabled={!professional || updateOwnProfile.isPending} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">Salvar perfil público</Button></div></form></CardContent></Card>
    <Card className="border-red-200 shadow-sm"><CardHeader><CardTitle className="flex items-center gap-2 text-red-700"><Trash2 className="h-5 w-5" />Excluir minha conta</CardTitle></CardHeader><CardContent className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><p className="max-w-2xl text-sm leading-6 text-muted-foreground">A exclusão remove definitivamente seu acesso ao painel, mas preserva os dados históricos da barbearia.</p><AlertDialog><AlertDialogTrigger asChild><Button variant="outline" className="shrink-0 border-red-300 text-red-700 hover:bg-red-50">Excluir minha conta</Button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Excluir sua conta?</AlertDialogTitle><AlertDialogDescription>Você perderá o acesso ao painel imediatamente. Confirme somente se tiver certeza.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Manter conta</AlertDialogCancel><AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => deleteAccount.mutate()} disabled={deleteAccount.isPending}>Excluir definitivamente</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog></CardContent></Card>
  </div>;
}

function AdminUsersTab() {
  const utils = trpc.useUtils();
  const { data: admins = [], isLoading } = trpc.adminAuth.list.useQuery();
  const { data: professionals = [] } = trpc.professionals.list.useQuery();
  const [userForm, setUserForm] = useState({ username: "", name: "", password: "", role: "user", professionalId: "none" });
  const [editingUser, setEditingUser] = useState<{ id: number; username: string; name: string | null; role: string; professionalId: number | null } | null>(null);
  const [editForm, setEditForm] = useState({ username: "", name: "", role: "user", professionalId: "none" });
  const [resettingUser, setResettingUser] = useState<{ id: number; username: string } | null>(null);
  const [resetPasswordForm, setResetPasswordForm] = useState({ newPassword: "", confirmPassword: "" });

  const createUser = trpc.adminAuth.create.useMutation({
    onSuccess: () => {
      toast.success("Usuário criado com sucesso.");
      utils.adminAuth.list.invalidate();
      setUserForm({ username: "", name: "", password: "", role: "user", professionalId: "none" });
    },
    onError: (error) => toast.error(error.message),
  });
  const updateUser = trpc.adminAuth.update.useMutation({
    onSuccess: () => { toast.success("Usuário atualizado."); utils.adminAuth.list.invalidate(); setEditingUser(null); },
    onError: (error) => toast.error(error.message),
  });
  const resetUserPassword = trpc.adminAuth.resetPassword.useMutation({
    onSuccess: () => { toast.success("Senha redefinida."); setResettingUser(null); },
    onError: (error) => toast.error(error.message),
  });
  const deleteUser = trpc.adminAuth.delete.useMutation({
    onSuccess: () => { toast.success("Usuário excluído."); utils.adminAuth.list.invalidate(); },
    onError: (error) => toast.error(error.message),
  });

  const handleCreateUser = (event: React.FormEvent) => {
    event.preventDefault();
    if (!userForm.username.trim() || !userForm.name.trim()) { toast.error("Informe usuário e nome."); return; }
    if (userForm.password.length < 8) { toast.error("A senha precisa ter pelo menos 8 caracteres."); return; }
    createUser.mutate({
      username: userForm.username,
      name: userForm.name,
      password: userForm.password,
      role: userForm.role as "admin" | "user",
      professionalId: userForm.professionalId === "none" ? null : Number(userForm.professionalId),
    });
  };

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-[oklch(0.63_0.12_53)]">Acesso da equipe</p>
        <h2 className="mt-2 font-serif text-4xl text-[oklch(0.22_0.025_70)]">Usuários administrativos</h2>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">Crie acessos paro barbeiros e colaboradores gerenciarem os agendamentos. Somente administradores podem alterar os usuários da equipe.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-none shadow-sm">
          <CardHeader><CardTitle className="flex items-center gap-2" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}><Plus className="h-5 w-5 text-[oklch(0.63_0.12_53)]" />Novo usuário</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={handleCreateUser} className="space-y-4">
              <div><Label>Usuário *</Label><Input value={userForm.username} onChange={(event) => setUserForm((previous) => ({ ...previous, username: event.target.value }))} placeholder="ex.: marina.silva" autoComplete="off" /></div>
              <div><Label>Nome de exibição *</Label><Input value={userForm.name} onChange={(event) => setUserForm((previous) => ({ ...previous, name: event.target.value }))} placeholder="Nome completo" /></div>
              <div><Label>Senha inicial *</Label><Input type="password" value={userForm.password} onChange={(event) => setUserForm((previous) => ({ ...previous, password: event.target.value }))} placeholder="Mínimo de 8 caracteres" autoComplete="new-password" /></div>
              <div><Label>Perfil de acesso</Label><Select value={userForm.role} onValueChange={(role) => setUserForm((previous) => ({ ...previous, role }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="user">Usuário — operação</SelectItem><SelectItem value="admin">Administrador — acesso total</SelectItem></SelectContent></Select></div>
              <div><Label>Vincular o barbeiro</Label><Select value={userForm.professionalId} onValueChange={(professionalId) => setUserForm((previous) => ({ ...previous, professionalId }))}><SelectTrigger><SelectValue placeholder="Sem vínculo específico" /></SelectTrigger><SelectContent><SelectItem value="none">Sem vínculo específico</SelectItem>{professionals.filter((professional) => professional.active === 1).map((professional) => <SelectItem key={professional.id} value={String(professional.id)}>{professional.name}{professional.specialty ? ` · ${professional.specialty}` : ""}</SelectItem>)}</SelectContent></Select></div>
              <Button type="submit" disabled={createUser.isPending} className="w-full bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">{createUser.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Criar usuário"}</Button>
            </form>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader><CardTitle className="flex items-center gap-2" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}><Shield className="h-5 w-5 text-[oklch(0.63_0.12_53)]" />Regra de acesso</CardTitle></CardHeader>
          <CardContent className="space-y-4 text-sm leading-6 text-muted-foreground">
            <p><strong className="text-[oklch(0.35_0.035_10)]">Administrador:</strong> gerencia usuários, barbeiros, serviços, conteúdo da Home e horários da barbearia.</p>
            <p><strong className="text-[oklch(0.35_0.035_10)]">Usuário:</strong> acessa Agenda, Agendamentos Pendentes, Relatórios e Meu Usuário. Não pode alterar configurações da barbearia nem outros usuários.</p>
            <div className="rounded-lg bg-[oklch(0.96_0.02_75)] p-3">As permissões são verificadas também no servidor; ocultar itens no menu não é a única camada de segurança.</div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader><CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Usuários cadastrados</CardTitle></CardHeader>
        <CardContent>
          {isLoading ? <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-[oklch(0.63_0.12_53)]" /></div> : admins.length === 0 ? <p className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">Nenhum usuário administrativo cadastrado.</p> : <div className="grid gap-3 md:grid-cols-2">{admins.map((adminUser) => { const linkedProfessional = professionals.find((professional) => professional.id === adminUser.professionalId); const isAdminUser = adminUser.role === "admin"; return <div key={adminUser.id} className="rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.01_20)] p-4"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="truncate font-semibold text-[oklch(0.22_0.025_70)]">{adminUser.name || adminUser.username}</p><p className="truncate text-sm text-muted-foreground">@{adminUser.username}</p></div><Badge className={isAdminUser ? "bg-violet-100 text-violet-800" : "bg-emerald-100 text-emerald-800"}>{isAdminUser ? "Administrador" : "Usuário"}</Badge></div><p className="mt-3 text-xs text-muted-foreground">{linkedProfessional ? `Barbeiro: ${linkedProfessional.name}` : "Sem vínculo barbeiro"}</p><div className="mt-4 flex flex-wrap gap-2"><Button variant="outline" size="sm" onClick={() => { setEditingUser(adminUser); setEditForm({ username: adminUser.username, name: adminUser.name || "", role: adminUser.role === "admin" ? "admin" : "user", professionalId: adminUser.professionalId ? String(adminUser.professionalId) : "none" }); }}><Edit className="mr-2 h-4 w-4" />Editar</Button><Button variant="outline" size="sm" onClick={() => { setResettingUser(adminUser); setResetPasswordForm({ newPassword: "", confirmPassword: "" }); }}><Shield className="mr-2 h-4 w-4" />Senha</Button><AlertDialog><AlertDialogTrigger asChild><Button variant="outline" size="sm" className="text-red-600"><Trash2 className="mr-2 h-4 w-4" />Excluir</Button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Excluir usuário?</AlertDialogTitle><AlertDialogDescription>O acesso de @{adminUser.username} será removido definitivamente. Agendamentos e dados da barbearia serão preservados.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => deleteUser.mutate({ id: adminUser.id })}>Excluir usuário</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog></div></div>; })}</div>}
        </CardContent>
      </Card>

      <Dialog open={Boolean(editingUser)} onOpenChange={(open) => !open && setEditingUser(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Editar usuário</DialogTitle><DialogDescription>Altere o nome, nome de usuário, perfil e vínculo barbeiro.</DialogDescription></DialogHeader>
          <form onSubmit={(event) => { event.preventDefault(); if (!editingUser) return; if (!editForm.name.trim() || !editForm.username.trim()) { toast.error("Informe nome e nome de usuário."); return; } updateUser.mutate({ id: editingUser.id, username: editForm.username, name: editForm.name, role: editForm.role as "admin" | "user", professionalId: editForm.professionalId === "none" ? null : Number(editForm.professionalId) }); }} className="space-y-4">
            <div><Label>Nome de usuário *</Label><Input value={editForm.username} onChange={(event) => setEditForm((previous) => ({ ...previous, username: event.target.value }))} /></div>
            <div><Label>Nome de exibição *</Label><Input value={editForm.name} onChange={(event) => setEditForm((previous) => ({ ...previous, name: event.target.value }))} /></div>
            <div><Label>Perfil</Label><Select value={editForm.role} onValueChange={(role) => setEditForm((previous) => ({ ...previous, role }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="user">Usuário — operação</SelectItem><SelectItem value="admin">Administrador — acesso total</SelectItem></SelectContent></Select></div>
            <div><Label>Barbeiro vinculado</Label><Select value={editForm.professionalId} onValueChange={(professionalId) => setEditForm((previous) => ({ ...previous, professionalId }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">Sem vínculo específico</SelectItem>{professionals.filter((professional) => professional.active === 1).map((professional) => <SelectItem key={professional.id} value={String(professional.id)}>{professional.name}</SelectItem>)}</SelectContent></Select></div>
            <DialogFooter><Button type="submit" disabled={updateUser.isPending} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">{updateUser.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar alterações"}</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(resettingUser)} onOpenChange={(open) => !open && setResettingUser(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Redefinir senha</DialogTitle><DialogDescription>Defina uma nova senha para @{resettingUser?.username}. O usuário poderá alterá-la depois em Meu Usuário.</DialogDescription></DialogHeader>
          <form onSubmit={(event) => { event.preventDefault(); if (!resettingUser) return; if (resetPasswordForm.newPassword.length < 8) { toast.error("A senha precisa ter pelo menos 8 caracteres."); return; } if (resetPasswordForm.newPassword !== resetPasswordForm.confirmPassword) { toast.error("A confirmação da senha não confere."); return; } resetUserPassword.mutate({ id: resettingUser.id, newPassword: resetPasswordForm.newPassword }); }} className="space-y-4">
            <div><Label>Nova senha *</Label><Input type="password" value={resetPasswordForm.newPassword} onChange={(event) => setResetPasswordForm((previous) => ({ ...previous, newPassword: event.target.value }))} autoComplete="new-password" /></div>
            <div><Label>Confirmar senha *</Label><Input type="password" value={resetPasswordForm.confirmPassword} onChange={(event) => setResetPasswordForm((previous) => ({ ...previous, confirmPassword: event.target.value }))} autoComplete="new-password" /></div>
            <DialogFooter><Button type="submit" disabled={resetUserPassword.isPending} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">{resetUserPassword.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar nova senha"}</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Reports Tab Component
function ReportsTab({ isAdmin, user }: { isAdmin: boolean; user: any }) {
  const [isAllTime, setIsAllTime] = useState(false);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);

  const { data: monthlyReport, isLoading: monthlyLoading } = trpc.reports.monthly.useQuery(
    { year: selectedYear, month: selectedMonth },
    { enabled: !isAdmin }
  );

  const { data: advancedReport, isLoading: advancedLoading } = trpc.reports.advancedGlobal.useQuery(
    { year: isAllTime ? undefined : selectedYear, month: isAllTime ? undefined : selectedMonth, allTime: isAllTime },
    { enabled: isAdmin }
  );

  const report = isAdmin ? advancedReport : monthlyReport;
  const isLoading = isAdmin ? advancedLoading : monthlyLoading;

  const months = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <Card className="border-none shadow-sm">
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[oklch(0.63_0.12_53)]">Análise de Desempenho</p>
              <CardTitle className="mt-1 font-serif text-3xl text-[oklch(0.22_0.025_70)]">
                Relatório {isAdmin ? "Global da Barbearia" : "do Barbeiro"}
              </CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                {isAdmin ? "Visão consolidada de todos os barbeiros, ranking de prestação e serviços." : `Resultados vinculados ao seu perfil barbeiro (${user?.name || user?.username || ""}).`}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex rounded-lg border border-[oklch(0.86_0.025_75)] bg-slate-50 p-1">
                <button
                  type="button"
                  onClick={() => setIsAllTime(false)}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${!isAllTime ? "bg-white text-[oklch(0.63_0.12_53)] shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
                >
                  Por Mês
                </button>
                <button
                  type="button"
                  onClick={() => setIsAllTime(true)}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${isAllTime ? "bg-white text-[oklch(0.63_0.12_53)] shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
                >
                  Todo o Tempo
                </button>
              </div>

              {!isAllTime && (
                <>
                  <Select
                    value={selectedMonth.toString()}
                    onValueChange={(v) => setSelectedMonth(parseInt(v))}
                  >
                    <SelectTrigger className="w-36">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {months.map((month, i) => (
                        <SelectItem key={i} value={(i + 1).toString()}>
                          {month}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select
                    value={selectedYear.toString()}
                    onValueChange={(v) => setSelectedYear(parseInt(v))}
                  >
                    <SelectTrigger className="w-28">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[2024, 2025, 2026, 2027].map((year) => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-[oklch(0.63_0.12_53)]" />
            </div>
          ) : report ? (
            <div className="space-y-8">
              {/* Summary Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-xl bg-[oklch(0.96_0.02_75)] border border-[oklch(0.91_0.03_20)]">
                  <p className="text-xs font-medium uppercase tracking-wider text-[oklch(0.43_0.025_70)]">Total de Agendamentos</p>
                  <p className="text-3xl font-serif mt-1 text-[oklch(0.22_0.025_70)]">
                    {report.totalAppointments}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-emerald-50/80 border border-emerald-100">
                  <p className="text-xs font-medium uppercase tracking-wider text-emerald-700">Confirmados</p>
                  <p className="text-3xl font-serif mt-1 text-emerald-800">
                    {report.confirmedAppointments}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-rose-50/80 border border-rose-100">
                  <p className="text-xs font-medium uppercase tracking-wider text-rose-700">Cancelados</p>
                  <p className="text-3xl font-serif mt-1 text-rose-800">
                    {report.canceledAppointments}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-[oklch(0.94_0.04_15)] border border-[oklch(0.88_0.06_15)]">
                  <p className="text-xs font-medium uppercase tracking-wider text-[oklch(0.50_0.12_45)]">Faturamento</p>
                  <p className="text-3xl font-serif mt-1 text-[oklch(0.38_0.15_5)]">
                    R$ {report.totalRevenue.toFixed(2)}
                  </p>
                </div>
              </div>

              {/* Professional Ranking & Breakdown (Admin only) */}
              {isAdmin && report.byProfessional && report.byProfessional.length > 0 && (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-serif text-[oklch(0.22_0.025_70)]">Ranking de Barbeiros (Prestação de Serviços)</h3>
                    <p className="text-sm text-muted-foreground">Ordem de quem mais prestou atendimentos e gerou receita no período ({isAllTime ? "Todo o Tempo" : `${months[selectedMonth - 1]} de ${selectedYear}`}).</p>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    {report.byProfessional.map((pro, index) => {
                      const maxRevenue = Math.max(...report.byProfessional.map(p => p.revenue), 1);
                      const percentage = Math.round((pro.revenue / maxRevenue) * 100);
                      return (
                        <div key={index} className="rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.01_20)] p-5 space-y-3 relative overflow-hidden">
                          {index === 0 && (
                            <div className="absolute top-0 right-0 bg-[oklch(0.63_0.12_53)] text-white text-[10px] font-bold px-3 py-1 rounded-bl-xl uppercase tracking-wider">
                              1º Lugar
                            </div>
                          )}
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-[oklch(0.63_0.12_53)] text-white text-sm font-bold flex items-center justify-center shrink-0">
                              {index + 1}º
                            </div>
                            <div className="min-w-0 flex-1">
                              <span className="font-semibold text-[oklch(0.22_0.025_70)] text-base block truncate">{pro.name}</span>
                              <span className="text-xs text-[oklch(0.63_0.12_53)] font-medium">Receita: R$ {pro.revenue.toFixed(2)}</span>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground pt-1 border-t border-[oklch(0.93_0.03_15)]">
                            <div>Total de solicitações: <strong className="text-[oklch(0.22_0.025_70)]">{pro.total}</strong></div>
                            <div>Serviços prestados: <strong className="text-emerald-700">{pro.confirmed}</strong></div>
                          </div>
                          {/* Visual progress bar */}
                          <div className="space-y-1">
                            <div className="flex justify-between text-[11px] text-muted-foreground">
                              <span>Participação no faturamento</span>
                              <span>{percentage}%</span>
                            </div>
                            <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                              <div className="h-full bg-[oklch(0.63_0.12_53)] rounded-full transition-all duration-500" style={{ width: `${percentage}%` }} />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Top Services */}
              {report.topServices.length > 0 && (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-serif text-[oklch(0.22_0.025_70)]">Serviços Mais Procurados</h3>
                    <p className="text-sm text-muted-foreground">Serviços com maior volume de agendamentos confirmados no período.</p>
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    {report.topServices.map((service, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between p-4 rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.01_20)]"
                      >
                        <div className="flex items-center gap-3">
                          <span className="w-7 h-7 rounded-full bg-[oklch(0.63_0.12_53)] text-white text-xs font-semibold flex items-center justify-center">
                            {i + 1}
                          </span>
                          <div>
                            <p className="font-medium text-[oklch(0.22_0.025_70)]">{service.name}</p>
                            <p className="text-xs text-muted-foreground">{service.count} agendamentos confirmados</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-semibold text-[oklch(0.38_0.15_5)]">
                            R$ {service.revenue.toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <p className="text-center text-[oklch(0.43_0.025_70)] py-8">
              Nenhum dado disponível para o período selecionado.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function PostsTab({ authorDefaultName }: { authorDefaultName: string }) {
  const utils = trpc.useUtils();
  const { data: posts = [], isLoading } = trpc.posts.list.useQuery();
  const { data: services = [] } = trpc.services.list.useQuery();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<any | null>(null);

  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    summary: "",
    content: "",
    coverImageUrl: "",
    authorName: authorDefaultName || "Equipe Gb Barbearia",
    isPinned: 0,
    isFeatured: 0,
    serviceIds: [] as number[],
  });

  const resetForm = () => {
    setFormData({
      title: "",
      slug: "",
      summary: "",
      content: "",
      coverImageUrl: "",
      authorName: authorDefaultName || "Equipe Gb Barbearia",
      isPinned: 0,
      isFeatured: 0,
      serviceIds: [],
    });
    setEditingPost(null);
  };

  const createPost = trpc.posts.create.useMutation({
    onSuccess: () => {
      toast.success("Postagem publicada com sucesso!");
      utils.posts.list.invalidate();
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error) => toast.error(error.message),
  });

  const updatePost = trpc.posts.update.useMutation({
    onSuccess: () => {
      toast.success("Postagem atualizada com sucesso!");
      utils.posts.list.invalidate();
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error) => toast.error(error.message),
  });

  const deletePost = trpc.posts.delete.useMutation({
    onSuccess: () => {
      toast.success("Postagem excluída.");
      utils.posts.list.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const uploadCover = trpc.posts.uploadCover.useMutation({
    onSuccess: ({ url }) => {
      setFormData((prev) => ({ ...prev, coverImageUrl: url }));
      toast.success("Capa enviada com sucesso.");
    },
    onError: (error) => toast.error(error.message),
  });

  const handleCoverUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      toast.error("Envie uma imagem JPG, PNG ou WEBP.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || "");
      const dataBase64 = dataUrl.split(",")[1];
      if (!dataBase64) {
        toast.error("Não foi possível ler a imagem.");
        return;
      }
      uploadCover.mutate({
        fileName: file.name,
        contentType: file.type as "image/jpeg" | "image/png" | "image/webp",
        dataBase64,
      });
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  };

  const openCreate = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const openEdit = (post: any) => {
    setEditingPost(post);
    setFormData({
      title: post.title,
      slug: post.slug,
      summary: post.summary,
      content: post.content,
      coverImageUrl: post.coverImageUrl || "",
      authorName: post.authorName,
      isPinned: post.isPinned || 0,
      isFeatured: post.isFeatured || 0,
      serviceIds: post.services?.map((s: any) => s.id) || [],
    });
    setIsDialogOpen(true);
  };

  const handleTitleChange = (value: string) => {
    setFormData((prev) => ({
      ...prev,
      title: value,
      slug: editingPost ? prev.slug : value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, ""),
    }));
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!formData.title.trim() || !formData.summary.trim() || !formData.content.trim()) {
      toast.error("Preencha o título, o resumo e o conteúdo da postagem.");
      return;
    }
    if (editingPost) {
      updatePost.mutate({ id: editingPost.id, ...formData });
    } else {
      createPost.mutate(formData);
    }
  };

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <Card className="border-none shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div>
            <CardTitle style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>Gestão de Postagens</CardTitle>
            <p className="mt-1 text-sm text-muted-foreground">Publique artigos, dicas de bem-estar e novidades visíveis na página inicial da barbearia.</p>
          </div>
          <Button onClick={openCreate} className="shrink-0 bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">
            <Plus className="mr-2 h-4 w-4" /> Nova postagem
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-10">
              <Loader2 className="h-6 w-6 animate-spin text-[oklch(0.63_0.12_53)]" />
            </div>
          ) : posts.length === 0 ? (
            <div className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">
              Nenhuma postagem publicada. Clique em "Nova postagem" para começar.
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2">
              {posts.map((post: any) => (
                <div key={post.id} className="rounded-2xl border border-[oklch(0.86_0.025_75)] bg-white p-5 shadow-sm space-y-4 flex flex-col justify-between">
                  <div>
                    {post.coverImageUrl && (
                      <div className="mb-4 h-44 w-full overflow-hidden rounded-xl bg-slate-100">
                        <img src={post.coverImageUrl} alt={post.title} className="h-full w-full object-cover" />
                      </div>
                    )}
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      {post.isPinned === 1 && (
                        <Badge className="bg-[oklch(0.63_0.12_53)] text-white text-[10px]">Fixado no topo</Badge>
                      )}
                      {post.isFeatured === 1 && (
                        <Badge variant="outline" className="border-[oklch(0.63_0.12_53)] text-[oklch(0.63_0.12_53)] text-[10px]">Destacado na Home</Badge>
                      )}
                    </div>
                    <h3 className="font-serif text-xl font-medium text-[oklch(0.22_0.025_70)]">{post.title}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">Por {post.authorName} · {new Date(post.createdAt).toLocaleDateString("pt-BR")}</p>
                    <p className="mt-3 text-sm leading-6 text-[oklch(0.45_0.035_10)] line-clamp-3">{post.summary}</p>
                    {post.services && post.services.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {post.services.map((s: any) => (
                          <Badge key={s.id} variant="outline" className="text-xs bg-[oklch(0.95_0.02_75)] text-[oklch(0.63_0.12_53)] border-[oklch(0.85_0.05_15)]">
                            {s.name}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center justify-between border-t border-[oklch(0.93_0.03_15)] pt-3">
                    <span className="text-xs font-semibold text-[oklch(0.63_0.12_53)]">{post.reactionsCount || 0} reações</span>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => openEdit(post)}>
                        <Edit className="mr-2 h-4 w-4" /> Editar
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="sm" className="text-red-600">
                            <Trash2 className="mr-2 h-4 w-4" /> Excluir
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Excluir postagem?</AlertDialogTitle>
                            <AlertDialogDescription>Esta postagem será removida permanentemente do site.</AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => deletePost.mutate({ id: post.id })}>
                              Excluir
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={(open) => { if (!open) setIsDialogOpen(false); }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPost ? "Editar postagem" : "Nova postagem"}</DialogTitle>
            <DialogDescription>Compartilhe dicas, novidades e informações úteis com as clientes da barbearia.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>Título da postagem *</Label>
              <Input
                value={formData.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                placeholder="Ex: Cuidados essenciais no pós-operatório"
              />
            </div>
            <div>
              <Label>Slug URL *</Label>
              <Input
                value={formData.slug}
                onChange={(e) => setFormData((prev) => ({ ...prev, slug: e.target.value }))}
                placeholder="ex-cuidados-pos-operatorio"
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label>Autor(a) *</Label>
                <Input
                  value={formData.authorName}
                  onChange={(e) => setFormData((prev) => ({ ...prev, authorName: e.target.value }))}
                  placeholder="Nome do barbeiro"
                />
              </div>
              <div>
                <Label>Capa da postagem</Label>
                <div className="flex items-center gap-3 mt-1">
                  {formData.coverImageUrl ? (
                    <img src={formData.coverImageUrl} alt="Capa" className="h-10 w-16 rounded object-cover" />
                  ) : (
                    <div className="flex h-10 w-16 items-center justify-center rounded bg-slate-100 text-xs text-muted-foreground">Sem capa</div>
                  )}
                  <label className="inline-flex cursor-pointer items-center rounded-lg border border-[oklch(0.76_0.09_5)] px-3 py-1.5 text-xs font-medium text-[oklch(0.50_0.12_45)] transition hover:bg-[oklch(0.95_0.02_75)]">
                    {uploadCover.isPending ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Plus className="mr-1.5 h-3.5 w-3.5" />}
                    Enviar capa
                    <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={handleCoverUpload} disabled={uploadCover.isPending} />
                  </label>
                </div>
              </div>
            </div>
            <div>
              <Label>Resumo / Descrição curta *</Label>
              <Textarea
                rows={2}
                value={formData.summary}
                onChange={(e) => setFormData((prev) => ({ ...prev, summary: e.target.value }))}
                placeholder="Breve introdução que aparece na listagem..."
              />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <Label>Conteúdo completo *</Label>
                <span className="text-[11px] text-muted-foreground">Quebras de linha e **negrito** (use **termo**) são preservados</span>
              </div>
              <Textarea
                rows={7}
                value={formData.content}
                onChange={(e) => setFormData((prev) => ({ ...prev, content: e.target.value }))}
                placeholder="Texto integral do artigo ou dica... Cole o texto com seus parágrafos e use **negrito** para destacar."
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2 rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.008_80)] p-4">
              <label className="flex cursor-pointer items-center gap-3">
                <input
                  type="checkbox"
                  checked={formData.isPinned === 1}
                  onChange={(e) => setFormData((prev) => ({ ...prev, isPinned: e.target.checked ? 1 : 0 }))}
                  className="h-4 w-4 rounded border-gray-300 text-[oklch(0.63_0.12_53)] focus:ring-[oklch(0.63_0.12_53)]"
                />
                <div>
                  <span className="text-sm font-medium block">Fixar no topo</span>
                  <span className="text-xs text-muted-foreground">Até 4 artigos no topo da página de artigos.</span>
                </div>
              </label>
              <label className="flex cursor-pointer items-center gap-3">
                <input
                  type="checkbox"
                  checked={formData.isFeatured === 1}
                  onChange={(e) => setFormData((prev) => ({ ...prev, isFeatured: e.target.checked ? 1 : 0 }))}
                  className="h-4 w-4 rounded border-gray-300 text-[oklch(0.63_0.12_53)] focus:ring-[oklch(0.63_0.12_53)]"
                />
                <div>
                  <span className="text-sm font-medium block">Destacar na Home</span>
                  <span className="text-xs text-muted-foreground">Até 2 artigos em destaque na página inicial.</span>
                </div>
              </label>
            </div>
            <div className="space-y-2 rounded-xl border border-[oklch(0.86_0.025_75)] bg-[oklch(0.99_0.008_80)] p-3">
              <Label>Serviços relacionados (referência para agendamento)</Label>
              <p className="text-xs text-muted-foreground">Selecione serviços que a cliente pode agendar diretamente ao ler este artigo.</p>
              {services.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhum serviço cadastrado.</p>
              ) : (
                <div className="grid gap-2 sm:grid-cols-2 mt-2">
                  {services.map((service: any) => (
                    <label key={service.id} className="flex cursor-pointer items-center gap-2 rounded-lg border border-transparent px-2 py-1.5 text-sm hover:border-[oklch(0.86_0.025_75)] hover:bg-white">
                      <input
                        type="checkbox"
                        checked={formData.serviceIds.includes(service.id)}
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setFormData((prev) => ({
                            ...prev,
                            serviceIds: checked ? [...prev.serviceIds, service.id] : prev.serviceIds.filter((id) => id !== service.id),
                          }));
                        }}
                      />
                      <span className="truncate">{service.name}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={createPost.isPending || updatePost.isPending} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">
                {createPost.isPending || updatePost.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar postagem"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}


function RafflesTab({ services }: { services: Service[] }) {
  const utils = trpc.useUtils();
  const rafflesQuery = trpc.raffles.adminList.useQuery();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const participantsQuery = trpc.raffles.participants.useQuery({ raffleId: selectedId || 0 }, { enabled: Boolean(selectedId) });
  const createRaffle = trpc.raffles.create.useMutation({ onSuccess: () => { toast.success("Sorteio ativado no site."); utils.raffles.adminList.invalidate(); utils.raffles.active.invalidate(); utils.raffles.featured.invalidate(); setTitle(""); setDescription(""); setDrawDate(""); setDrawTime(""); setServiceId(""); } });
  const activateRaffle = trpc.raffles.activate.useMutation({ onSuccess: () => { toast.success("Sorteio ativado."); utils.raffles.adminList.invalidate(); utils.raffles.active.invalidate(); utils.raffles.featured.invalidate(); } });
  const finalizeRaffle = trpc.raffles.finalize.useMutation({ onSuccess: () => { toast.success("Sorteio finalizado e resultado publicado."); utils.raffles.adminList.invalidate(); utils.raffles.active.invalidate(); utils.raffles.featured.invalidate(); utils.raffles.list.invalidate(); } });
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [drawDate, setDrawDate] = useState("");
  const [drawTime, setDrawTime] = useState("");
  const [serviceId, setServiceId] = useState("");

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!serviceId || !drawDate || !drawTime) { toast.error("Preencha data, horário e serviço do prêmio."); return; }
    createRaffle.mutate({ title, description: description || undefined, drawDate, drawTime, serviceId: Number(serviceId) });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="text-xs font-bold uppercase tracking-[0.2em] text-[oklch(0.63_0.12_53)]">Campanhas promocionais</p><h2 className="mt-1 font-serif text-3xl">Sorteios</h2><p className="mt-2 text-sm text-muted-foreground">Crie um sorteio, acompanhe os números e publique o resultado com transparência.</p></div><a href="/sorteios" target="_blank" rel="noreferrer" className="text-sm font-semibold text-[oklch(0.63_0.12_53)]">Ver página pública ↗</a></div>
      <Card><CardHeader><CardTitle className="flex items-center gap-2"><Gift className="h-5 w-5 text-[oklch(0.63_0.12_53)]" />Ativar novo sorteio</CardTitle></CardHeader><CardContent><form onSubmit={submit} className="grid gap-4 md:grid-cols-2"><div className="md:col-span-2"><Label>Título</Label><Input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Ex.: Sorteio Corte + Barba" required /></div><div className="md:col-span-2"><Label>Descrição</Label><Textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Explique a campanha para os clientes." rows={3} /></div><div><Label>Data do sorteio</Label><Input type="date" value={drawDate} onChange={(event) => setDrawDate(event.target.value)} required /></div><div><Label>Horário do sorteio</Label><Input type="time" value={drawTime} onChange={(event) => setDrawTime(event.target.value)} required /></div><div><Label>Serviço do prêmio</Label><select value={serviceId} onChange={(event) => setServiceId(event.target.value)} className="mt-1 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" required><option value="">Selecione um serviço</option>{services.map((service) => <option key={service.id} value={service.id}>{service.name}</option>)}</select></div><div className="flex items-end"><Button type="submit" disabled={createRaffle.isPending} className="w-full bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">{createRaffle.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Ativar sorteio no site"}</Button></div></form></CardContent></Card>
      <div className="grid gap-4 lg:grid-cols-2">{rafflesQuery.data?.map((raffle) => <Card key={raffle.id} className={raffle.status === "active" ? "border-[oklch(0.63_0.12_53)]" : ""}><CardContent className="p-5"><div className="flex items-start justify-between gap-3"><div><p className="text-xs uppercase tracking-wider text-muted-foreground">{raffle.status === "active" ? "Ativo no site" : raffle.status === "finalized" ? "Finalizado" : "Encerrado"}</p><h3 className="mt-1 font-serif text-xl">{raffle.title}</h3></div><Gift className="h-5 w-5 text-[oklch(0.63_0.12_53)]" /></div><p className="mt-2 text-sm text-muted-foreground">{raffle.drawDate} às {raffle.drawTime.slice(0, 5)} · {raffle.serviceName}</p><div className="mt-4 grid grid-cols-2 gap-2 text-sm"><span className="rounded-lg bg-muted p-2"><strong>{raffle.participantCount}</strong><br />participantes</span><span className="rounded-lg bg-muted p-2"><strong>{raffle.numberCount}</strong><br />números</span></div>{raffle.winnerNumber && <div className="mt-3 rounded-lg border border-[oklch(0.63_0.12_53)]/40 bg-[oklch(0.96_0.02_75)] p-3 text-sm"><strong>Vencedor publicado</strong><br />Número #{String(raffle.winnerNumber).padStart(3, "0")}{raffle.winnerPhone && <Button asChild size="sm" variant="outline" className="mt-3 ml-auto flex w-fit border-[oklch(0.63_0.12_53)] text-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.63_0.12_53)] hover:text-white"><a href={buildWhatsAppUrl(`Olá, ${raffle.winnerName || "vencedor"}! Parabéns, você foi o sorteado da Gb Barbearia com o número #${String(raffle.winnerNumber).padStart(3, "0")}. Entre em contato para confirmar a data e o horário do seu ${raffle.serviceName}.`, raffle.winnerPhone)} target="_blank" rel="noreferrer"><MessageCircle className="mr-2 h-4 w-4" />Mandar mensagem</a></Button>}</div>}<div className="mt-4 flex flex-wrap gap-2"><Button type="button" variant="outline" size="sm" onClick={() => setSelectedId(selectedId === raffle.id ? null : raffle.id)}>Ver participantes</Button>{raffle.status !== "finalized" && raffle.status !== "active" && <Button type="button" variant="outline" size="sm" onClick={() => activateRaffle.mutate({ id: raffle.id })}>Ativar</Button>}{raffle.status === "active" && <Button type="button" size="sm" className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]" onClick={() => finalizeRaffle.mutate({ id: raffle.id })}>Sortear agora</Button>}</div></CardContent></Card>)}</div>
      {selectedId && <Card><CardHeader><CardTitle>Participantes do sorteio</CardTitle></CardHeader><CardContent>{participantsQuery.isLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <div className="space-y-2">{participantsQuery.data?.length ? participantsQuery.data.map((participant) => <div key={participant.id} className="flex flex-col justify-between gap-2 rounded-lg border p-3 text-sm sm:flex-row sm:items-center"><div><strong>{participant.name}</strong><p className="text-muted-foreground">{participant.phone}</p></div><div className="flex flex-wrap gap-1">{participant.numbers.map((number) => <span key={number} className="rounded-full bg-muted px-2 py-1 font-semibold">#{String(number).padStart(3, "0")}</span>)}</div></div>) : <p className="text-sm text-muted-foreground">Nenhum participante ainda.</p>}</div>}</CardContent></Card>}
    </div>
  );
}


function ClientsTab({ services }: { services: Service[] }) {
  const clientsQuery = trpc.clients.list.useQuery();
  const [selectedClient, setSelectedClient] = useState<any | null>(null);
  const [messageType, setMessageType] = useState<"promotion" | "return">("promotion");
  const [promotionServiceId, setPromotionServiceId] = useState("");
  const [search, setSearch] = useState("");
  const selectedService = services.find((service) => service.id === Number(promotionServiceId));
  const filteredClients = (clientsQuery.data || []).filter((client) => `${client.name} ${client.phone}`.toLowerCase().includes(search.toLowerCase().trim()));
  const messagePreview = selectedClient ? messageType === "promotion"
    ? `Olá, ${selectedClient.name}! Aqui é da Gb Barbearia. Já faz ${selectedClient.daysSinceLastAppointment} ${selectedClient.daysSinceLastAppointment === 1 ? "dia" : "dias"} desde seu último atendimento. Temos uma promoção especial no serviço ${selectedService?.name || "selecionado"}. Quer aproveitar e confirmar seu próximo horário?`
    : `Olá, ${selectedClient.name}! Aqui é da Gb Barbearia. Já faz ${selectedClient.daysSinceLastAppointment} ${selectedClient.daysSinceLastAppointment === 1 ? "dia" : "dias"} desde seu último atendimento de ${selectedClient.lastServiceName}. Que tal agendar seu próximo horário? Será um prazer receber você novamente.` : "";

  const openMessage = () => {
    if (!selectedClient) return;
    if (messageType === "promotion" && !selectedService) {
      toast.error("Selecione o serviço que está em promoção.");
      return;
    }
    const phone = normalizeBrazilianPhone(selectedClient.phone);
    if (!phone) {
      toast.error("O telefone deste cliente não está em um formato válido.");
      return;
    }
    window.open(buildWhatsAppUrl(messagePreview, phone), "_blank", "noopener,noreferrer");
  };

  return (
    <div className="space-y-6">
      <div><p className="text-xs font-bold uppercase tracking-[0.2em] text-[oklch(0.63_0.12_53)]">Relacionamento</p><h2 className="mt-1 font-serif text-3xl">Clientes</h2><p className="mt-2 text-sm text-muted-foreground">Todos que já fizeram um agendamento aparecem aqui com nome, telefone e último atendimento.</p></div>
      <Card><CardContent className="p-4"><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar por nome ou telefone..." /></CardContent></Card>
      {clientsQuery.isLoading ? <Card><CardContent className="flex justify-center p-10"><Loader2 className="h-6 w-6 animate-spin text-[oklch(0.63_0.12_53)]" /></CardContent></Card> : filteredClients.length === 0 ? <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">Nenhum cliente encontrado.</CardContent></Card> : <div className="grid gap-4 lg:grid-cols-2">{filteredClients.map((client) => <Card key={client.phone}><CardContent className="p-5"><div className="flex items-start justify-between gap-3"><div><h3 className="font-serif text-xl">{client.name}</h3><p className="mt-1 text-sm text-muted-foreground">{client.phone}</p></div><UsersRound className="h-5 w-5 text-[oklch(0.63_0.12_53)]" /></div><div className="mt-4 grid grid-cols-2 gap-2 text-sm"><span className="rounded-lg bg-muted p-2"><strong>{client.daysSinceLastAppointment}</strong><br />dias desde o último</span><span className="rounded-lg bg-muted p-2"><strong>{client.totalAppointments}</strong><br />agendamentos</span></div><p className="mt-3 text-sm text-muted-foreground">Último serviço: <span className="font-medium text-foreground">{client.lastServiceName}</span></p><Button type="button" onClick={() => { setSelectedClient(client); setPromotionServiceId(services[0] ? String(services[0].id) : ""); }} className="mt-4 w-full bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]"><MessageCircle className="mr-2 h-4 w-4" />Enviar mensagem</Button></CardContent></Card>)}</div>}
      <Dialog open={Boolean(selectedClient)} onOpenChange={(open) => !open && setSelectedClient(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Mensagem para {selectedClient?.name}</DialogTitle><DialogDescription>Escolha o objetivo da mensagem. O WhatsApp será aberto com o texto preenchido.</DialogDescription></DialogHeader>
          <div className="space-y-4">
            <div><Label>O que deseja fazer?</Label><select value={messageType} onChange={(event) => setMessageType(event.target.value as "promotion" | "return")} className="mt-1 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"><option value="promotion">Apresentar promoção</option><option value="return">Convidar para voltar</option></select></div>
            {messageType === "promotion" && <div><Label>Serviço em promoção</Label><select value={promotionServiceId} onChange={(event) => setPromotionServiceId(event.target.value)} className="mt-1 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"><option value="">Selecione um serviço</option>{services.map((service) => <option key={service.id} value={service.id}>{service.name}</option>)}</select></div>}
            <div className="rounded-xl border border-[oklch(0.86_0.025_75)] bg-muted/50 p-4"><p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Prévia da mensagem</p><p className="mt-2 whitespace-pre-line text-sm leading-6">{messagePreview}</p></div>
          </div>
          <DialogFooter><Button type="button" variant="outline" onClick={() => setSelectedClient(null)}>Cancelar</Button><Button type="button" onClick={openMessage} className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]"><MessageCircle className="mr-2 h-4 w-4" />Abrir WhatsApp</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

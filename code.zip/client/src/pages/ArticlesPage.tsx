import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, ArrowUpRight, Pin } from "lucide-react";
import { toast } from "sonner";

export default function ArticlesPage() {
  const [limit, setLimit] = useState(10);
  const { data, isLoading } = trpc.posts.paginated.useQuery({ limit, offset: 0 });
  const utils = trpc.useUtils();

  const reactPost = trpc.posts.react.useMutation({
    onSuccess: () => {
      toast.success("Obrigado pela reação!");
      utils.posts.paginated.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const pinned = data?.pinned || [];
  const items = data?.items || [];
  const total = data?.total || 0;
  const hasMore = items.length < total;

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-[#FFFFFF]">
      {/* Top Bar */}
      <header className="sticky top-0 z-40 border-b border-[#383838] bg-[#0B0B0B]/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 sm:px-8">
          <Button asChild variant="ghost" size="sm" className="gap-2 text-[#A5A5A5] hover:bg-[#242424]">
            <Link href="/">
              <ArrowLeft className="h-4 w-4" /> Voltar ao início
            </Link>
          </Button>
          <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[#C8A45D]">Gb Barbearia</span>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 py-12 sm:px-8 sm:py-16 space-y-16">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold uppercase tracking-[0.22em] text-[#C8A45D]">Artigos e Dicas</span>
          <h1 className="font-serif text-3xl sm:text-5xl text-[#FFFFFF]">Todos os artigos da barbearia</h1>
          <p className="text-[#A5A5A5] leading-relaxed">Explore nossa biblioteca de conteúdos sobre estilo masculino, cabelo e barba.</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <p className="text-muted-foreground text-sm">Carregando artigos...</p>
          </div>
        ) : (
          <div className="space-y-16">
            {/* Pinned Articles (up to 4, 2 per column) */}
            {pinned.length > 0 && (
              <div className="space-y-6">
                <div className="flex items-center gap-2 border-b border-[#383838] pb-3">
                  <Pin className="h-5 w-5 text-[#C8A45D] fill-current" />
                  <h2 className="font-serif text-2xl text-[#FFFFFF]">Em destaque</h2>
                </div>
                <div className="grid gap-8 md:grid-cols-2">
                  {pinned.map((post: any) => (
                    <div key={post.id} className="group rounded-[1.8rem] border border-[#383838] bg-[#1C1C1C] overflow-hidden shadow-sm transition-all duration-300 hover:shadow-md flex flex-col justify-between">
                      <div>
                        {post.coverImageUrl && (
                          <a href={`/post/${post.id}`} className="block h-60 w-full overflow-hidden bg-[#242424]">
                            <img src={post.coverImageUrl} alt={post.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                          </a>
                        )}
                        <div className="p-6 sm:p-8 space-y-3">
                          <div className="flex items-center gap-2">
                            <Badge className="bg-[#C8A45D] text-[#0B0B0B] text-[11px]">Em destaque</Badge>
                            <span className="text-xs text-muted-foreground font-medium">Por {post.authorName}</span>
                          </div>
                          <a href={`/post/${post.id}`} className="block">
                            <h3 className="font-serif text-2xl sm:text-3xl text-[#FFFFFF] group-hover:text-[#C8A45D] transition-colors">{post.title}</h3>
                          </a>
                          <p className="text-sm leading-7 text-[#A5A5A5] line-clamp-3">{post.summary}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between border-t border-[#383838] px-6 sm:px-8 py-4 bg-[#242424]">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => reactPost.mutate({ id: post.id })}
                          className="gap-1.5 text-[#C8A45D] hover:bg-[#242424]"
                        >
                          <Heart className="h-4 w-4 fill-current" />
                          <span>{post.reactionsCount || 0}</span>
                        </Button>
                        <Button asChild size="sm" className="bg-[#C8A45D] hover:bg-[#E0BD72] text-[#0B0B0B]">
                          <a href={`/post/${post.id}`}>Ler artigo completo <ArrowUpRight className="ml-1 h-3.5 w-3.5" /></a>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* All Articles Grid (2 columns) */}
            <div className="space-y-6">
              <div className="border-b border-[#383838] pb-3">
                <h2 className="font-serif text-2xl text-[#FFFFFF]">Todos os Artigos e Publicações</h2>
              </div>
              <div className="grid gap-8 md:grid-cols-2">
                {items.map((post: any) => (
                  <div key={post.id} className="group rounded-[1.8rem] border border-[#383838] bg-[#1C1C1C] overflow-hidden shadow-sm transition-all duration-300 hover:shadow-md flex flex-col justify-between">
                    <div>
                      {post.coverImageUrl && (
                        <a href={`/post/${post.id}`} className="block h-52 w-full overflow-hidden bg-[#242424]">
                          <img src={post.coverImageUrl} alt={post.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        </a>
                      )}
                      <div className="p-6 space-y-3">
                        <p className="text-xs text-muted-foreground font-medium">Por {post.authorName} · {new Date(post.createdAt).toLocaleDateString("pt-BR")}</p>
                        <a href={`/post/${post.id}`} className="block">
                          <h3 className="font-serif text-xl sm:text-2xl text-[#FFFFFF] group-hover:text-[#C8A45D] transition-colors">{post.title}</h3>
                        </a>
                        <p className="text-sm leading-6 text-[#A5A5A5] line-clamp-3">{post.summary}</p>
                        {post.services && post.services.length > 0 && (
                          <div className="flex flex-wrap gap-1.5 pt-2">
                            {post.services.map((s: any) => (
                              <span key={s.id} className="inline-flex items-center rounded-full bg-[#242424] px-2.5 py-0.5 text-[11px] font-medium text-[#C8A45D] border border-[#383838]">
                                {s.name}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between border-t border-[#383838] px-6 py-4 bg-[#242424]/55">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => reactPost.mutate({ id: post.id })}
                        className="gap-1.5 text-[#C8A45D] hover:bg-[#242424]"
                      >
                        <Heart className="h-4 w-4 fill-current" />
                        <span>{post.reactionsCount || 0}</span>
                      </Button>
                      <Button asChild size="sm" className="bg-[#C8A45D] hover:bg-[#E0BD72] text-[#0B0B0B]">
                        <a href={`/post/${post.id}`}>Ler artigo completo <ArrowUpRight className="ml-1 h-3.5 w-3.5" /></a>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              {hasMore && (
                <div className="flex justify-center pt-8">
                  <Button
                    onClick={() => setLimit((prev) => prev + 10)}
                    className="rounded-full bg-[#C8A45D] px-8 py-3 text-[#0B0B0B] hover:bg-[#E0BD72] shadow-md"
                  >
                    Mostrar mais artigos
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <footer className="mt-20 border-t border-[#383838] bg-[#0B0B0B] py-7 text-[#A5A5A5]">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 text-sm sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <p>© 2026 Gb Barbearia · Barbearia Premium</p>
          <Link href="/" className="font-semibold text-[#C8A45D] hover:text-[#E0BD72]">Voltar à página inicial</Link>
        </div>
      </footer>
    </div>
  );
}

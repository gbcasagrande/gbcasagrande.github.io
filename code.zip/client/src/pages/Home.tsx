import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { buildWhatsAppUrl, formatCivilDateForWhatsApp, formatTimeForWhatsApp, resolveProfessionalWhatsAppTarget } from "@/lib/whatsapp";
import { trpc } from "@/lib/trpc";
import { SITE_CONTENT_DEFAULTS } from "@shared/siteContent";
import { getServicePromotionalPrice, parseServiceBenefits } from "@shared/serviceCatalog";
import { DEFAULT_TOP_BAR_HEIGHT, getHomeHeaderVisibility, getHomeTopPadding, getLoadedHomeImageUrl, getRequestedBookingServiceId, getRequestedProfessionalId, getRequestedProfessionalOnly, LOCATION_SECTION_LABEL } from "@shared/siteLayout";
import {
  Activity,
  ArrowUpRight,
  CalendarDays,
  Check,
  ChevronDown,
  Clock,
  Droplets,
  Flower2,
  Gift,
  HandHeart,
  Heart,
  Instagram,
  Leaf,
  MapPin,
  MessageCircle,
  Phone,
  Shield,
  Snowflake,
  Scissors,
  Sparkles,
  Waves,
  Zap,
} from "lucide-react";
import { useState, useRef, useMemo, useEffect } from "react";
import { toast } from "sonner";
import HomeV1 from "./HomeV1";

const NAVALHA_LOGO = "/manus-storage/gb-barbearia-logo-transparent_77dbd48f.png";
const INSTAGRAM_URL = "https://www.instagram.com/navalhamarau/";

const serviceIconByKey: Record<string, typeof Sparkles> = {
  Sparkles,
  Droplets,
  Heart,
  Activity,
  Shield,
  Zap,
  Snowflake,
  Flower2,
  Waves,
  HandHeart,
  Leaf,
};

const serviceIconByName: Record<string, typeof Sparkles> = {
  "Corte Clássico": Sparkles,
  "Corte + Barba": Scissors,
  "Barba Tradicional": Heart,
  "Corte Degradê": Activity,
  "Corte Infantil": Shield,
  "Ritual de Toalha Quente": Droplets,
  "Camuflagem de Fios": Zap,
};

const serviceBenefitsByName: Record<string, string[]> = {
  "Corte Clássico": ["Consulta de estilo", "Tesoura e máquina", "Acabamento preciso", "Finalização"],
  "Corte + Barba": ["Corte personalizado", "Toalha quente", "Contornos definidos", "Finalização completa"],
  "Barba Tradicional": ["Toalha quente", "Desenho da barba", "Navalha e acabamento", "Hidratação"],
  "Corte Degradê": ["Transição limpa", "Acabamento na régua", "Textura personalizada", "Finalização"],
  "Corte Infantil": ["Atendimento paciente", "Ambiente descontraído", "Corte sob medida", "Finalização"],
  "Ritual de Toalha Quente": ["Esfoliação suave", "Toalha quente", "Relaxamento", "Hidratação"],
  "Camuflagem de Fios": ["Resultado natural", "Aplicação rápida", "Tom personalizado", "Baixa manutenção"],
};

export default function Home() {
  const { data: selectedContent } = trpc.siteContent.get.useQuery();
  if (selectedContent?.siteVersion === "v1") return <HomeV1 />;
  return <HomeV0 />;
}

function HomeV0() {
  const servicesRef = useRef<HTMLElement>(null);
  const contactRef = useRef<HTMLElement>(null);
  const { data: siteContent } = trpc.siteContent.get.useQuery();
  const { data: services = [], isLoading: servicesLoading } = trpc.services.listWithProfessionals.useQuery();
  const { data: professionals = [] } = trpc.professionals.listActive.useQuery();
  const { data: featuredRaffle } = trpc.raffles.featured.useQuery();
  const content = siteContent ?? SITE_CONTENT_DEFAULTS;
  const heroImageUrl = getLoadedHomeImageUrl(siteContent?.aboutImageUrl || SITE_CONTENT_DEFAULTS.aboutImageUrl);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingServiceId, setBookingServiceId] = useState<number | null>(null);
  const [bookingProfessionalId, setBookingProfessionalId] = useState<number | null>(null);
  const [bookingProfessionalLocked, setBookingProfessionalLocked] = useState(false);

  const openBooking = (serviceId?: number, professionalId?: number) => {
    setBookingServiceId(serviceId ?? services[0]?.id ?? null);
    setBookingProfessionalId(professionalId ?? null);
    setBookingProfessionalLocked(false);
    setIsBookingOpen(true);
  };

  useEffect(() => {
    const requestedServiceId = getRequestedBookingServiceId(window.location.search);
    const requestedProfessionalId = getRequestedProfessionalId(window.location.search);
    const requestedProfessionalOnly = getRequestedProfessionalOnly(window.location.search);
    const validServiceId = requestedServiceId && services.some((service) => service.id === requestedServiceId) ? requestedServiceId : null;
    const validProfessionalId = requestedProfessionalId && professionals.some((professional) => professional.id === requestedProfessionalId) ? requestedProfessionalId : null;
    if (!validServiceId && !validProfessionalId) return;

    setBookingServiceId(validServiceId ?? services[0]?.id ?? null);
    setBookingProfessionalId(validProfessionalId);
    setBookingProfessionalLocked(requestedProfessionalOnly && Boolean(validProfessionalId));
    setIsBookingOpen(true);

    const url = new URL(window.location.href);
    url.searchParams.delete("bookingServiceId");
    url.searchParams.delete("professionalId");
    url.searchParams.delete("professionalOnly");
    window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
  }, [professionals, services]);

  const scrollTo = (ref: React.RefObject<HTMLElement | null>) => {
    ref.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };



  return (
    <div className="min-h-screen overflow-x-clip bg-[#0B0B0B] text-[#FFFFFF]">
      <div aria-hidden={isBookingOpen} className={`fixed inset-x-0 top-0 z-[60] transition-opacity duration-150 ${getHomeHeaderVisibility(isBookingOpen) === "hidden" ? "pointer-events-none invisible opacity-0" : "visible opacity-100"}`}>
      <header className="relative z-10 border-b border-[#383838]/80 bg-[#0B0B0B]/95 shadow-[0_8px_30px_rgba(86,53,52,0.08)] backdrop-blur-xl">
          <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-12">
          <button type="button" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="group flex items-center gap-3 text-left">
            <span className="flex h-11 w-16 items-center justify-center overflow-hidden rounded-xl transition-transform duration-200 group-hover:-rotate-2">
              <img src={content.logoUrl || NAVALHA_LOGO} alt="Logo da Gb Barbearia" className="h-full w-full object-contain" />
            </span>
            <span>
              <span className="block font-serif text-lg leading-none text-[#FFFFFF]">Gb Barbearia</span>
              <span className="mt-1 block text-[10px] font-medium uppercase tracking-[0.22em] text-[#A5A5A5]">Barbearia Premium</span>
            </span>
          </button>

          <nav className="hidden items-center gap-6 md:flex" aria-label="Navegação principal">
            <button type="button" onClick={() => scrollTo(servicesRef)} className="text-sm font-medium text-[#5f554b] transition-colors hover:text-[#C8A45D]">Serviços</button>
            <button type="button" onClick={() => scrollTo(contactRef)} className="text-sm font-medium text-[#5f554b] transition-colors hover:text-[#C8A45D]">Contato</button>
            <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-medium text-[#5f554b] transition-colors hover:text-[#C8A45D]"><Instagram className="h-4 w-4" />Instagram</a>
            <a href={buildWhatsAppUrl("Olá! Gostaria de agendar um horário na Gb Barbearia. Vim pelo site.")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-[#b87545] px-4 py-2 text-sm font-semibold text-white shadow-sm transition-all hover:bg-[#E0BD72]"><MessageCircle className="h-4 w-4" />WhatsApp</a>
            <a href="/login" className="rounded-full border border-[#C8A45D]/45 px-4 py-2 text-sm font-semibold text-[#aa4662] transition-all hover:bg-[#b87545] hover:text-white">Área Administrativa</a>
          </nav>

          <div className="flex items-center gap-2 md:hidden">
            <a href={buildWhatsAppUrl("Olá! Gostaria de agendar um horário na Gb Barbearia. Vim pelo site.")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-[#b87545] px-4 py-2.5 text-sm font-semibold text-white shadow-[0_10px_22px_rgba(200,164,93,0.18)] transition-all hover:-translate-y-0.5 hover:bg-[#E0BD72]">
              <MessageCircle className="h-4 w-4" />
              <span className="hidden min-[380px]:inline">WhatsApp</span>
            </a>
          </div>
        </div>
      </header>
      </div>

      {featuredRaffle && (
        <section className="fixed inset-x-0 top-[76px] z-40 border-b border-[#C8A45D]/40 bg-[#1C1C1C]/95 shadow-[0_10px_30px_rgba(0,0,0,0.35)] backdrop-blur-xl">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-5 py-3 sm:px-8 lg:px-12">
            <div className="flex min-w-0 items-center gap-3"><Gift className="h-5 w-5 shrink-0 text-[#C8A45D]" /><p className="truncate text-sm text-[#FFFFFF]"><span className="font-semibold text-[#C8A45D]">{featuredRaffle.status === "active" ? "Sorteio ativo:" : "Último sorteio:"}</span> {featuredRaffle.title} · {featuredRaffle.status === "active" ? featuredRaffle.serviceName : `${("winnerName" in featuredRaffle ? featuredRaffle.winnerName : null) || "Resultado publicado"} venceu`}</p></div>
            <a href={`/sorteios/${featuredRaffle.id}`} className="shrink-0 rounded-full bg-[#C8A45D] px-4 py-2 text-xs font-bold text-[#0B0B0B] transition hover:bg-[#E0BD72]">{featuredRaffle.status === "active" ? "Participar" : "Ver resultado"}</a>
          </div>
        </section>
      )}

      <main>
        <section className="relative isolate overflow-hidden" style={{ paddingTop: `${getHomeTopPadding(DEFAULT_TOP_BAR_HEIGHT)}px` }}>
          <div className="absolute inset-0 -z-20 bg-[radial-gradient(circle_at_8%_10%,rgba(200,164,93,0.16),transparent_33%),radial-gradient(circle_at_90%_18%,rgba(200,164,93,0.08),transparent_28%),linear-gradient(135deg,#0B0B0B_0%,#121212_52%,#1C1C1C_100%)]" />
          <div className="mx-auto grid max-w-7xl items-center gap-10 px-5 pb-16 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-16 lg:px-12 lg:pb-20">
            <div className="max-w-2xl">
              <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-[#C8A45D]/35 bg-[#1C1C1C]/80 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-[#C8A45D] backdrop-blur-sm">
                <Sparkles className="h-3.5 w-3.5" />
                Ofício, precisão, presença
              </div>
              <h1 className="max-w-2xl font-serif text-4xl leading-[1.02] tracking-[-0.045em] text-white sm:text-6xl lg:text-[4.8rem]">Seu estilo pede precisão. <em className="font-normal text-[#C8A45D]">Sente-se.</em></h1>
              <p className="mt-6 max-w-xl text-base leading-7 text-[#A5A5A5] sm:text-lg">{content.heroDescription}</p>

              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <Button onClick={() => openBooking()} className="h-14 rounded-full bg-[#b87545] px-7 text-base font-semibold text-white shadow-[0_14px_28px_rgba(200,164,93,0.2)] transition-all hover:-translate-y-0.5 hover:bg-[#E0BD72]">
                  <CalendarDays className="mr-2 h-5 w-5" />
                  Escolher meu horário
                </Button>
                <Button variant="outline" onClick={() => scrollTo(servicesRef)} className="h-14 rounded-full border-[#C8A45D]/45 bg-[#1C1C1C]/70 px-7 text-base font-semibold text-[#FFFFFF] hover:bg-[#242424]">
                  Conhecer serviços
                  <ArrowUpRight className="ml-2 h-4 w-4" />
                </Button>
              </div>

              <div className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm text-[#A5A5A5]">
                <span className="inline-flex items-center gap-2"><Check className="h-4 w-4 text-[#C8A45D]" />Cortes com assinatura</span>
                <span className="inline-flex items-center gap-2"><Check className="h-4 w-4 text-[#C8A45D]" />Barbeiros experientes</span>
                <span className="inline-flex items-center gap-2"><Check className="h-4 w-4 text-[#C8A45D]" />Marau · RS</span>
              </div>
            </div>

            <div className="relative mx-auto w-full max-w-[32rem] lg:justify-self-end">
              <div className="absolute -inset-4 rounded-[2.5rem] bg-[#1C1C1C]/60 blur-2xl" />
              <div className="relative overflow-hidden rounded-[2rem] border border-[#383838] bg-[#242424] p-2.5 shadow-[0_24px_55px_rgba(111,66,67,0.14)]">
                {heroImageUrl ? (
                  <img src={heroImageUrl} alt="Gb Barbearia - Barbearia Premium" className="h-[24rem] w-full rounded-[1.5rem] object-cover object-center sm:h-[30rem]" />
                ) : (
                  <div className="h-[24rem] w-full rounded-[1.5rem] bg-[#242424] sm:h-[30rem]" aria-hidden="true" />
                )}
                <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between rounded-2xl border border-[#383838] bg-[#242424]/90 px-4 py-3.5 shadow-lg backdrop-blur-md">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#C8A45D]">Ritual da casa</p>
                    <p className="mt-1 font-serif text-xl text-[#FFFFFF]">Seu estilo, nosso ofício</p>
                  </div>
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[#b87545] text-white"><Heart className="h-5 w-5" /></span>
                </div>
              </div>
              <div className="absolute -bottom-5 -left-5 hidden rounded-2xl border border-[#383838] bg-[#1C1C1C]/90 px-5 py-4 shadow-xl sm:block">
                <p className="font-serif text-2xl text-[#C8A45D]">7 anos</p>
                <p className="text-xs uppercase tracking-[0.12em] text-[#A5A5A5]">de experiência</p>
              </div>
            </div>
          </div>
          <button type="button" onClick={() => scrollTo(servicesRef)} className="mx-auto mb-5 flex flex-col items-center gap-2 text-[#C8A45D]" aria-label="Conhecer serviços">
            <span className="text-[10px] font-bold uppercase tracking-[0.24em]">Descubra</span>
            <ChevronDown className="h-5 w-5 animate-bounce" />
          </button>
        </section>

        <section className="border-y border-[#383838] bg-[#1C1C1C] py-4">
          <div className="mx-auto grid max-w-7xl gap-4 px-5 sm:grid-cols-3 sm:px-8 lg:px-12">
            <div className="flex items-center gap-3 sm:justify-center"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#242424] text-[#C8A45D]"><Heart className="h-4 w-4" /></span><span className="text-sm font-semibold text-[#A5A5A5]">Técnica de barbeiro</span></div>
            <div className="flex items-center gap-3 sm:justify-center"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#242424] text-[#C8A45D]"><Clock className="h-4 w-4" /></span><span className="text-sm font-semibold text-[#A5A5A5]">Horários com agendamento</span></div>
            <div className="flex items-center gap-3 sm:justify-center"><span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#242424] text-[#C8A45D]"><MapPin className="h-4 w-4" /></span><span className="text-sm font-semibold text-[#A5A5A5]">Localização em Marau</span></div>
          </div>
        </section>

        <section className="bg-[#1C1C1C] py-20 sm:py-24">
          <div className="mx-auto max-w-4xl px-5 sm:px-8 lg:px-12">
            <div>
              <p className="mb-4 text-xs font-bold uppercase tracking-[0.22em] text-[#C8A45D]">Sobre a barbearia</p>
              <h2 className="max-w-xl font-serif text-4xl leading-tight text-[#FFFFFF] sm:text-5xl">{content.aboutTitle}</h2>
              <div className="mt-6 h-px w-20 bg-[#b87545]" />
              <p className="mt-7 text-lg leading-8 text-[#A5A5A5]">{content.aboutParagraph1}</p>
              <p className="mt-5 text-lg leading-8 text-[#A5A5A5]">{content.aboutParagraph2}</p>
              <div className="mt-8 flex items-start gap-4 rounded-2xl border border-[#383838] bg-[#242424] p-5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#b87545] text-white"><Sparkles className="h-5 w-5" /></span>
                <div><p className="font-serif text-xl text-[#FFFFFF]">{content.aboutHighlightTitle}</p><p className="mt-1 text-sm leading-6 text-[#A5A5A5]">{content.aboutHighlightDescription}</p></div>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-[#0B0B0B] py-20 sm:py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
            <div className="mx-auto max-w-3xl text-center">
              <p className="mb-4 text-xs font-bold uppercase tracking-[0.22em] text-[#C8A45D]">Nossa equipe</p>
              <h2 className="font-serif text-4xl leading-tight text-[#FFFFFF] sm:text-5xl">Barbeiros dedicados ao seu estilo</h2>
              <p className="mt-5 text-lg leading-8 text-[#A5A5A5]">Conheça os barbeiros que integram a Gb Barbearia em Marau, unindo técnica, precisão e atendimento próximo em cada corte.</p>
            </div>

            <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {professionals.map((prof) => (
                <a key={prof.id} href={`/barbeiro/${prof.profileSlug || prof.id}`} className="group rounded-3xl border border-[#383838] bg-[#1C1C1C] p-6 text-center transition-all duration-300 hover:-translate-y-1 hover:border-[#C8A45D]/45 hover:shadow-[0_16px_32px_rgba(105,69,68,0.08)]">
                  <div className="mx-auto mb-5 h-24 w-24 overflow-hidden rounded-full border-2 border-[#C8A45D]/30 bg-[#242424] shadow-inner">
                    {prof.avatarUrl ? (
                      <img src={prof.avatarUrl} alt={prof.name} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center font-serif text-2xl font-bold text-[#C8A45D]">
                        {prof.name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <h3 className="font-serif text-xl text-[#FFFFFF]">{prof.name}</h3>
                  <p className="mt-1 text-xs font-semibold uppercase tracking-wider text-[#C8A45D]">{prof.specialty || "Barbeiro da barbearia"}</p>
                  {prof.bio && <p className="mt-3 line-clamp-3 text-xs leading-5 text-[#A5A5A5]">{prof.bio}</p>}
                  <span className="mt-5 inline-flex items-center gap-1 text-xs font-bold text-[#C8A45D]">Ver perfil e serviços <ArrowUpRight className="h-3.5 w-3.5" /></span>
                </a>
              ))}
            </div>
          </div>
        </section>

        <section id="servicos" ref={servicesRef} className="scroll-mt-20 bg-[#0B0B0B] py-20 sm:py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
            <div className="mb-14 flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
              <div className="max-w-2xl"><p className="mb-4 text-xs font-bold uppercase tracking-[0.22em] text-[#C8A45D]">Serviços selecionados</p><h2 className="font-serif text-4xl leading-tight text-[#FFFFFF] sm:text-5xl">Cuidados que respeitam o seu momento.</h2></div>
              <p className="max-w-xs text-sm leading-6 text-[#A5A5A5]">Escolha o serviço ideal e encontre um horário disponível para seu próximo corte.</p>
            </div>

            {servicesLoading ? <p className="py-8 text-center text-[#A5A5A5]">Carregando serviços...</p> : services.length === 0 ? <p className="py-8 text-center text-[#A5A5A5]">Os serviços estarão disponíveis em breve.</p> : <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {services.map((service) => {
                const Icon = serviceIconByKey[service.icon] ?? serviceIconByName[service.name] ?? Sparkles;
                const benefits = parseServiceBenefits(service.benefits, serviceBenefitsByName[service.name] ?? ["Atendimento personalizado", "Acabamento preciso"]);
                return <Card key={service.id} className={`group relative flex h-full flex-col overflow-hidden rounded-3xl bg-[#1C1C1C] transition-all duration-300 hover:-translate-y-1 ${service.isFeatured === 1 ? "border-2 border-[#C8A45D] shadow-[0_18px_42px_rgba(200,164,93,0.2)]" : "border border-[#383838] shadow-[0_8px_24px_rgba(105,69,68,0.04)] hover:shadow-[0_18px_38px_rgba(105,69,68,0.1)]"}`}>
                  <CardContent className="flex h-full flex-col p-6">
                    {service.isFeatured === 1 ? <div className="absolute right-5 top-5 inline-flex items-center gap-1.5 rounded-full bg-[#b87545] px-3 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-white"><Sparkles className="h-3 w-3" /> Serviço em destaque</div> : null}
                    <div className="flex items-start justify-between gap-4"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#242424] text-[#C8A45D] transition-colors group-hover:bg-[#b87545] group-hover:text-white"><Icon className="h-6 w-6" /></span><span className="rounded-full bg-[#242424] px-3 py-1 text-xs font-bold text-[#C8A45D]">{service.duration ? `${service.duration} min` : "Atendimento"}</span></div>
                    {service.discountPercent ? <div className="mt-4 inline-flex w-fit items-center gap-2 rounded-full bg-[#b87545] px-3 py-1 text-xs font-bold uppercase tracking-[0.12em] text-white"><Sparkles className="h-3.5 w-3.5" />{service.promotionLabel || "Oferta especial"} · -{service.discountPercent}%</div> : null}
                    <h3 className="mt-6 font-serif text-2xl text-[#FFFFFF]">{service.name}</h3>
                    <p className="mt-3 min-h-[3.5rem] text-sm leading-6 text-[#A5A5A5]">{service.description || "Um ritual preciso para renovar corte, barba e autoestima."}</p>
                    <div className="mt-5 flex items-center justify-between border-y border-[#efe2df] py-4"><span className="text-sm font-medium text-[#A5A5A5]">Investimento</span><span className="text-right font-serif text-lg text-[#C8A45D]">{service.priceDisplayMode === "evaluation" ? "Agendar uma avaliação" : service.discountPercent ? <><span className="mr-2 text-sm text-[#9a8587] line-through">R$ {service.defaultPrice}</span>R$ {getServicePromotionalPrice(service.defaultPrice, service.discountPercent).toFixed(2)}</> : `R$ ${service.defaultPrice}`}</span></div>
                    <div className="mt-5 rounded-2xl border border-[#383838] bg-[#242424] p-4">
                      <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#C8A45D]">Barbeiros disponíveis</p>
                      {service.professionals?.length ? (
                        <div className="mt-3 flex flex-wrap items-center gap-2.5">
                          {service.professionals.map((professional) => (
                            <div key={professional.id} className="flex items-center gap-2 rounded-full bg-[#1C1C1C] py-1.5 pl-1.5 pr-3 shadow-sm" title={professional.specialty || professional.name}>
                              <div className="h-8 w-8 overflow-hidden rounded-full border border-[#e7c5cb] bg-[#242424]">
                                {professional.avatarUrl ? <img src={professional.avatarUrl} alt={professional.name} className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center font-serif text-xs font-bold text-[#C8A45D]">{professional.name.charAt(0)}</div>}
                              </div>
                              <span className="max-w-[9rem] truncate text-xs font-medium text-[#A5A5A5]">{professional.name}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="mt-2 text-xs leading-5 text-[#A5A5A5]">A equipe confirmará o barbeiro disponível no momento do agendamento.</p>
                      )}
                    </div>
                    <div className="mt-5 space-y-2">{benefits.slice(0, 4).map((benefit) => <p key={benefit} className="flex items-center gap-2 text-sm text-[#A5A5A5]"><Check className="h-4 w-4 shrink-0 text-[#C8A45D]" />{benefit}</p>)}</div>
                    <Button onClick={() => openBooking(service.id)} className="mt-7 h-12 w-full rounded-full bg-[#b87545] font-semibold text-white hover:bg-[#E0BD72]"><MessageCircle className="mr-2 h-4 w-4" />Agendar este serviço</Button>
                  </CardContent>
                </Card>;
              })}
            </div>}
          </div>
        </section>

        <section className="bg-[#1C1C1C] py-20 sm:py-24">
          <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
              <div className="mx-auto mb-14 max-w-2xl text-center"><p className="mb-4 text-xs font-bold uppercase tracking-[0.22em] text-[#C8A45D]">Uma experiência completa</p><h2 className="font-serif text-4xl leading-tight text-[#FFFFFF] sm:text-5xl">Precisão pensada nos detalhes.</h2><a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-[#C8A45D] hover:text-[#C8A45D]"><Instagram className="h-4 w-4" />Siga-nos no Instagram · @navalhamarau</a></div>
            <div className="grid gap-5 md:grid-cols-3">
              <div className="rounded-[1.5rem] border border-[#383838] bg-[#242424] p-7"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#1C1C1C] text-[#C8A45D] shadow-sm"><HandHeart className="h-6 w-6" /></span><h3 className="mt-7 font-serif text-2xl text-[#FFFFFF]">Escuta atenta</h3><p className="mt-3 leading-7 text-[#A5A5A5]">Cada atendimento começa entendendo o seu estilo e o resultado que você busca.</p></div>
              <div className="rounded-[1.5rem] border border-[#383838] bg-[#242424] p-7"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#242424] text-[#C8A45D]"><Sparkles className="h-6 w-6" /></span><h3 className="mt-7 font-serif text-2xl text-[#FFFFFF]">Técnica e presença</h3><p className="mt-3 leading-7 text-[#A5A5A5]">Conhecimento técnico aliado a um ambiente tranquilo, preciso e acolhedor.</p></div>
              <div className="rounded-[1.5rem] border border-[#383838] bg-[#242424] p-7"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#1C1C1C] text-[#C8A45D] shadow-sm"><Leaf className="h-6 w-6" /></span><h3 className="mt-7 font-serif text-2xl text-[#FFFFFF]">Seu tempo, do seu jeito</h3><p className="mt-3 leading-7 text-[#A5A5A5]">Um ritual para desacelerar, cuidar do visual e voltar para a rotina renovado.</p></div>
            </div>

          </div>
        </section>

        {/* Posts Section */}
        {(() => {
          const { data } = trpc.posts.home.useQuery();
          const utils = trpc.useUtils();
          const reactPost = trpc.posts.react.useMutation({
            onSuccess: () => {
              toast.success("Obrigado pela reação!");
              utils.posts.home.invalidate();
            },
            onError: (err) => toast.error(err.message),
          });

          const featured = data?.featured || [];
          const recent = data?.recent || [];
          const allHomePosts = [...featured, ...recent];

          if (allHomePosts.length === 0) return null;

          return (
            <section className="bg-[#0B0B0B] py-24 sm:py-28">
              <div className="mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
                <div className="text-center max-w-2xl mx-auto mb-16">
                  <span className="text-xs font-bold uppercase tracking-[0.22em] text-[oklch(0.63_0.12_53)]">Dicas e Novidades</span>
                  <h2 className="font-serif text-3xl sm:text-5xl text-[oklch(0.22_0.025_70)] mt-3">Artigos e publicações da barbearia</h2>
                  <p className="mt-4 text-[oklch(0.43_0.025_70)] leading-relaxed">Acompanhe conteúdos exclusivos preparados por nossos barbeiros para o seu estilo.</p>
                </div>

                {/* Featured (up to 2) */}
                {featured.length > 0 && (
                  <div className="grid gap-8 md:grid-cols-2 mb-12">
                    {featured.map((post: any) => (
                      <div key={post.id} className="group rounded-[1.8rem] border border-[oklch(0.72_0.09_52)] bg-[#1C1C1C] overflow-hidden shadow-sm transition-all duration-300 hover:shadow-md flex flex-col justify-between">
                        <div>
                          {post.coverImageUrl && (
                            <a href={`/post/${post.id}`} className="block h-60 w-full overflow-hidden bg-[#242424]">
                              <img src={post.coverImageUrl} alt={post.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                            </a>
                          )}
                          <div className="p-6 sm:p-8 space-y-3">
                            <div className="flex items-center gap-2">
                              <Badge className="bg-[oklch(0.63_0.12_53)] text-white text-[11px]">Em destaque</Badge>
                              <span className="text-xs text-muted-foreground font-medium">Por {post.authorName}</span>
                            </div>
                            <a href={`/post/${post.id}`} className="block">
                              <h3 className="font-serif text-2xl sm:text-3xl text-[oklch(0.22_0.025_70)] group-hover:text-[oklch(0.63_0.12_53)] transition-colors">{post.title}</h3>
                            </a>
                            <p className="text-sm leading-7 text-[oklch(0.43_0.025_70)] line-clamp-3">{post.summary}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between border-t border-[#383838] px-6 sm:px-8 py-4 bg-[#242424]">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => reactPost.mutate({ id: post.id })}
                            className="gap-1.5 text-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.93_0.03_75)]"
                          >
                            <Heart className="h-4 w-4 fill-current" />
                            <span>{post.reactionsCount || 0}</span>
                          </Button>
                          <Button asChild size="sm" className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)] text-white">
                            <a href={`/post/${post.id}`}>Ler artigo completo <ArrowUpRight className="ml-1 h-3.5 w-3.5" /></a>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Recent (up to 3) */}
                {recent.length > 0 && (
                  <div className="grid gap-8 md:grid-cols-3">
                    {recent.map((post: any) => (
                      <div key={post.id} className="group rounded-[1.8rem] border border-[#383838] bg-[#1C1C1C] overflow-hidden shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-md flex flex-col justify-between">
                        <div>
                          {post.coverImageUrl && (
                            <a href={`/post/${post.id}`} className="block h-48 w-full overflow-hidden bg-[#242424]">
                              <img src={post.coverImageUrl} alt={post.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                            </a>
                          )}
                          <div className="p-6 space-y-3">
                            <p className="text-xs text-muted-foreground font-medium">Por {post.authorName} · {new Date(post.createdAt).toLocaleDateString("pt-BR")}</p>
                            <a href={`/post/${post.id}`} className="block">
                              <h3 className="font-serif text-xl text-[oklch(0.22_0.025_70)] group-hover:text-[oklch(0.63_0.12_53)] transition-colors">{post.title}</h3>
                            </a>
                            <p className="text-sm leading-6 text-[oklch(0.43_0.025_70)] line-clamp-3">{post.summary}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between border-t border-[#383838] px-6 py-4 bg-[#242424]/55">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => reactPost.mutate({ id: post.id })}
                            className="gap-1.5 text-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.93_0.03_75)]"
                          >
                            <Heart className="h-4 w-4 fill-current" />
                            <span>{post.reactionsCount || 0}</span>
                          </Button>
                          <Button asChild size="sm" className="bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)] text-white">
                            <a href={`/post/${post.id}`}>Ler artigo completo <ArrowUpRight className="ml-1 h-3.5 w-3.5" /></a>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex justify-center mt-12">
                  <Button asChild className="rounded-full border border-[oklch(0.72_0.09_52)] bg-[#1C1C1C] px-8 py-3.5 font-semibold text-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.95_0.02_75)] shadow-sm">
                    <a href="/artigos">Ver todos os artigos <ArrowUpRight className="ml-2 h-4 w-4" /></a>
                  </Button>
                </div>
              </div>
            </section>
          );
        })()}

        <section ref={contactRef} className="scroll-mt-20 bg-[#0B0B0B] py-24 text-white sm:py-28">
          <div className="mx-auto grid max-w-7xl gap-12 px-5 sm:px-8 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20 lg:px-12">
            <div><p className="mb-4 text-xs font-bold uppercase tracking-[0.22em] text-[#C8A45D]">Gb Barbearia</p><h2 className="font-serif text-4xl leading-tight sm:text-5xl">Seu próximo corte pode começar agora.</h2><p className="mt-6 max-w-md text-lg leading-8 text-[#A5A5A5]">Agende seu horário ou fale diretamente pelo WhatsApp. Será um prazer receber você.</p><Button asChild className="mt-8 h-13 rounded-full bg-[#C8A45D] px-7 font-semibold text-[#0B0B0B] hover:bg-[#E0BD72]"><a href={buildWhatsAppUrl("Olá! Gostaria de agendar um horário na Gb Barbearia. Vim pelo site.")} target="_blank" rel="noreferrer"><MessageCircle className="mr-2 h-5 w-5" />Falar pelo WhatsApp</a></Button></div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-3xl border border-white/10 bg-[#1C1C1C]/[0.06] p-6"><Instagram className="h-6 w-6 text-[#C8A45D]" /><p className="mt-5 text-xs font-bold uppercase tracking-[0.16em] text-[#C8A45D]">Instagram</p><a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="mt-2 block text-lg font-semibold text-[#f5eaea] hover:text-white">@navalhamarau</a></div>
              <div className="rounded-3xl border border-white/10 bg-[#1C1C1C]/[0.06] p-6"><MapPin className="h-6 w-6 text-[#C8A45D]" /><p className="mt-5 text-xs font-bold uppercase tracking-[0.16em] text-[#C8A45D]">Endereço</p><p className="mt-2 leading-7 text-[#f5eaea]">Rua Nicandro Oltramari, 309<br />Marau, RS</p></div>
              <div className="rounded-3xl border border-white/10 bg-[#1C1C1C]/[0.06] p-6"><Clock className="h-6 w-6 text-[#C8A45D]" /><p className="mt-5 text-xs font-bold uppercase tracking-[0.16em] text-[#C8A45D]">Atendimento</p><p className="mt-2 leading-7 text-[#f5eaea]">Segunda a sábado<br />Com hora marcada</p></div>
              <div className="overflow-hidden rounded-3xl border border-white/10 bg-[#1C1C1C]/[0.06] sm:col-span-2">
                <div className="flex items-center gap-3 border-b border-white/10 px-6 py-4">
                  <MapPin className="h-5 w-5 text-[#C8A45D]" />
                  <h3 className="font-serif text-2xl text-[#f5eaea]">{LOCATION_SECTION_LABEL}</h3>
                </div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3636.4289938268!2d-51.9234!3d-28.9823!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x951d8c8c8c8c8c8d%3A0x8c8c8c8c8c8c8c8c!2sRua%20Nicandro%20Oltramari%2C%20309%20-%20Marau%2C%20RS!5e0!3m2!1spt-BR!2sbr!4v1234567890" title="Localização da barbearia Gb Barbearia" className="h-64 w-full grayscale-[0.2]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#0B0B0B] py-7 text-[#cfc2b3]">
        <div className="mx-auto flex max-w-7xl flex-col gap-5 px-5 text-sm sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-12">
          <div className="flex items-center gap-3"><span className="flex h-10 w-14 items-center justify-center overflow-hidden rounded-lg"><img src={content.logoUrl || NAVALHA_LOGO} alt="Logo da Gb Barbearia" className="h-full w-full object-contain" /></span><p>Gb Barbearia ® 2026 | Desenvolvido por <a href="https://www.instagram.com/gbcasagrande/" target="_blank" rel="noreferrer" className="font-semibold text-[#d9a77f] transition-colors hover:text-white">@gbcasagrande</a></p></div>
          <div className="flex flex-wrap items-center gap-5">
            <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 font-semibold text-[#d9a77f] transition-colors hover:text-white"><Instagram className="h-4 w-4" />@navalhamarau</a>
            <a href="/login" className="inline-flex items-center gap-2 font-semibold text-[#d9a77f] transition-colors hover:text-white">Área Administrativa <ArrowUpRight className="h-4 w-4" /></a>
          </div>
        </div>
      </footer>

      <BookingDialog open={isBookingOpen} onOpenChange={setIsBookingOpen} services={services} initialServiceId={bookingServiceId} initialProfessionalId={bookingProfessionalId} professionalLocked={bookingProfessionalLocked} />
    </div>
  );
}

function getTodayCivilDate() {
  const today = new Date();
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
}

export function BookingDialog({
  open,
  onOpenChange,
  services,
  initialServiceId,
  initialProfessionalId,
  professionalLocked,
  lockedProfessional,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  services: Array<{ id: number; name: string; duration: number | null; professionals?: Array<{ id: number }> }>;
  initialServiceId: number | null;
  initialProfessionalId: number | null;
  professionalLocked: boolean;
  lockedProfessional?: { id: number; name: string; specialty?: string | null; avatarUrl?: string | null };
}) {
  const [serviceId, setServiceId] = useState<number | null>(initialServiceId);
  const [appointmentDate, setAppointmentDate] = useState(getTodayCivilDate());
  const [appointmentTime, setAppointmentTime] = useState("");
  const [professionalId, setProfessionalId] = useState<number | null>(initialProfessionalId);
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [reason, setReason] = useState("");
  const availableServices = useMemo(() => professionalLocked && initialProfessionalId ? services.filter((service) => service.professionals?.some((professional) => professional.id === initialProfessionalId)) : services, [initialProfessionalId, professionalLocked, services]);
  const selectedService = availableServices.find((service) => service.id === serviceId) ?? null;
  const { data: serviceProfessionals = [], isLoading: professionalsLoading } = trpc.professionals.forService.useQuery(
    { serviceId: selectedService?.id ?? 0 },
    { enabled: open && Boolean(selectedService) },
  );
  const lockedProfessionalInfo = serviceProfessionals.find((professional) => professional.id === initialProfessionalId) ?? lockedProfessional;
  const availabilityInput = useMemo(() => ({ date: appointmentDate, serviceId: serviceId ?? undefined, professionalId: professionalId ?? undefined }), [appointmentDate, serviceId, professionalId]);
  const { data: slots = [], isLoading: slotsLoading } = trpc.availability.slots.useQuery(availabilityInput, { enabled: open && Boolean(appointmentDate) });
  const availableSlots = slots.filter((slot) => slot.status === "available");
  const minDate = getTodayCivilDate();
  const createPendingAppointment = trpc.appointments.request.useMutation({ onError: (error) => toast.error(error.message) });

  useEffect(() => {
    if (open) {
      setServiceId(initialServiceId && availableServices.some((service) => service.id === initialServiceId) ? initialServiceId : availableServices[0]?.id ?? null);
      setAppointmentTime("");
      setProfessionalId(initialProfessionalId);
      setClientName("");
      setClientPhone("");
      setReason("");
    }
  }, [availableServices, open, initialProfessionalId, initialServiceId]);

  useEffect(() => {
    if (appointmentTime && !availableSlots.some((slot) => slot.time === appointmentTime)) setAppointmentTime("");
  }, [availableSlots, appointmentTime]);

  useEffect(() => {
    if (professionalLocked && initialProfessionalId) {
      setProfessionalId(initialProfessionalId);
      return;
    }
    if (serviceProfessionals.length === 1) {
      setProfessionalId(serviceProfessionals[0].id);
    } else if (professionalId && !serviceProfessionals.some((professional) => professional.id === professionalId)) {
      setProfessionalId(null);
    }
  }, [serviceProfessionals, professionalId]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!selectedService || !appointmentTime) return;
    if (!clientName.trim() || !clientPhone.trim()) {
      toast.error("Informe seu nome e telefone para enviar a solicitação.");
      return;
    }

    const reasonText = reason.trim() ? ` Motivo: ${reason.trim()}.` : "";
    try {
      const createdAppointment = await createPendingAppointment.mutateAsync({ serviceId: selectedService.id, professionalId: professionalId ?? undefined, appointmentDate, appointmentTime, clientName: clientName.trim(), clientPhone: clientPhone.trim(), reason: reason.trim() || undefined });
      const assignedProfessionalId = createdAppointment?.professionalId ?? professionalId;
      const whatsappTarget = resolveProfessionalWhatsAppTarget(serviceProfessionals, assignedProfessionalId);
      const professionalText = whatsappTarget.professionalName ? ` com ${whatsappTarget.professionalName}` : " (sem preferência de barbeiro)";
      const message = `Olá! Gostaria de agendar o serviço de ${selectedService.name}${professionalText} no dia ${formatCivilDateForWhatsApp(appointmentDate)}, às ${formatTimeForWhatsApp(appointmentTime)}.${reasonText} Meu nome é ${clientName.trim()} e meu telefone é ${clientPhone.trim()}. Vim pelo site da Gb Barbearia.`;
      window.open(buildWhatsAppUrl(message, whatsappTarget.phone ?? undefined), "_blank", "noopener,noreferrer");
      toast.success("Solicitação enviada! A administradora confirmará seu horário.");
      onOpenChange(false);
    } catch {
      // O erro já é exibido pelo callback da mutation; o WhatsApp não é aberto se o salvamento falhar.
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto rounded-3xl">
        <DialogHeader><DialogTitle className="font-serif text-3xl">Escolha seu horário</DialogTitle><DialogDescription>Selecione o serviço, a data e um horário disponível. O botão Agendar abrirá o WhatsApp com os dados preenchidos.</DialogDescription></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div><Label htmlFor="booking-service">Serviço</Label><select id="booking-service" value={serviceId ?? ""} onChange={(event) => setServiceId(event.target.value ? Number(event.target.value) : null)} className="mt-1 flex h-11 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"><option value="">Selecione um serviço</option>{availableServices.map((service) => <option key={service.id} value={service.id}>{service.name}</option>)}</select>{professionalLocked && <p className="mt-1 text-xs text-[#A5A5A5]">Exibindo apenas serviços deste barbeiro.</p>}</div>
          <div>
            <Label className="block mb-2 font-medium text-[#FFFFFF]">Barbeiro</Label>
            {professionalLocked ? (
              <div className="flex items-center gap-3 rounded-2xl border border-[#383838] bg-[#242424] p-3 shadow-sm"><div className="h-14 w-14 shrink-0 overflow-hidden rounded-full border border-[#C8A45D]/30 bg-[#1C1C1C]">{lockedProfessionalInfo?.avatarUrl ? <img src={lockedProfessionalInfo.avatarUrl} alt={lockedProfessionalInfo.name} className="h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center bg-[#242424] font-serif text-lg font-semibold text-[#C8A45D]">{lockedProfessionalInfo?.name?.charAt(0) || "✓"}</div>}</div><div className="min-w-0"><p className="text-xs font-semibold uppercase tracking-wider text-[#C8A45D]">Barbeiro selecionado</p><p className="truncate font-serif text-base font-medium text-[#FFFFFF]">{lockedProfessionalInfo?.name || "Barbeiro do perfil"}</p>{lockedProfessionalInfo?.specialty && <p className="truncate text-xs text-[#756265]">{lockedProfessionalInfo.specialty}</p>}<p className="text-xs text-[#756265]">Agendamento direcionado para este perfil.</p></div></div>
            ) : professionalsLoading ? (
              <p className="text-xs text-muted-foreground">Carregando barbeiros...</p>
            ) : serviceProfessionals.length === 1 ? (
              <div className="flex items-center gap-3 rounded-2xl border border-[#383838] bg-[#242424] p-3 shadow-sm">
                <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full border border-[#C8A45D]/30 bg-[#1C1C1C]">
                  {serviceProfessionals[0].avatarUrl ? (
                    <img src={serviceProfessionals[0].avatarUrl} alt={serviceProfessionals[0].name} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-[#242424] font-serif text-sm font-semibold text-[#C8A45D]">
                      {serviceProfessionals[0].name.charAt(0)}
                    </div>
                  )}
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#C8A45D]">Barbeiro responsável</p>
                  <p className="font-serif text-base font-medium text-[#FFFFFF]">{serviceProfessionals[0].name}</p>
                  {serviceProfessionals[0].specialty && <p className="text-xs text-[#756265]">{serviceProfessionals[0].specialty}</p>}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                {/* Opção Sem Preferência */}
                <button
                  type="button"
                  onClick={() => setProfessionalId(null)}
                  className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all ${
                    professionalId === null
                      ? "border-[#C8A45D] bg-[#242424] shadow-sm ring-2 ring-[#b87545]/20"
                      : "border-[#383838] bg-[#1C1C1C] hover:border-[#C8A45D]/50 hover:bg-[#242424]"
                  }`}
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#242424] text-[#C8A45D] font-serif text-lg font-bold">
                    ★
                  </div>
                  <p className="mt-2 text-xs font-bold text-[#FFFFFF]">Sem preferência</p>
                  <p className="text-[10px] text-[#756265]">Qualquer barbeiro</p>
                </button>

                {/* Lista de Barbeiros com Foto */}
                {serviceProfessionals.map((professional) => {
                  const isSelected = professionalId === professional.id;
                  return (
                    <button
                      key={professional.id}
                      type="button"
                      onClick={() => setProfessionalId(professional.id)}
                      className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-center transition-all ${
                        isSelected
                          ? "border-[#C8A45D] bg-[#242424] shadow-sm ring-2 ring-[#b87545]/20"
                          : "border-[#383838] bg-[#1C1C1C] hover:border-[#C8A45D]/50 hover:bg-[#242424]"
                      }`}
                    >
                      <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full border border-[#C8A45D]/30 bg-[#1C1C1C] shadow-sm">
                        {professional.avatarUrl ? (
                          <img src={professional.avatarUrl} alt={professional.name} className="h-full w-full object-cover" />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center bg-[#242424] font-serif text-sm font-semibold text-[#C8A45D]">
                            {professional.name.charAt(0)}
                          </div>
                        )}
                      </div>
                      <p className="mt-2 truncate w-full text-xs font-bold text-[#FFFFFF]">{professional.name}</p>
                      <p className="truncate w-full text-[10px] text-[#756265]">{professional.specialty || "Especialista"}</p>
                    </button>
                  );
                })}
              </div>
            )}
            <p className="mt-2 text-xs text-muted-foreground">{serviceProfessionals.length === 1 ? "Barbeiro atribuída automaticamente para este serviço." : 'Selecione um barbeiro ou escolha "Sem preferência".'}</p>
          </div>
          <div><Label htmlFor="booking-date">Data</Label><Input id="booking-date" type="date" min={minDate} value={appointmentDate} onChange={(event) => setAppointmentDate(event.target.value)} className="mt-1 h-11 rounded-xl" /></div>
          <div><Label>Horários do dia</Label>{slotsLoading ? <p className="mt-2 text-sm text-muted-foreground">Consultando disponibilidade...</p> : !selectedService ? <p className="mt-2 text-sm text-muted-foreground">Escolha um serviço para visualizar os horários.</p> : slots.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">Não há expediente configurado para este dia.</p> : <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-4">{slots.map((slot) => <button key={slot.time} type="button" disabled={slot.status !== "available"} onClick={() => setAppointmentTime(slot.time)} className={`rounded-xl border px-2 py-2 text-sm transition-colors ${slot.status === "available" ? appointmentTime === slot.time ? "border-[#C8A45D] bg-[#b87545] text-white" : "border-[#e6c9ce] bg-[#1C1C1C] text-[#A5A5A5] hover:bg-[#242424]" : "cursor-not-allowed border-slate-200 bg-[#242424] text-slate-400 line-through"}`} title={slot.status === "available" ? "Disponível" : "Indisponível"}>{slot.time}</button>)}</div>}<p className="mt-2 text-xs text-muted-foreground">Horários cinza estão ocupados ou indisponíveis.</p></div>
          <div className="grid gap-4 sm:grid-cols-2"><div><Label htmlFor="booking-name">Seu nome</Label><Input id="booking-name" required value={clientName} onChange={(event) => setClientName(event.target.value)} placeholder="Nome completo" className="mt-1 rounded-xl" /></div><div><Label htmlFor="booking-phone">Seu telefone</Label><Input id="booking-phone" required value={clientPhone} onChange={(event) => setClientPhone(event.target.value)} placeholder="(54) 99999-9999" className="mt-1 rounded-xl" /></div></div>
          <div><Label htmlFor="booking-reason">Nos conte um pouco por que você escolheu esse serviço (opcional)</Label><textarea id="booking-reason" value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Ex: Sinto dores lombares e preciso relaxar..." rows={2} className="mt-1 flex w-full rounded-xl border border-input bg-background px-3 py-2 text-sm" /></div>
          <Button type="submit" disabled={!selectedService || !appointmentTime || !clientName.trim() || !clientPhone.trim() || createPendingAppointment.isPending} className="h-12 w-full rounded-full bg-[#b87545] hover:bg-[#E0BD72]"><MessageCircle className="mr-2 h-4 w-4" />Agendar pelo WhatsApp</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

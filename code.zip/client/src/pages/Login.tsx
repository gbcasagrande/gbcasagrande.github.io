import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Lock, User, ArrowLeft, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

const BARBER_LOGO = "/manus-storage/gb-barbearia-logo-transparent_77dbd48f.png";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [, setLocation] = useLocation();

  const { data: admin, isLoading: checkingAuth } = trpc.adminAuth.me.useQuery();
  
  const utils = trpc.useUtils();

  const loginMutation = trpc.adminAuth.login.useMutation({
    onSuccess: async () => {
      toast.success("Login realizado com sucesso!");
      await utils.adminAuth.me.invalidate();
      window.location.href = "/agenda";
    },
    onError: (error) => {
      toast.error(error.message || "Credenciais inválidas");
    },
  });

  useEffect(() => {
    if (admin && !checkingAuth) {
      setLocation("/agenda");
    }
  }, [admin, checkingAuth, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error("Preencha todos os campos");
      return;
    }
    loginMutation.mutate({ username, password });
  };

  if (checkingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[oklch(0.99_0.008_80)]">
        <Loader2 className="h-8 w-8 animate-spin text-[oklch(0.63_0.12_53)]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0B0B0B] p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23c46b85' fill-opacity='0.15'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }} />

      <div className="relative z-10 w-full max-w-md">
        <a 
          href="/" 
          className="inline-flex items-center gap-2 text-[oklch(0.63_0.12_53)] hover:text-[oklch(0.50_0.12_45)] mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Voltar ao site
        </a>

        <Card className="border-none shadow-xl bg-[#0B0B0B]/95 backdrop-blur-sm">
          <CardHeader className="text-center pb-2">
            <div className="flex justify-center mb-4">
              <div className="h-24 w-24 overflow-hidden rounded-2xl">
                <img src={BARBER_LOGO} alt="Logo da Gb Barbearia" className="h-full w-full object-contain" />
              </div>
            </div>
            <CardTitle className="text-2xl font-light text-[oklch(0.22_0.025_70)]" style={{ fontFamily: "'Playfair Display', Georgia, serif" }}>
              Área Administrativa
            </CardTitle>
            <CardDescription className="text-[oklch(0.43_0.025_70)]">
              Entre para cuidar da agenda da casa
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-[oklch(0.35_0.03_70)]">
                  Usuário
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[oklch(0.58_0.03_70)]" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Digite seu usuário"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="pl-10 border-[oklch(0.86_0.025_75)] focus:border-[oklch(0.63_0.12_53)] focus:ring-[oklch(0.63_0.12_53)]"
                    disabled={loginMutation.isPending}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-[oklch(0.35_0.03_70)]">
                  Senha
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[oklch(0.58_0.03_70)]" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Digite sua senha"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 border-[oklch(0.86_0.025_75)] focus:border-[oklch(0.63_0.12_53)] focus:ring-[oklch(0.63_0.12_53)]"
                    disabled={loginMutation.isPending}
                  />
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)] text-white py-5"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  "Entrar"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <p className="text-center text-sm text-[oklch(0.43_0.025_70)] mt-6">
          Gb Barbearia · Área reservada da equipe
        </p>
      </div>
    </div>
  );
}

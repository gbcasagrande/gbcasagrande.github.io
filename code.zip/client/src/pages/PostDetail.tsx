import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, Share2, MessageCircle, CalendarDays, User, Clock, Check, Copy, Instagram } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function PostDetail() {
  const [, params] = useRoute("/post/:id");
  const postId = Number(params?.id || 0);

  const { data: post, isLoading, refetch } = trpc.posts.getById.useQuery(
    { id: postId },
    { enabled: postId > 0 }
  );

  const { data: earlierPosts = [] } = trpc.posts.earlier.useQuery(
    { excludeId: postId > 0 ? postId : 1, limit: 4 },
    { enabled: postId > 0 && Boolean(post) }
  );

  const reactMutation = trpc.posts.react.useMutation({
    onSuccess: () => {
      toast.success("Obrigado pela sua reação!");
      refetch();
    },
    onError: (err) => toast.error(err.message),
  });

  const [selectedServiceId, setSelectedServiceId] = useState<number | null>(null);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0B0B0B]">
        <p className="text-sm text-muted-foreground">Carregando postagem...</p>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0B0B0B] px-4 text-center">
        <h1 className="font-serif text-3xl text-[oklch(0.22_0.025_70)]">Postagem não encontrada</h1>
        <p className="mt-2 text-muted-foreground">O artigo que você procura pode ter sido removido ou não existe.</p>
        <Button asChild className="mt-6 bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)]">
          <Link href="/">Voltar para a página inicial</Link>
        </Button>
      </div>
    );
  }

  const shareUrl = window.location.href;
  const shareTitle = encodeURIComponent(post.title);
  const shareText = encodeURIComponent(`${post.title} — Gb Barbearia`);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    toast.success("Link copiado para a área de transferência!");
  };

  const handleShareWhatsApp = () => {
    window.open(`https://api.whatsapp.com/send?text=${shareText}%20${encodeURIComponent(shareUrl)}`, "_blank");
  };

  const handleShareFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, "_blank");
  };

  const handleShareInstagram = () => {
    toast.info("Copie o link acima e compartilhe no Instagram!");
  };

  return (
    <div className="min-h-screen bg-[#0B0B0B] text-[oklch(0.22_0.025_70)]">
      {/* Top Bar Navigation */}
      <header className="sticky top-0 z-40 border-b border-[#383838] bg-[#0B0B0B]/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-5 py-4 sm:px-8">
          <Button asChild variant="ghost" size="sm" className="gap-2 text-[oklch(0.35_0.03_70)] hover:bg-[#242424]">
            <Link href="/">
              <ArrowLeft className="h-4 w-4" /> Voltar ao início
            </Link>
          </Button>
          <span className="text-xs font-semibold uppercase tracking-[0.16em] text-[oklch(0.63_0.12_53)]">Gb Barbearia</span>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-5 py-10 sm:px-8 sm:py-16">
        <article className="space-y-8">
          {post.coverImageUrl && (
            <div className="overflow-hidden rounded-3xl border border-[#383838] bg-[#242424] shadow-sm">
              <img src={post.coverImageUrl} alt={post.title} className="h-72 w-full object-cover sm:h-96" />
            </div>
          )}

          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5 font-medium text-[oklch(0.63_0.12_53)]">
                <User className="h-3.5 w-3.5" /> {post.authorName}
              </span>
              <span>•</span>
              <span className="inline-flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" /> {new Date(post.createdAt).toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" })}
              </span>
            </div>

            <h1 className="font-serif text-3xl sm:text-5xl leading-tight text-[oklch(0.22_0.035_10)]">{post.title}</h1>
            <p className="text-lg leading-relaxed text-[oklch(0.35_0.03_70)] font-medium">{post.summary}</p>
          </div>

          <hr className="border-[#383838]" />

          {/* Main Content */}
          <div className="prose prose-neutral max-w-none text-base leading-8 text-[oklch(0.32_0.035_10)] space-y-6">
            {post.content.split("\n\n").map((paragraph: string, pIdx: number) => (
              <p key={pIdx} className="leading-8">
                {paragraph.split("\n").map((line: string, lIdx: number, arr: Array<string>) => {
                  // Process bold markup **text** or __text__ safely
                  const parts = line.split(/(\*\*.*?\*\*|__.*?__)/g);
                  return (
                    <span key={lIdx}>
                      {parts.map((part, partIdx) => {
                        if ((part.startsWith("**") && part.endsWith("**")) || (part.startsWith("__") && part.endsWith("__"))) {
                          return <strong key={partIdx} className="font-bold text-[oklch(0.22_0.035_10)]">{part.slice(2, -2)}</strong>;
                        }
                        return part;
                      })}
                      {lIdx < arr.length - 1 && <br />}
                    </span>
                  );
                })}
              </p>
            ))}
          </div>

          {/* Reactions & Share Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[#383838] bg-[#242424] p-5">
            <div className="flex items-center gap-3">
              <Button
                onClick={() => reactMutation.mutate({ id: post.id })}
                disabled={reactMutation.isPending}
                className="gap-2 rounded-full bg-[oklch(0.63_0.12_53)] px-5 text-white hover:bg-[oklch(0.50_0.12_45)]"
              >
                <Heart className="h-4 w-4 fill-current" />
                <span>Reagir</span>
              </Button>
              <span className="text-sm font-semibold text-[oklch(0.63_0.12_53)]">{post.reactionsCount || 0} reações</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mr-1">Compartilhar:</span>
              <Button variant="outline" size="sm" onClick={handleShareWhatsApp} title="Compartilhar no WhatsApp" className="rounded-full border-[#383838] text-emerald-700 hover:bg-emerald-50">
                <MessageCircle className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleShareFacebook} title="Compartilhar no Facebook" className="rounded-full border-[#383838] text-blue-700 hover:bg-blue-50">
                <Share2 className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleShareInstagram} title="Compartilhar no Instagram" className="rounded-full border-[#383838] text-[#C8A45D] hover:bg-[#242424]">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleCopyLink} title="Copiar link" className="rounded-full border-[#383838]">
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Related Services Section */}
          {post.services && post.services.length > 0 && (
            <div className="rounded-3xl border border-[#383838] bg-[#1C1C1C] p-6 sm:p-8 space-y-5 shadow-sm">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[oklch(0.63_0.12_53)]">Serviços recomendados</p>
                <h3 className="font-serif text-2xl text-[oklch(0.22_0.025_70)] mt-1">Serviços mencionados neste artigo</h3>
                <p className="text-sm text-muted-foreground mt-1">Agende seu horário diretamente com um clique.</p>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                {post.services.map((service: any) => (
                  <div key={service.id} className="rounded-2xl border border-[#383838] bg-[#1C1C1C] p-5 flex flex-col justify-between space-y-4">
                    <div>
                      <h4 className="font-serif text-lg font-semibold text-[oklch(0.22_0.025_70)]">{service.name}</h4>
                      <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{service.description || "Serviço personalizado para seu bem-estar."}</p>
                      <p className="mt-3 font-serif text-base text-[oklch(0.63_0.12_53)] font-semibold">
                        {service.priceDisplayMode === "evaluation" ? "Avaliação gratuita" : `R$ ${service.defaultPrice}`}
                      </p>
                    </div>
                    <Button
                      onClick={() => {
                        window.location.href = `/?bookingServiceId=${service.id}#agendar`;
                      }}
                      className="w-full bg-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.50_0.12_45)] text-white"
                    >
                      <CalendarDays className="mr-2 h-4 w-4" /> Agendar este serviço
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Conheça Nossos Serviços */}
          <div className="rounded-3xl border border-[#383838] bg-[#1C1C1C] p-6 sm:p-8 space-y-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[oklch(0.63_0.12_53)]">Gb Barbearia</p>
                <h3 className="font-serif text-2xl text-[oklch(0.22_0.025_70)] mt-1">Conheça nossos serviços</h3>
              </div>
              <Button asChild variant="outline" className="border-[oklch(0.72_0.09_52)] text-[oklch(0.63_0.12_53)] hover:bg-[oklch(0.93_0.03_75)]">
                <Link href="/#servicos">Ver todos os serviços</Link>
              </Button>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Oferecemos uma variedade de serviços em barbearia, cuidados para cabelo e barba para promover seu equilíbrio físico e mental em Marau - RS.
            </p>
          </div>

          {/* Earlier Posts Section (Compact cards) */}
          {earlierPosts.length > 0 && (
            <div className="space-y-6 pt-6">
              <div className="border-b border-[#383838] pb-3 flex items-center justify-between">
                <h3 className="font-serif text-2xl text-[oklch(0.22_0.025_70)]">Outras postagens anteriores</h3>
                <Button asChild variant="ghost" size="sm" className="text-[oklch(0.63_0.12_53)]">
                  <Link href="/artigos">Ver todos os artigos</Link>
                </Button>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                {earlierPosts.map((earlier: any) => (
                  <a
                    key={earlier.id}
                    href={`/post/${earlier.id}`}
                    className="group rounded-2xl border border-[#383838] bg-[#1C1C1C] p-4 shadow-sm transition-all hover:shadow-md hover:border-[oklch(0.63_0.12_53)] flex gap-4 items-center"
                  >
                    {earlier.coverImageUrl ? (
                      <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-[#242424]">
                        <img src={earlier.coverImageUrl} alt={earlier.title} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                      </div>
                    ) : (
                      <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-[#242424] flex items-center justify-center text-xs text-muted-foreground">Artigo</div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-[11px] text-muted-foreground">{new Date(earlier.createdAt).toLocaleDateString("pt-BR")}</p>
                      <h4 className="font-serif text-base font-semibold text-[oklch(0.22_0.025_70)] group-hover:text-[oklch(0.63_0.12_53)] transition-colors line-clamp-2">{earlier.title}</h4>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}
        </article>
      </main>

      <footer className="mt-20 border-t border-[#383838] bg-[#0B0B0B] py-7 text-[#cfc2b3]">
        <div className="mx-auto flex max-w-4xl flex-col gap-4 px-5 text-sm sm:flex-row sm:items-center sm:justify-between sm:px-8">
          <p>© 2026 Gb Barbearia · Barbearia Premium</p>
          <Link href="/" className="font-semibold text-[#d9a77f] hover:text-white">Voltar à página inicial</Link>
        </div>
      </footer>
    </div>
  );
}

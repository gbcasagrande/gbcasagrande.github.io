import { useMemo, useState } from "react";
import { Link, useRoute } from "wouter";
import { ArrowLeft, ArrowUpRight, BadgeCheck, CalendarDays, Clock, Heart, Instagram, MapPin, MessageCircle, Share2, Sparkles, User } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { getServicePromotionalPrice, parseServiceBenefits } from "@shared/serviceCatalog";
import NotFound from "@/pages/NotFound";
import { BookingDialog } from "@/pages/Home";
import { toast } from "sonner";

const serviceIcons: Record<string, typeof Sparkles> = { Sparkles, Heart };

function getInstagramUrl(value: string | null | undefined) {
  const normalized = value?.trim();
  if (!normalized) return null;
  if (normalized.startsWith("http://") || normalized.startsWith("https://")) return normalized;
  return `https://www.instagram.com/${normalized.replace(/^@/, "")}/`;
}

function formatPrice(price: string, mode?: string) {
  if (mode === "evaluation") return "Agendar uma avaliação";
  const numeric = Number(price);
  return Number.isFinite(numeric) ? numeric.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) : price;
}

export default function ProfessionalProfile() {
  const [, params] = useRoute("/barbeiro/:slug");
  const slug = params?.slug?.trim() || "";
  const { data: profile, isLoading } = trpc.professionals.profile.useQuery({ slug }, { enabled: Boolean(slug) });
  const instagramUrl = useMemo(() => getInstagramUrl(profile?.instagramUrl), [profile?.instagramUrl]);
  const profilePath = profile ? `/barbeiro/${profile.profileSlug || profile.id}` : `/barbeiro/${slug}`;
  const [bookingOpen, setBookingOpen] = useState(false);
  const [bookingServiceId, setBookingServiceId] = useState<number | null>(null);
  const profileServices = useMemo(() => profile?.services.map((service) => ({ ...service, professionals: [{ id: profile.id }] })) ?? [], [profile]);
  const openBooking = (serviceId?: number) => {
    setBookingServiceId(serviceId ?? null);
    setBookingOpen(true);
  };
  const shareProfile = async () => {
    const url = new URL(profilePath, window.location.origin).toString();
    try {
      if (navigator.share) {
        await navigator.share({ title: `${profile?.name || "Perfil barbeiro"} | Gb Barbearia`, text: `Conheça o perfil de ${profile?.name || "um barbeiro"} na Gb Barbearia.`, url });
      } else {
        await navigator.clipboard.writeText(url);
        toast.success("Link do perfil copiado!");
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      toast.error("Não foi possível compartilhar o perfil.");
    }
  };

  if (!slug || (!isLoading && !profile)) return <NotFound />;
  if (isLoading) return <div className="flex min-h-screen items-center justify-center bg-[#0B0B0B] text-sm text-[#A5A5A5]">Carregando perfil...</div>;
  if (!profile) return <NotFound />;

  return (
    <main className="min-h-screen overflow-x-clip bg-[#1C1C1C] text-[#FFFFFF]">
      <header className="sticky top-0 z-30 border-b border-[#383838]/80 bg-[#0B0B0B]/95 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
          <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-[#A5A5A5] transition-colors hover:text-[#C8A45D]"><ArrowLeft className="h-4 w-4" /> Voltar para a barbearia</Link>
          <span className="font-serif text-lg text-[#FFFFFF]">Gb Barbearia</span>
        </div>
      </header>

      <section className="mx-auto max-w-6xl">
        <div className="relative h-52 overflow-visible bg-gradient-to-br from-[#dc5746] via-[#ef8568] to-[#f6c2a2] sm:h-72">
          {profile.coverUrl && <img src={profile.coverUrl} alt={`Capa de ${profile.name}`} className="h-full w-full object-cover" />}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-white/10" />
          <div className="absolute -bottom-20 left-6 z-20 h-40 w-40 rounded-full bg-[#1C1C1C] p-1 shadow-[0_14px_30px_rgba(52,40,42,0.2)] sm:left-12 sm:h-48 sm:w-48 sm:p-1.5">
            <div className="flex h-full w-full items-center justify-center overflow-hidden rounded-full bg-[#242424] text-[#C8A45D]">{profile.avatarUrl ? <img src={profile.avatarUrl} alt={profile.name} className="h-full w-full object-cover" /> : <User className="h-16 w-16" />}</div>
          </div>
        </div>
        <div className="px-6 pb-8 pt-24 sm:px-12 sm:pt-24">
          <div className="flex flex-col justify-between gap-5 md:flex-row md:items-start">
            <div className="max-w-2xl">
              <div className="flex flex-wrap items-center gap-2"><h1 className="font-sans text-3xl font-extrabold tracking-tight text-[#FFFFFF] sm:text-5xl">{profile.name}</h1>{profile.verified === 1 && <BadgeCheck className="h-8 w-8 fill-[#198fe0] text-white sm:h-9 sm:w-9" aria-label="Perfil verificado" />}</div>
              <p className="mt-3 text-lg text-[#A5A5A5]">{profile.specialty || "Barbeiro da Gb Barbearia"}</p>
              {profile.bio && <p className="mt-4 max-w-xl whitespace-pre-line text-base leading-7 text-[#A5A5A5]">{profile.bio}</p>}
            </div>
            <div className="flex shrink-0 gap-3">
              <button type="button" onClick={() => openBooking()} className="inline-flex h-12 items-center gap-2 rounded-full bg-[#b87545] px-6 text-sm font-bold text-white shadow-sm transition hover:bg-[#E0BD72]"><MessageCircle className="h-5 w-5" /> Fale comigo</button>
              {instagramUrl && <a href={instagramUrl} target="_blank" rel="noreferrer" aria-label="Instagram" className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-[#b87545] text-white transition hover:bg-[#E0BD72]"><Instagram className="h-5 w-5" /></a>}
              <button type="button" onClick={shareProfile} aria-label="Compartilhar ou copiar link do perfil" title="Compartilhar ou copiar link do perfil" className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-[#b87545] text-white transition hover:bg-[#E0BD72]"><Share2 className="h-5 w-5" /></button>
            </div>
          </div>
          <div className="mt-5 flex flex-wrap gap-x-5 gap-y-2 text-sm text-[#A5A5A5]"><span className="inline-flex items-center gap-1.5"><MapPin className="h-4 w-4 text-[#C8A45D]" /> Marau - RS</span></div>
        </div>
      </section>

      <section className="border-t border-[#383838] bg-[#1C1C1C]">
        <div className="mx-auto max-w-6xl px-6 py-12 sm:px-12 sm:py-16">
          <div className="mb-8 flex flex-col justify-between gap-3 sm:flex-row sm:items-end"><div><p className="text-xs font-bold uppercase tracking-[0.2em] text-[#C8A45D]">Escolha seu cuidado</p><h2 className="mt-2 text-3xl font-extrabold tracking-tight text-[#FFFFFF] sm:text-4xl">Serviços com {profile.name.split(" ")[0]}</h2><p className="mt-2 text-sm leading-6 text-[#A5A5A5]">Agendamento direcionado para este perfil.</p></div><span className="text-sm text-[#A5A5A5]">{profile.services.length} {profile.services.length === 1 ? "serviço disponível" : "serviços disponíveis"}</span></div>
          {profile.services.length === 0 ? <Card className="border-[#383838] bg-[#1C1C1C]"><CardContent className="p-8 text-center text-sm text-[#A5A5A5]">Os serviços deste barbeiro serão publicados em breve.</CardContent></Card> : <div className="grid gap-5 md:grid-cols-2">{profile.services.map((service) => { const Icon = serviceIcons[service.icon] || Sparkles; const benefits = parseServiceBenefits(service.benefits); return <Card key={service.id} className={`group relative overflow-hidden bg-[#1C1C1C] transition-transform hover:-translate-y-1 ${service.isFeatured === 1 ? "border-2 border-[#C8A45D] shadow-[0_16px_36px_rgba(200,164,93,0.18)]" : "border-[#383838] shadow-[0_12px_32px_rgba(86,53,52,0.06)]"}`}><CardContent className="p-6">{service.isFeatured === 1 ? <div className="mb-4 inline-flex items-center gap-1.5 rounded-full bg-[#b87545] px-3 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-white"><Sparkles className="h-3 w-3" /> Serviço em destaque</div> : null}<div className="flex items-start justify-between gap-4"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#242424] text-[#C8A45D]"><Icon className="h-6 w-6" /></span><div className="text-right">{service.discountPercent ? <p className="mb-1 text-xs font-bold uppercase tracking-wide text-[#C8A45D]">{service.promotionLabel || "Oferta especial"} · -{service.discountPercent}%</p> : null}<p className="font-semibold text-[#C8A45D]">{service.discountPercent ? <><span className="mr-2 text-xs text-[#A5A5A5] line-through">{formatPrice(String(service.defaultPrice), service.priceDisplayMode)}</span>{formatPrice(String(getServicePromotionalPrice(service.defaultPrice, service.discountPercent)), service.priceDisplayMode)}</> : formatPrice(String(service.defaultPrice), service.priceDisplayMode)}</p>{service.duration && <p className="mt-1 inline-flex items-center gap-1 text-xs text-[#A5A5A5]"><Clock className="h-3.5 w-3.5" /> {service.duration} min</p>}</div></div><h3 className="mt-5 font-serif text-2xl text-[#FFFFFF]">{service.name}</h3>{service.description && <p className="mt-2 text-sm leading-6 text-[#A5A5A5]">{service.description}</p>}{benefits.length > 0 && <ul className="mt-4 grid gap-2 text-sm text-[#A5A5A5] sm:grid-cols-2">{benefits.slice(0, 4).map((benefit) => <li key={benefit} className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-[#b87545]" />{benefit}</li>)}</ul>}<button type="button" onClick={() => openBooking(service.id)} className="mt-6 inline-flex h-11 w-full items-center justify-center gap-2 rounded-full bg-[#b87545] px-4 text-sm font-bold text-white transition-colors hover:bg-[#E0BD72]"><CalendarDays className="h-4 w-4" /> Agendar este serviço <ArrowUpRight className="h-4 w-4" /></button></CardContent></Card>; })}</div>}
        </div>
      </section>
      <section className="border-t border-[#383838] bg-[#0B0B0B]">
        <div className="mx-auto max-w-6xl px-6 py-10 sm:px-12 sm:py-14">
          <div className="mb-5 flex items-center gap-3 text-[#f5eaea]"><MapPin className="h-5 w-5 text-[#C8A45D]" /><h2 className="font-serif text-2xl">Nossa localização</h2></div>
          <p className="mb-5 text-sm text-[#cfc2b3]">Rua Nicandro Oltramari, 309 · Marau, RS</p>
          <div className="overflow-hidden rounded-3xl border border-white/10"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3636.4289938268!2d-51.9234!3d-28.9823!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x951d8c8c8c8c8c8d%3A0x8c8c8c8c8c8c8c8c!2sRua%20Nicandro%20Oltramari%2C%20309%20-%20Marau%2C%20RS!5e0!3m2!1spt-BR!2sbr!4v1234567890" title="Localização do barbeiro na Gb Barbearia" className="h-64 w-full grayscale-[0.2]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" /></div>
        </div>
      </section>
      <footer className="border-t border-[#383838] bg-[#0B0B0B] px-6 py-6 text-center text-sm text-[#cfc2b3]">
        Gb Barbearia ® 2026 | Desenvolvido por <a href="https://www.instagram.com/gbcasagrande/" target="_blank" rel="noreferrer" className="font-semibold text-[#d9a77f] transition-colors hover:text-white">@gbcasagrande</a>
      </footer>
      {profile && <BookingDialog open={bookingOpen} onOpenChange={setBookingOpen} services={profileServices} initialServiceId={bookingServiceId} initialProfessionalId={profile.id} professionalLocked lockedProfessional={{ id: profile.id, name: profile.name, specialty: profile.specialty, avatarUrl: profile.avatarUrl }} />}
    </main>
  );
}

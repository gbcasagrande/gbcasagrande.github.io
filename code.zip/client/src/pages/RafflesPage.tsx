import { useEffect, useMemo, useState } from "react";
import { Link, useRoute } from "wouter";
import { ArrowLeft, ArrowUpRight, CalendarDays, Check, Gift, Hash, Instagram, Loader2, MessageCircle, Phone, Search, Share2, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { buildWhatsAppUrl } from "@/lib/whatsapp";
import { toast } from "sonner";

const NAVALHA_LOGO = "/manus-storage/gb-barbearia-logo-transparent_77dbd48f.png";
const INSTAGRAM_URL = "https://www.instagram.com/navalhamarau/";

function formatDrawDate(date: string, time: string) {
  const [year, month, day] = date.split("-");
  return `${day}/${month}/${year} às ${time.slice(0, 5)}`;
}

function formatNumber(value: number) {
  return `#${String(value).padStart(3, "0")}`;
}

type RaffleLookup = {
  displayName: string;
  numbers: number[];
  winnerNumber: number | null;
  isWinner: boolean;
};

export default function RafflesPage() {
  const [, params] = useRoute("/sorteios/:id");
  const raffleId = params?.id ? Number(params.id) : null;
  const activeQuery = trpc.raffles.active.useQuery(undefined, { enabled: !raffleId });
  const detailQuery = trpc.raffles.getById.useQuery({ id: raffleId || 0 }, { enabled: Boolean(raffleId) });
  const historyQuery = trpc.raffles.list.useQuery();
  const registerMutation = trpc.raffles.register.useMutation();
  const claimShareMutation = trpc.raffles.claimShare.useMutation();
  const utils = trpc.useUtils();

  const raffle = raffleId ? detailQuery.data : activeQuery.data;
  const winnerName = raffleId ? detailQuery.data?.winnerName : null;
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [lookupPhone, setLookupPhone] = useState("");
  const [registration, setRegistration] = useState<{ displayName: string; numbers: number[]; shareToken?: string } | null>(null);
  const [lookup, setLookup] = useState<RaffleLookup | null>(null);
  const [shareUrl, setShareUrl] = useState("");

  const queryShareToken = useMemo(() => new URLSearchParams(window.location.search).get("share"), []);
  useEffect(() => {
    if (!queryShareToken) return;
    claimShareMutation.mutate({ shareToken: queryShareToken }, {
      onSuccess: (result) => {
        if (result) {
          setRegistration({ displayName: result.displayName, numbers: result.numbers });
          toast.success(result.added ? "Você ganhou mais um número!" : "Este compartilhamento já foi contabilizado.");
        }
      },
      onError: () => toast.error("Não foi possível validar este link de compartilhamento."),
    });
  // O token vem da URL e deve ser processado uma única vez.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryShareToken]);

  const handleRegister = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!raffle) return;
    try {
      const result = await registerMutation.mutateAsync({ raffleId: raffle.id, name, phone });
      if (!result) throw new Error("Não foi possível reservar seu número.");
      setRegistration(result);
      setShareUrl(`${window.location.origin}/sorteios/${raffle.id}?share=${result.shareToken}`);
      setName("");
      setPhone("");
      toast.success("Inscrição confirmada! Seu número foi reservado.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível fazer sua inscrição.");
    }
  };

  const handleShare = async () => {
    if (!registration?.shareToken || !raffle) return;
    try {
      const result = await claimShareMutation.mutateAsync({ shareToken: registration.shareToken });
      if (result) setRegistration({ ...registration, numbers: result.numbers });
      const url = shareUrl || `${window.location.origin}/sorteios/${raffle.id}?share=${registration.shareToken}`;
      if (navigator.share) await navigator.share({ title: raffle.title, text: `Participe do sorteio da Gb Barbearia: ${url}`, url });
      else {
        await navigator.clipboard.writeText(url);
        toast.success("Link copiado! Compartilhe para validar seu número extra.");
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      toast.error(error instanceof Error ? error.message : "Não foi possível compartilhar agora.");
    }
  };

  const handleLookup = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!raffle) return;
    try {
      const data = await utils.raffles.numbersByPhone.fetch({ raffleId: raffle.id, phone: lookupPhone });
      if (!data) throw new Error("Nenhum número encontrado para este telefone.");
      setLookup(data);
    } catch (error) {
      setLookup(null);
      toast.error(error instanceof Error ? error.message : "Nenhum número encontrado para este telefone.");
    }
  };

  if (activeQuery.isLoading || detailQuery.isLoading) {
    return <div className="flex min-h-screen items-center justify-center bg-[#0B0B0B] text-[#C8A45D]"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  return (
    <main className="min-h-screen bg-[#0B0B0B] px-4 py-8 text-[#FFFFFF] sm:px-6 sm:py-12">
      <header className="sticky top-0 z-50 -mx-4 -mt-8 border-b border-[#383838]/80 bg-[#0B0B0B]/95 shadow-[0_8px_30px_rgba(0,0,0,0.28)] backdrop-blur-xl sm:-mx-6 sm:-mt-12">
        <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-12">
          <Link href="/" className="group flex items-center gap-3 text-left">
            <span className="flex h-11 w-16 items-center justify-center overflow-hidden rounded-xl transition-transform duration-200 group-hover:-rotate-2"><img src={NAVALHA_LOGO} alt="Logo da Gb Barbearia" className="h-full w-full object-contain" /></span>
            <span><span className="block font-serif text-lg leading-none text-[#FFFFFF]">Gb Barbearia</span><span className="mt-1 block text-[10px] font-medium uppercase tracking-[0.22em] text-[#A5A5A5]">Barbearia Premium</span></span>
          </Link>
          <a href={buildWhatsAppUrl("Olá! Gostaria de agendar um horário na Gb Barbearia. Vim pelo site.")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-[#C8A45D] px-5 py-3 text-sm font-semibold text-[#0B0B0B] shadow-[0_10px_22px_rgba(200,164,93,0.18)] transition hover:bg-[#E0BD72]"><MessageCircle className="h-4 w-4" /><span className="hidden min-[380px]:inline">WhatsApp</span></a>
        </div>
      </header>
      <div className="mx-auto max-w-5xl space-y-8">
        <header className="flex flex-col gap-5 border-b border-[#383838] pb-7 pt-6 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <Button asChild variant="ghost" size="sm" className="-ml-3 gap-2 text-[#A5A5A5] hover:bg-[#242424] hover:text-[#FFFFFF]">
              <Link href="/"><ArrowLeft className="h-4 w-4" /> Voltar ao início</Link>
            </Button>
            <p className="mt-5 text-xs font-bold uppercase tracking-[0.22em] text-[#C8A45D]">Sorteios da casa</p>
            <h1 className="mt-2 font-serif text-4xl sm:text-5xl">Concorra a um cuidado especial.</h1>
            <p className="mt-3 max-w-2xl text-[#A5A5A5]">Cadastre seu nome e telefone, receba seu número e acompanhe tudo com transparência.</p>
          </div>
          <a href="/sorteios" className="text-sm font-semibold text-[#A5A5A5] hover:text-[#C8A45D]">Histórico de sorteios</a>
        </header>

        {raffle ? (
          <section className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
            <Card className="border-[#383838] bg-[#1C1C1C] text-[#FFFFFF]">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#C8A45D]">{raffle.status === "active" ? "Sorteio ativo" : "Sorteio finalizado"}</p>
                    <CardTitle className="mt-2 font-serif text-3xl">{raffle.title}</CardTitle>
                  </div>
                  <div className="rounded-2xl bg-[#242424] p-3 text-[#C8A45D]"><Gift className="h-7 w-7" /></div>
                </div>
                <p className="mt-3 text-[#A5A5A5]">{raffle.description || "Participe e concorra a um serviço especial da Gb Barbearia."}</p>
                <div className="mt-5 grid gap-3 text-sm sm:grid-cols-2">
                  <div className="rounded-xl border border-[#383838] bg-[#242424] p-3"><CalendarDays className="mb-2 h-4 w-4 text-[#C8A45D]" />Sorteio em<br /><strong>{formatDrawDate(raffle.drawDate, raffle.drawTime)}</strong></div>
                  <div className="rounded-xl border border-[#383838] bg-[#242424] p-3"><Trophy className="mb-2 h-4 w-4 text-[#C8A45D]" />Prêmio<br /><strong>{raffle.serviceName}</strong></div>
                </div>
              </CardHeader>
              <CardContent>
                {raffle.status === "active" ? (
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div><Label htmlFor="raffle-name">Nome completo</Label><Input id="raffle-name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Ex.: Gabriel Costa" className="mt-1 border-[#383838] bg-[#0B0B0B] text-white" required /></div>
                    <div><Label htmlFor="raffle-phone">Telefone com WhatsApp</Label><Input id="raffle-phone" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="(54) 99999-9999" className="mt-1 border-[#383838] bg-[#0B0B0B] text-white" required /></div>
                    <Button disabled={registerMutation.isPending} className="w-full bg-[#C8A45D] text-[#0B0B0B] hover:bg-[#E0BD72]">{registerMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Hash className="mr-2 h-4 w-4" />}Quero participar</Button>
                  </form>
                ) : (
                  <div className="rounded-xl border border-[#C8A45D]/40 bg-[#242424] p-5"><p className="text-sm text-[#A5A5A5]">Sorteio encerrado.</p><p className="mt-2 text-2xl font-semibold text-[#C8A45D]">{winnerName || "Vencedor confirmado"}</p><p className="mt-1 text-[#A5A5A5]">Número vencedor {formatNumber(raffle.winnerNumber || 0)}</p></div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-6">
              {registration && (
                <Card className="border-[#C8A45D]/50 bg-[#1C1C1C] text-[#FFFFFF]">
                  <CardHeader><CardTitle className="flex items-center gap-2 text-xl"><Check className="h-5 w-5 text-[#C8A45D]" />Sua participação</CardTitle></CardHeader>
                  <CardContent>
                    <p className="font-serif text-2xl">{registration.displayName}</p>
                    <p className="mt-1 text-sm text-[#A5A5A5]">Seus números</p>
                    <div className="mt-3 flex flex-wrap gap-2">{registration.numbers.map((number) => <span key={number} className="rounded-full bg-[#C8A45D] px-3 py-1 font-bold text-[#0B0B0B]">{formatNumber(number)}</span>)}</div>
                    <Button type="button" onClick={handleShare} className="mt-5 w-full border border-[#C8A45D] bg-transparent text-[#C8A45D] hover:bg-[#242424]"><Share2 className="mr-2 h-4 w-4" />Compartilhar e ganhar mais um número</Button>
                  </CardContent>
                </Card>
              )}

              <Card className="border-[#383838] bg-[#1C1C1C] text-[#FFFFFF]">
                <CardHeader><CardTitle className="flex items-center gap-2 text-xl"><Search className="h-5 w-5 text-[#C8A45D]" />Consultar meus números</CardTitle></CardHeader>
                <CardContent>
                  <form onSubmit={handleLookup} className="space-y-3"><Label htmlFor="lookup-phone">Digite seu telefone</Label><div className="flex gap-2"><Input id="lookup-phone" value={lookupPhone} onChange={(event) => setLookupPhone(event.target.value)} placeholder="(54) 99999-9999" className="border-[#383838] bg-[#0B0B0B] text-white" required /><Button type="submit" size="icon" className="shrink-0 bg-[#C8A45D] text-[#0B0B0B] hover:bg-[#E0BD72]"><Phone className="h-4 w-4" /></Button></div></form>
                  {lookup && <div className="mt-5 rounded-xl bg-[#242424] p-4"><p className="font-semibold">{lookup.displayName}</p>{lookup.isWinner && <div className="mt-2 rounded-lg border border-[#C8A45D]/50 bg-[#C8A45D]/10 p-3"><p className="flex items-center gap-2 font-semibold text-[#C8A45D]"><Trophy className="h-5 w-5" />Você foi o sorteado!</p><p className="mt-1 text-sm text-[#A5A5A5]">Entraremos em contato para agendar o dia e horário.</p></div>}<div className="mt-3 flex flex-wrap gap-2">{lookup.numbers.map((number) => <span key={number} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-sm ${lookup.winnerNumber === number ? "border-[#C8A45D] bg-[#C8A45D] font-bold text-[#0B0B0B]" : "border-[#C8A45D] text-[#C8A45D]"}`}>{lookup.winnerNumber === number && <Trophy className="h-4 w-4" />}{formatNumber(number)}</span>)}</div></div>}
                </CardContent>
              </Card>
            </div>
          </section>
        ) : (
          <Card className="border-[#383838] bg-[#1C1C1C] text-center text-[#FFFFFF]"><CardContent className="p-10"><Gift className="mx-auto h-10 w-10 text-[#C8A45D]" /><h2 className="mt-4 font-serif text-3xl">Nenhum sorteio ativo agora</h2><p className="mt-2 text-[#A5A5A5]">Confira abaixo os sorteios já realizados pela Gb Barbearia.</p></CardContent></Card>
        )}

        <section className="space-y-4">
          <div><p className="text-xs font-bold uppercase tracking-[0.2em] text-[#C8A45D]">Transparência</p><h2 className="mt-1 font-serif text-3xl">Sorteios realizados</h2></div>
          {historyQuery.data?.length ? <div className="grid gap-4 md:grid-cols-2">{historyQuery.data.map((item) => item && <Card key={item.id} className="border-[#383838] bg-[#1C1C1C] text-[#FFFFFF]"><CardContent className="p-5"><div className="flex items-start justify-between gap-3"><div><p className="text-xs text-[#A5A5A5]">{formatDrawDate(item.drawDate, item.drawTime)}</p><h3 className="mt-1 font-serif text-xl">{item.title}</h3></div><Trophy className="h-5 w-5 text-[#C8A45D]" /></div><p className="mt-3 text-sm text-[#A5A5A5]">Prêmio: {item.serviceName}</p><div className="mt-4 rounded-xl bg-[#242424] p-3"><p className="text-xs uppercase tracking-wider text-[#A5A5A5]">Vencedor</p><p className="mt-1 font-semibold text-[#C8A45D]">{item.winnerName || "Resultado registrado"}</p>{item.winnerNumber && <p className="text-sm text-[#A5A5A5]">Número {formatNumber(item.winnerNumber)}</p>}</div></CardContent></Card>)}</div> : <p className="text-[#A5A5A5]">Ainda não há sorteios finalizados.</p>}
        </section>
        <section className="rounded-3xl border border-[#C8A45D]/35 bg-[#1C1C1C] px-6 py-8 text-center sm:px-10">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#C8A45D]">Seu próximo visual começa aqui</p>
          <h2 className="mt-2 font-serif text-3xl">Conheça nossos serviços</h2>
          <p className="mx-auto mt-2 max-w-xl text-[#A5A5A5]">Escolha seu corte, barba ou ritual de cuidado e agende seu horário na Gb Barbearia.</p>
          <Button asChild className="mt-5 bg-[#C8A45D] text-[#0B0B0B] hover:bg-[#E0BD72]"><a href="/#servicos"><CalendarDays className="mr-2 h-4 w-4" />Conheça nossos serviços</a></Button>
        </section>
      </div>
      <footer className="-mx-4 mt-12 border-t border-[#383838] bg-[#0B0B0B] px-4 py-7 text-[#A5A5A5] sm:-mx-6 sm:px-6">
        <div className="mx-auto flex max-w-5xl flex-col gap-5 text-sm sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3"><span className="flex h-10 w-14 items-center justify-center overflow-hidden rounded-lg"><img src={NAVALHA_LOGO} alt="Logo da Gb Barbearia" className="h-full w-full object-contain" /></span><p>Gb Barbearia ® 2026 | Desenvolvido por <a href="https://www.instagram.com/gbcasagrande/" target="_blank" rel="noreferrer" className="font-semibold text-[#C8A45D] hover:text-[#E0BD72]">@gbcasagrande</a></p></div>
          <div className="flex flex-wrap items-center gap-5"><a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 font-semibold text-[#C8A45D] hover:text-[#E0BD72]"><Instagram className="h-4 w-4" />@navalhamarau</a><a href="/login" className="inline-flex items-center gap-2 font-semibold text-[#C8A45D] hover:text-[#E0BD72]">Área Administrativa <ArrowUpRight className="h-4 w-4" /></a></div>
        </div>
      </footer>
    </main>
  );
}

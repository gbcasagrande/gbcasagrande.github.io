ALTER TABLE `services` ADD `benefits` text;--> statement-breakpoint
ALTER TABLE `services` ADD `icon` varchar(64) DEFAULT 'Sparkles' NOT NULL;

CREATE TABLE `post_services` (
	`id` int AUTO_INCREMENT NOT NULL,
	`postId` int NOT NULL,
	`serviceId` int NOT NULL,
	CONSTRAINT `post_services_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `posts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`slug` varchar(255) NOT NULL,
	`summary` text NOT NULL,
	`content` text NOT NULL,
	`coverImageUrl` text,
	`authorName` varchar(255) NOT NULL,
	`reactionsCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `posts_id` PRIMARY KEY(`id`),
	CONSTRAINT `posts_slug_unique` UNIQUE(`slug`)
);

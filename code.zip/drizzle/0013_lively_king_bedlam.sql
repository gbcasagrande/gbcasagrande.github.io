ALTER TABLE `posts` ADD `isPinned` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `posts` ADD `isFeatured` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `professionals` ADD `instagramUrl` varchar(500);
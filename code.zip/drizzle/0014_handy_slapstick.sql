ALTER TABLE `professionals` ADD `profileSlug` varchar(160);--> statement-breakpoint
ALTER TABLE `professionals` ADD `coverUrl` text;--> statement-breakpoint
ALTER TABLE `professionals` ADD `verified` int DEFAULT 1 NOT NULL;
CREATE TABLE `admin_connections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`adminId` int NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`ipAddress` varchar(128),
	`userAgent` text,
	`connectedAt` timestamp NOT NULL DEFAULT (now()),
	`lastSeenAt` timestamp NOT NULL DEFAULT (now()),
	`disconnectedAt` timestamp,
	CONSTRAINT `admin_connections_id` PRIMARY KEY(`id`),
	CONSTRAINT `admin_connections_sessionId_unique` UNIQUE(`sessionId`)
);
--> statement-breakpoint
ALTER TABLE `admins` ADD `email` varchar(320);--> statement-breakpoint
ALTER TABLE `professionals` ADD `address` text;--> statement-breakpoint
ALTER TABLE `professionals` ADD `profileAccepted` int DEFAULT 0 NOT NULL;
ALTER TABLE `services` ADD `discountPercent` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `services` ADD `promotionLabel` varchar(120);
ALTER TABLE `services` ADD `sortOrder` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `services` ADD `isFeatured` int DEFAULT 0 NOT NULL;
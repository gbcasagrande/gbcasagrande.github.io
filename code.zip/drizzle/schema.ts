import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, date, time, uniqueIndex, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tabela de serviços oferecidos com valores padrão
 */
export const services = mysqlTable("services", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  defaultPrice: decimal("defaultPrice", { precision: 10, scale: 2 }).notNull(),
  duration: int("duration"), // duração em minutos
  benefits: text("benefits"), // um benefício por linha
  icon: varchar("icon", { length: 64 }).default("Sparkles").notNull(),
  active: int("active").default(1).notNull(), // 1 = ativo, 0 = inativo
  priceDisplayMode: varchar("priceDisplayMode", { length: 32 }).default("price").notNull(), // "price" ou "evaluation"
  discountPercent: int("discountPercent").default(0).notNull(), // desconto promocional de 0 a 100
  promotionLabel: varchar("promotionLabel", { length: 120 }), // ex.: Semana do corte
  sortOrder: int("sortOrder").default(0).notNull(), // menor número aparece primeiro
  isFeatured: int("isFeatured").default(0).notNull(), // 1 = serviço fixado no topo
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Service = typeof services.$inferSelect;
export type InsertService = typeof services.$inferInsert;

/**
 * Tabela de barbeiros da barbearia
 */
export const professionals = mysqlTable("professionals", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  specialty: varchar("specialty", { length: 255 }),
  bio: text("bio"),
  phone: varchar("phone", { length: 20 }),
  address: text("address"),
  instagramUrl: varchar("instagramUrl", { length: 500 }),
  profileSlug: varchar("profileSlug", { length: 160 }),
  coverUrl: text("coverUrl"),
  verified: int("verified").default(1).notNull(),
  avatarUrl: text("avatarUrl"),
  profileAccepted: int("profileAccepted").default(0).notNull(),
  active: int("active").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Professional = typeof professionals.$inferSelect;
export type InsertProfessional = typeof professionals.$inferInsert;

/**
 * Tabela de associação N para N entre serviços e barbeiros
 */
export const serviceProfessionals = mysqlTable("service_professionals", {
  id: int("id").autoincrement().primaryKey(),
  serviceId: int("serviceId").notNull(),
  professionalId: int("professionalId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ServiceProfessional = typeof serviceProfessionals.$inferSelect;
export type InsertServiceProfessional = typeof serviceProfessionals.$inferInsert;

/**
 * Expediente individual de cado barbeiro.
 * dayOfWeek usa 0 = domingo até 6 = sábado; um dia pode ter vários intervalos
 * para representar, por exemplo, manhã e tarde.
 */
export const professionalSchedules = mysqlTable("professional_schedules", {
  id: int("id").autoincrement().primaryKey(),
  professionalId: int("professionalId").notNull(),
  dayOfWeek: int("dayOfWeek").notNull(),
  startTime: time("startTime").notNull(),
  endTime: time("endTime").notNull(),
  active: int("active").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProfessionalSchedule = typeof professionalSchedules.$inferSelect;
export type InsertProfessionalSchedule = typeof professionalSchedules.$inferInsert;

/**
 * Conteúdo institucional editável da página inicial.
 */
export const siteContent = mysqlTable("site_content", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteContent = typeof siteContent.$inferSelect;
export type InsertSiteContent = typeof siteContent.$inferInsert;

/**
 * Expediente configurável por dia da semana. dayOfWeek usa 0 = domingo até 6 = sábado.
 */
export const businessHours = mysqlTable("business_hours", {
  id: int("id").autoincrement().primaryKey(),
  dayOfWeek: int("dayOfWeek").notNull(),
  startTime: time("startTime").notNull(),
  endTime: time("endTime").notNull(),
  active: int("active").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BusinessHour = typeof businessHours.$inferSelect;
export type InsertBusinessHour = typeof businessHours.$inferInsert;

/**
 * Bloqueios específicos criados pela administradora para tornar um intervalo indisponível.
 */
export const blockedSlots = mysqlTable("blocked_slots", {
  id: int("id").autoincrement().primaryKey(),
  blockedDate: date("blockedDate", { mode: "string" }).notNull(),
  startTime: time("startTime").notNull(),
  endTime: time("endTime").notNull(),
  reason: varchar("reason", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BlockedSlot = typeof blockedSlots.$inferSelect;
export type InsertBlockedSlot = typeof blockedSlots.$inferInsert;

/**
 * Tabela de agendamentos
 */
export const appointments = mysqlTable("appointments", {
  id: int("id").autoincrement().primaryKey(),
  clientName: varchar("clientName", { length: 255 }).notNull(),
  clientPhone: varchar("clientPhone", { length: 20 }).notNull(),
  clientEmail: varchar("clientEmail", { length: 320 }),
  userOpenId: varchar("userOpenId", { length: 128 }),
  serviceName: varchar("serviceName", { length: 255 }).notNull(), // permite serviço customizado
  serviceId: int("serviceId"), // referência opcional ao serviço cadastrado
  // Data civil do agendamento: armazenada como YYYY-MM-DD sem conversão de timezone.
  appointmentDate: date("appointmentDate", { mode: "string" }).notNull(),
  appointmentTime: time("appointmentTime").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["confirmado", "cancelado", "pendente"]).default("pendente").notNull(),
  notes: text("notes"),
  notificationSent: int("notificationSent").default(0).notNull(), // 1 = enviado, 0 = não enviado
  source: mysqlEnum("source", ["admin", "public"]).default("admin").notNull(),
  professionalId: int("professionalId"), // referência opcional ao barbeiro responsável
  reason: text("reason"), // motivo opcional informado pelo cliente no agendamento público
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = typeof appointments.$inferInsert;

/**
 * Tabela de administradores com credenciais fixas
 */
export const admins = mysqlTable("admins", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  role: varchar("role", { length: 32 }).default("admin").notNull(),
  professionalId: int("professionalId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = typeof admins.$inferInsert;

/** Registro resumido de conexões do painel para a área de segurança. */
export const adminConnections = mysqlTable("admin_connections", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull(),
  sessionId: varchar("sessionId", { length: 64 }).notNull().unique(),
  ipAddress: varchar("ipAddress", { length: 128 }),
  userAgent: text("userAgent"),
  connectedAt: timestamp("connectedAt").defaultNow().notNull(),
  lastSeenAt: timestamp("lastSeenAt").defaultNow().notNull(),
  disconnectedAt: timestamp("disconnectedAt"),
});
export type AdminConnection = typeof adminConnections.$inferSelect;
export type InsertAdminConnection = typeof adminConnections.$inferInsert;

/**
 * Tabela de postagens/artigos da barbearia Navalha & Cia
 */
export const posts = mysqlTable("posts", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  summary: text("summary").notNull(),
  content: text("content").notNull(),
  coverImageUrl: text("coverImageUrl"),
  authorName: varchar("authorName", { length: 255 }).notNull(),
  isPinned: int("isPinned").default(0).notNull(), // 1 = fixado no topo (máx 4)
  isFeatured: int("isFeatured").default(0).notNull(), // 1 = destacado na Home (máx 2)
  reactionsCount: int("reactionsCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Post = typeof posts.$inferSelect;
export type InsertPost = typeof posts.$inferInsert;

/**
 * Relação entre postagens e serviços recomendados para referência e agendamento
 */
export const postServices = mysqlTable("post_services", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  serviceId: int("serviceId").notNull(),
});

export type PostService = typeof postServices.$inferSelect;
export type InsertPostService = typeof postServices.$inferInsert;

/** Sorteios promocionais configurados pela administração. */
export const raffles = mysqlTable("raffles", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  drawDate: date("drawDate", { mode: "string" }).notNull(),
  drawTime: time("drawTime").notNull(),
  serviceId: int("serviceId").notNull(),
  status: mysqlEnum("status", ["active", "finalized", "cancelled"]).default("active").notNull(),
  winnerNumber: int("winnerNumber"),
  winnerParticipantId: int("winnerParticipantId"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  statusIdx: index("raffles_status_idx").on(table.status),
  drawDateIdx: index("raffles_draw_date_idx").on(table.drawDate),
}));
export type Raffle = typeof raffles.$inferSelect;
export type InsertRaffle = typeof raffles.$inferInsert;

/** Uma inscrição por telefone em cada sorteio; o token permite ganhar um número extra. */
export const raffleParticipants = mysqlTable("raffle_participants", {
  id: int("id").autoincrement().primaryKey(),
  raffleId: int("raffleId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  shareToken: varchar("shareToken", { length: 64 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  rafflePhoneIdx: uniqueIndex("raffle_participant_phone_idx").on(table.raffleId, table.phone),
  raffleIdx: index("raffle_participant_raffle_idx").on(table.raffleId),
}));
export type RaffleParticipant = typeof raffleParticipants.$inferSelect;
export type InsertRaffleParticipant = typeof raffleParticipants.$inferInsert;

/** Números sorteáveis, com no máximo um número inicial e um número de compartilhamento por participante. */
export const raffleNumbers = mysqlTable("raffle_numbers", {
  id: int("id").autoincrement().primaryKey(),
  raffleId: int("raffleId").notNull(),
  participantId: int("participantId").notNull(),
  number: int("number").notNull(),
  kind: mysqlEnum("kind", ["initial", "share"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  raffleNumberIdx: uniqueIndex("raffle_number_unique_idx").on(table.raffleId, table.number),
  participantKindIdx: uniqueIndex("raffle_participant_kind_idx").on(table.participantId, table.kind),
  participantIdx: index("raffle_number_participant_idx").on(table.participantId),
}));
export type RaffleNumber = typeof raffleNumbers.$inferSelect;
export type InsertRaffleNumber = typeof raffleNumbers.$inferInsert;

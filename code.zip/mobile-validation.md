# Validação responsiva — WhatsApp e próximos horários

## Home em viewport mobile

A Home foi capturada em 390 x 844 pixels com Chromium headless. O cabeçalho da marca permanece legível, o título principal não transborda, o texto introdutório quebra adequadamente e os dois CTAs ficam empilhados com largura confortável. O botão principal de serviços e o botão "Agende pelo WhatsApp" aparecem completos e sem sobreposição. A captura foi salva em `/home/ubuntu/mobile-home-whatsapp.png`.

## Observação

As validações finais da agenda e da navegação por teclado foram concluídas e estão registradas nas seções abaixo.

## Agenda autenticada e confirmação

Na prévia autenticada da agenda, a seção "Próximos horários" aparece acima do calendário, ordenando os agendamentos por data e horário. O cartão de Agata exibe Drenagem Linfática, 18/08/2026 às 17:06 e o link de confirmação abre `https://wa.me/5554991973203` com a mensagem codificada: "Olá, Agata! Você tem um horário marcado para Drenagem Linfática no dia 18/08/2026, às 17:06. Posso confirmar?". O cartão sem telefone válido informa que não é possível confirmar. A agenda também apresenta a navegação mobile horizontal para os módulos e os cards usam largura responsiva.

O redimensionamento direto da janela do navegador não alterou a viewport desta sessão, portanto a validação mobile efetiva foi concluída na Home via captura Chromium de 390 x 844; a agenda foi revisada estaticamente com classes responsivas e visualizada na prévia autenticada.

## Foco e acessibilidade

O CSS global agora define foco visível para links e botões com `:focus-visible`, e os novos CTAs de WhatsApp também recebem classes explícitas de anel de foco. A navegação por Tab na agenda foi executada; o foco percorreu controles do calendário e a prévia manteve o layout utilizável. A validação programática confirmou que o link de confirmação é um elemento `<a>` com largura de outline configurada, enquanto a exibição do anel depende da interação de teclado (`:focus-visible`).

## Smoke test de foco na Home

A Home foi aberta na prévia e recebeu navegação por Tab. O foco visível foi aplicado ao controle "Serviços" e a sequência de elementos interativos inclui o acesso administrativo, o CTA de WhatsApp geral e os sete links de agendamento por serviço. Os novos links foram encontrados pelo navegador com URLs `wa.me` codificadas e o acesso administrativo aponta para `/login`.

### Agenda — sequência de foco

Na agenda autenticada, a navegação por Tab iniciou no botão "Agenda" e avançou pelos controles "Serviços" e "Relatórios", com `:focus-visible` verdadeiro em cada verificação. O próximo passo do teste é alcançar "Sair" e, em seguida, "Confirmar pelo WhatsApp".

### Resultado final do smoke test real na Agenda

A sequência manual por Tab percorreu "Agenda" → "Serviços" → "Relatórios" → "Sair" → "Confirmar pelo WhatsApp". O último elemento foi confirmado programaticamente como `<a>` com `:focus-visible = true`, texto "Confirmar pelo WhatsApp" e URL `https://wa.me/5554991973203?...` contendo a mensagem codificada para Agata, Drenagem Linfática, 18/08/2026 às 17:06. Nenhum controle novo ficou inalcançável nessa sequência.

## Regressão final do painel

A sessão autenticada permaneceu válida ao navegar entre Agenda, Serviços e Relatórios. A tela de Serviços carregou os serviços cadastrados e exibiu ações de novo, editar e excluir. A tela de Relatórios carregou Agosto de 2026 com 4 agendamentos, 2 confirmados, 0 cancelados e faturamento de R$ 270,00. Na Agenda, o dia 18/08 abriu o cartão de Agata e o formulário de edição carregou corretamente cliente, telefone, serviço, data civil `2026-08-18`, horário e valor; o formulário foi fechado sem salvar alterações, preservando os dados.

## Evidência adicional da Home

A Home carregou a imagem `Grazi Batistela - Massoterapia Avançada` com `complete: true` e URL de asset válida. O DOM contém os acessos administrativos do cabeçalho e do rodapé apontando para `/login`, além do botão administrativo responsivo. Os sete links de serviço e o CTA geral de WhatsApp permanecem presentes.

A verificação visual do rodapé mostra o botão "Área Administrativa" apontando para `/login`. A captura mobile existente em 390 x 844 px foi revisada; ela confirma a composição responsiva da Home sem sobreposição dos CTAs, enquanto o DOM da mesma página confirma o botão de rodapé responsivo com destino `/login`.

## Ciclo CRUD real de regressão

Foi criado um agendamento temporário `QA Temporário` em 25/08/2026 às 10:30, com Drenagem Linfática; a seleção preencheu automaticamente R$ 150,00. O registro persistiu na agenda com a data civil correta, foi editado e salvo com status `Confirmado` mantendo 25/08/2026, e depois foi excluído mediante confirmação. A tela retornou "Agendamento excluído!" e 25/08 ficou sem agendamentos, enquanto Gabriel e Agata permaneceram intactos.

## Atualização do número de agendamento — validação

A Home foi recarregada após a alteração e apresentou 9 links públicos de WhatsApp — CTA geral, sete serviços e CTA do rodapé — todos iniciando com `https://wa.me/5554991399264?text=`. A agenda autenticada carregou normalmente e exibiu seu estado vazio nesta sessão; os testes automatizados continuam cobrindo a composição das mensagens de confirmação e o uso separado do telefone do cliente.

A validação direta pós-atualização criou o registro temporário `QA Confirmação` com telefone `54987654321`. O link real de confirmação gerado na agenda apontou para `https://wa.me/5554987654321?...`, com a mensagem correta de 25/08/2026 às 11:15, e não para o número da clínica `5554991399264`. A verificação programática confirmou `confirmationUsesClient: true` e `clinicNumberAbsentFromConfirmation: true`.

O registro temporário `QA Confirmação` foi excluído após confirmação, a agenda exibiu `Agendamento excluído!` e 25/08/2026 voltou a ficar sem agendamentos. O agendamento real de Gabriel permaneceu visível, sem alteração feita durante este teste.

Validação das novas abas administrativas: a aba `Página Inicial` renderizou campos para título principal, subtítulo e descrição principal; a aba `Sobre` renderizou título, dois parágrafos e destaque institucional. Ambas carregaram os valores padrão atuais sem erro após a correção do uso indevido de DialogDescription.

Validação de sincronização: a aba `Gerenciar Serviços` exibiu, em ordem decrescente de cadastro, Micropigmentação, Avaliação, Terapia com LED, Criolipólise, Tapping, Pós-Operatória, Pré-Operatória, Massagem Terapêutica, Massagem Relaxante e Drenagem Linfática. A Home exibiu a mesma ordem e os mesmos serviços, cada um com botão de agendamento.

A Home foi validada após a sincronização: os 10 cards de serviços cadastrados aparecem na mesma ordem do painel; a consulta DOM também identificou as demais headings institucionais. Foram encontrados 12 links públicos de WhatsApp (CTA, serviços e contato), todos começando por `https://wa.me/5554991399264?text=` e nenhum com DDD 49.

Validação do fluxo público: o botão `Agende pelo WhatsApp` abriu o diálogo `Escolha seu horário` com serviço, data, grade de horários e campos de nome/telefone. Para preservar o formato civil do input de data durante a validação automatizada, a próxima checagem usa o setter nativo do campo para aplicar `YYYY-MM-DD`.

Validação de disponibilidade: no diálogo público, a data civil `2026-08-17` retornou a grade do expediente e o slot `18:30` apareceu com hint `Ocupado`, enquanto os demais horários possíveis permaneceram disponíveis. Isso confirma que o agendamento existente é refletido no fluxo público.

Validação administrativa: a aba `Horários` foi aberta com 12 intervalos ativos, de segunda a sábado, nos períodos 07:30–12:00 e 13:30–19:00. A mesma aba exibiu controles para adicionar/editar/desativar intervalos e o formulário para bloquear uma data e faixa horária com motivo.

Validação do botão final: o diálogo foi reaberto na Home com a grade de horários e o botão `Agendar pelo WhatsApp` disponível para testar a mensagem com serviço, data e horário selecionados.

Teste controlado de mensagem: foi selecionado `Avaliação` às `07:30` em `14/08/2026`, com nome `Cliente de Validação` e telefone de teste preenchidos. O clique final será interceptado apenas para inspecionar a URL, sem abrir ou enviar uma conversa real.

Validação final da mensagem pública: o clique controlado gerou `https://wa.me/5554991399264` e a mensagem decodificada mencionou `Avaliação`, `14/08/2026`, `07:30`, o nome e o telefone informados. O WhatsApp não foi aberto nem houve envio, pois o `window.open` foi interceptado somente para inspeção.

Validação do fluxo pendente: o diálogo público continua exibindo serviço, data, horários e os campos `Seu nome` e `Seu telefone`; o botão `Agendar pelo WhatsApp` permanece desabilitado enquanto os dados obrigatórios não forem preenchidos.

Validação administrativa: a nova aba `Pendentes` aparece na navegação da Agenda e exibe corretamente o estado vazio `Nenhum horário pendente`, informando que as solicitações feitas pela Home aparecerão ali para confirmação.

Validação do painel após a atualização: a aba Agenda exibe o título `Todos os próximos horários` e mostra mais de um horário futuro sem o limite anterior de seis itens. A aba `Agendamentos Pendentes` exibe uma solicitação com o rótulo `Solicitação pendente`, data, horário, telefone e os controles `Agendar neste horário`, `Editar data e horário`, `Cancelar horário` e `Falar pelo WhatsApp`.

Validação da navegação administrativa: em desktop, o painel passou a usar uma barra lateral esquerda com os itens Agenda, Agendamentos Pendentes, Serviços, Página Inicial, Sobre, Horários e Relatórios. O item `Início` aparece separado no topo e abre a rota pública `/`, sem abrir uma aba interna do painel. Em viewport estreita, os mesmos itens permanecem acessíveis em uma faixa horizontal rolável.

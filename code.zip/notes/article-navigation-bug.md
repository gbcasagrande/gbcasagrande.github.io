# Validação — abertura de artigos pela Home

O erro foi reproduzido acessando `/post/1`: a página mostrava `Rendered more hooks than during the previous render`.

A causa era a chamada de `trpc.posts.earlier.useQuery()` dentro de uma função executada apenas depois que o artigo carregava. Isso alterava a quantidade de hooks entre o primeiro render (carregamento) e os renders seguintes.

A correção moveu a consulta para o nível principal do componente `PostDetail`, com `enabled` controlado por `postId` e pela existência do artigo, e substituiu o bloco condicional por renderização baseada em `earlierPosts`. TypeScript voltou a reportar 0 erros após a alteração.

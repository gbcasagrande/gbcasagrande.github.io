# Validação — agendamento a partir de postagem

A URL `/?bookingServiceId=150004#agendar` foi aberta na prévia da Home. O parâmetro foi consumido e removido da URL, e o diálogo **Escolha seu horário** abriu automaticamente. O seletor de serviço já aparece com **Massagem Relaxante** selecionado, seguido da escolha de profissional, data e horários disponíveis.

O teste com `bookingServiceId=1` não abriu o diálogo porque esse ID não existe entre os serviços atuais; isso confirma que o fluxo ignora IDs inválidos. O vínculo real consultado no banco usa `postId=1` e `serviceId=150004`, e esse caso foi validado com sucesso.

A suíte automatizada executada após a alteração passou com 60 testes Vitest e TypeScript sem erros.

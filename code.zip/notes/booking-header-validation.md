# Validação — cabeçalho durante escolha de horário

A Home foi aberta com um serviço solicitado pela URL e o modal `Escolha seu horário` apareceu com o serviço selecionado e horários disponíveis.

Enquanto o modal estava aberto, o contêiner do cabeçalho apresentou `aria-hidden="true"`, `visibility: hidden`, `opacity: 0` e `pointer-events: none`.

Depois de clicar em fechar, o mesmo contêiner apresentou `aria-hidden="false"`, `visibility: visible`, `opacity: 1` e `pointer-events: auto`.

Resultado: o cabeçalho com logo e WhatsApp fica oculto apenas durante a escolha de horário e retorna automaticamente após o fechamento.

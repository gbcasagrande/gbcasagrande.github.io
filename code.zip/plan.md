# Plano — Barbearia

## Escopo
Cópia funcional do sistema de autenticação, profissionais, serviços, disponibilidade, bloqueios, agenda e agendamento público, rebrandada para uma barbearia. A base exportada da tarefa de referência será preservada e adaptada sem remover os fluxos existentes.

## Estrutura
- `client/src/pages` — home, login, painel, perfis públicos e telas de agenda.
- `client/src/components` — componentes de navegação, modais, formulários e UI.
- `client/src/index.css` — tokens visuais, tipografia e responsividade.
- `server` — autenticação, rotas tRPC e regras de disponibilidade/agendamento.
- `drizzle` — schema e migrações do banco compartilhado.
- `public/manus-routes.json` — manifesto das rotas navegáveis.

## Direção de design
Três opções consideradas: neo-barbearia editorial (0,06), clube masculino vintage (0,04), minimalismo industrial premium (0,08). Escolha: **minimalismo industrial premium**.

- **Movimento:** hotelaria masculina contemporânea, com precisão editorial e materiais escuros.
- **Princípios:** contraste alto, hierarquia tipográfica forte, superfícies sóbrias e ações diretas.
- **Cor:** carvão e grafite criam confiança; marfim melhora leitura; cobre queimado funciona como assinatura premium.
- **Layout:** blocos assimétricos, faixa hero com chamada lateral e seções em trilhos horizontais, evitando aparência de template.
- **Assinaturas:** linha de navalha/cobre, selo circular da casa e cartões com bordas finas.
- **Interação:** CTAs curtos e claros; agendamento sempre aparece como próxima ação principal.
- **Animação:** entradas discretas de fade/slide e hover com elevação mínima, sem efeitos chamativos.
- **Tipografia:** Manrope para interface e títulos compactos; serif de contraste apenas em frases de destaque, quando já suportada pelo projeto.
- **Essência:** a cadeira certa, no horário certo, com barbeiros que dominam o ofício. Personalidade: preciso, acolhedor, confiante.
- **Voz:** direta, masculina e calorosa. Exemplos: “Seu próximo corte começa aqui.” / “Escolha o barbeiro. A gente cuida do resto.”
- **Wordmark:** monograma “B” formado por duas lâminas paralelas, acompanhado do nome da casa em caixa alta.
- **Cor proprietária:** cobre queimado `#B87545`.

## Implementação
Reaproveitar a base exportada, substituir textos, nomes de marca, serviços e exemplos ligados à clínica por conteúdo de barbearia, ajustar os tokens de cor e garantir as rotas e o manifesto. Manter banco, login e agenda conforme a estrutura original.

### Módulo de sorteios
Adicionar entidades persistentes para sorteios, participantes e números, com um número inicial por telefone e no máximo um número extra por compartilhamento. O administrador poderá criar/ativar um sorteio com data, horário e serviço escolhido, visualizar participantes e executar o sorteio aleatório; ao finalizar, o resultado ficará público e não exibirá sobrenomes.

As rotas públicas `/sorteios` e `/sorteios/:id` mostrarão o sorteio ativo, permitirão cadastrar nome e telefone, compartilhar o link para obter o número extra e consultar números pelo telefone. A Home exibirá um bloco fixado enquanto houver sorteio ativo. O painel administrativo terá uma aba dedicada para criar, ativar, finalizar e consultar sorteios.

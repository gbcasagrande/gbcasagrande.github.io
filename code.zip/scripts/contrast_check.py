import math


def oklch_to_srgb(L, C, h_degrees):
    h = math.radians(h_degrees)
    a = C * math.cos(h)
    b = C * math.sin(h)

    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b

    l = l_ ** 3
    m = m_ ** 3
    s = s_ ** 3

    r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    blue = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s

    def encode(value):
        value = max(0.0, min(1.0, value))
        return 12.92 * value if value <= 0.0031308 else 1.055 * (value ** (1 / 2.4)) - 0.055

    return tuple(encode(value) for value in (r, g, blue))


def luminance(rgb):
    linear = []
    for channel in rgb:
        linear.append(channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4)
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def contrast(first, second):
    first_l = luminance(first)
    second_l = luminance(second)
    lighter = max(first_l, second_l)
    darker = min(first_l, second_l)
    return (lighter + 0.05) / (darker + 0.05)

white = (1.0, 1.0, 1.0)
rose_button = oklch_to_srgb(0.58, 0.16, 5)
rose_outline_text = oklch_to_srgb(0.48, 0.15, 5)
rose_focus = rose_button

print(f"main CTA rose / white text: {contrast(rose_button, white):.2f}:1")
print(f"outline rose text / white background: {contrast(rose_outline_text, white):.2f}:1")
print(f"focus ring rose / white background: {contrast(rose_focus, white):.2f}:1")
assert contrast(rose_button, white) >= 4.5
assert contrast(rose_outline_text, white) >= 4.5
assert contrast(rose_focus, white) >= 3.0

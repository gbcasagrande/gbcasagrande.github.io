import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const services = [
  { name: 'Corte Clássico', description: 'Corte sob medida, acabamento preciso e finalização que respeita o seu estilo.', defaultPrice: '55.00', duration: 45 },
  { name: 'Corte + Barba', description: 'O combo completo para alinhar cabelo, barba e contornos em um único horário.', defaultPrice: '85.00', duration: 75 },
  { name: 'Barba Tradicional', description: 'Toalha quente, desenho e acabamento cuidadoso para uma barba impecável.', defaultPrice: '45.00', duration: 35 },
  { name: 'Corte Degradê', description: 'Degradê feito na régua, com transição limpa e acabamento personalizado.', defaultPrice: '65.00', duration: 55 },
  { name: 'Corte Infantil', description: 'Atendimento paciente e descontraído para os pequenos saírem estilosos.', defaultPrice: '45.00', duration: 40 },
  { name: 'Ritual de Toalha Quente', description: 'Uma pausa de cuidado com esfoliação suave, toalha quente e finalização.', defaultPrice: '35.00', duration: 25 },
  { name: 'Camuflagem de Fios', description: 'Disfarce natural dos fios brancos com aplicação rápida e resultado discreto.', defaultPrice: '50.00', duration: 35 },
];

async function seedServices() {
  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  
  for (const service of services) {
    try {
      await connection.execute(
        'INSERT INTO services (name, description, defaultPrice, duration, active) VALUES (?, ?, ?, ?, 1) ON DUPLICATE KEY UPDATE description = VALUES(description), defaultPrice = VALUES(defaultPrice), duration = VALUES(duration)',
        [service.name, service.description, service.defaultPrice, service.duration]
      );
      console.log(`Inserted: ${service.name}`);
    } catch (error) {
      console.error(`Error inserting ${service.name}:`, error.message);
    }
  }
  
  await connection.end();
  console.log('Seed completed!');
}

seedServices().catch(console.error);

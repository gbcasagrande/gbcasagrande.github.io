import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { SignJWT } from "jose";

// Mock do módulo db
vi.mock("./db", () => ({
  verifyAdminCredentials: vi.fn(),
  getAdminByUsername: vi.fn(),
  getAdminById: vi.fn(),
  getAllAdmins: vi.fn().mockResolvedValue([]),
  createAdmin: vi.fn(),
  getProfessionalById: vi.fn(),
  updateAdminPassword: vi.fn(),
  updateAdminProfile: vi.fn(),
  deleteAdmin: vi.fn(),
  createAdminConnection: vi.fn(),
  disconnectAdminConnection: vi.fn(),
  touchAdminConnection: vi.fn(),
  getAllServices: vi.fn().mockResolvedValue([]),
  getAllAppointments: vi.fn().mockResolvedValue([]),
  getMonthlyReport: vi.fn().mockResolvedValue({
    year: 2026,
    month: 1,
    totalAppointments: 0,
    confirmedAppointments: 0,
    canceledAppointments: 0,
    pendingAppointments: 0,
    totalRevenue: 0,
    topServices: [],
  }),
}));

import * as db from "./db";

const ADMIN_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "grazi-massoterapia-secret-key");

function createMockContext(cookies: Record<string, string> = {}): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
      cookies,
    } as unknown as TrpcContext["req"],
    res: {
      cookie: vi.fn(),
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

async function createAdminContext() {
  const token = await new SignJWT({ id: 1, username: "grazi", name: "Grazi Batistela", role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("1h")
    .sign(ADMIN_SECRET);
  return createMockContext({ admin_session: token });
}

describe("adminAuth", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(db.getAdminById).mockResolvedValue({ id: 1, username: "grazi", name: "Grazi Batistela", role: "admin", professionalId: null } as any);
  });

  describe("login", () => {
    it("should reject invalid credentials", async () => {
      vi.mocked(db.verifyAdminCredentials).mockResolvedValue(null);
      
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.adminAuth.login({ username: "wrong", password: "wrong" })
      ).rejects.toThrow("Credenciais inválidas");
    });

    it("should accept valid credentials and set cookie", async () => {
      vi.mocked(db.verifyAdminCredentials).mockResolvedValue({
        id: 1,
        username: "grazi",
        passwordHash: "hash",
        name: "Grazi Batistela",
        role: "admin",
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.adminAuth.login({
        username: "grazi",
        password: "1889@gByu/1m",
      });

      expect(result.success).toBe(true);
      expect(result.admin.username).toBe("grazi");
      expect(ctx.res.cookie).toHaveBeenCalled();
    });
  });

  describe("management", () => {
    it("blocks user-role accounts from administrative management routes", async () => {
      vi.mocked(db.getAdminById).mockResolvedValue({ id: 1, username: "marina", name: "Marina", role: "user", professionalId: 12 } as any);
      const token = await new SignJWT({ id: 1, username: "marina", name: "Marina", role: "user" }).setProtectedHeader({ alg: "HS256" }).setExpirationTime("1h").sign(ADMIN_SECRET);
      const caller = appRouter.createCaller(createMockContext({ admin_session: token }));

      await expect(caller.adminAuth.list()).rejects.toThrow("Acesso restrito a administradores");
    });

    it("allows a logged-in user to update only their own profile", async () => {
      vi.mocked(db.getAdminByUsername).mockResolvedValue(null);
      vi.mocked(db.updateAdminProfile).mockResolvedValue({ id: 1, username: "marina.nova", name: "Marina Nova", role: "user", professionalId: 12 } as any);
      const caller = appRouter.createCaller(await createAdminContext());

      const result = await caller.adminAuth.updateProfile({ username: "Marina.Nova", name: "Marina Nova" });

      expect(result).toMatchObject({ id: 1, username: "marina.nova", name: "Marina Nova" });
      expect(db.updateAdminProfile).toHaveBeenCalledWith(1, { username: "marina.nova", name: "Marina Nova" });
    });

    it("creates a user linked to an active professional", async () => {
      vi.mocked(db.getAdminByUsername).mockResolvedValue(null);
      vi.mocked(db.getProfessionalById).mockResolvedValue({ id: 12, name: "Dra. Marina", active: 1 } as any);
      vi.mocked(db.createAdmin).mockResolvedValue({ id: 2, username: "marina", name: "Dra. Marina", professionalId: 12 } as any);

      const caller = appRouter.createCaller(await createAdminContext());
      const result = await caller.adminAuth.create({ username: "Marina", name: "Dra. Marina", password: "senha-segura", professionalId: 12 });

      expect(result).toMatchObject({ username: "marina", professionalId: 12 });
      expect(db.createAdmin).toHaveBeenCalledWith(expect.objectContaining({ username: "marina", professionalId: 12 }));
    });

    it("changes the authenticated user's password after validating the current one", async () => {
      vi.mocked(db.getAdminByUsername).mockResolvedValue({ id: 1, username: "grazi", passwordHash: "old", name: "Grazi" } as any);
      vi.mocked(db.verifyAdminCredentials).mockResolvedValue({ id: 1, username: "grazi" } as any);
      vi.mocked(db.updateAdminPassword).mockResolvedValue(true);

      const caller = appRouter.createCaller(await createAdminContext());
      const result = await caller.adminAuth.changePassword({ currentPassword: "senha-atual", newPassword: "senha-nova" });

      expect(result.success).toBe(true);
      expect(db.updateAdminPassword).toHaveBeenCalledWith(1, "senha-nova");
    });
  });

  describe("me", () => {
    it("should return null when not authenticated", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.adminAuth.me();

      expect(result).toBeNull();
    });
  });

  describe("logout", () => {
    it("should clear the admin session cookie", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.adminAuth.logout();

      expect(result.success).toBe(true);
      expect(ctx.res.clearCookie).toHaveBeenCalledWith("admin_session", { path: "/" });
    });
  });
});

describe("services", () => {
  it("should list services publicly", async () => {
    vi.mocked(db.getAllServices).mockResolvedValue([
      {
        id: 1,
        name: "Massagem Relaxante",
        description: "Descrição",
        defaultPrice: "120.00",
        duration: 60,
        active: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);

    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);

    const services = await caller.services.list();

    expect(services).toHaveLength(1);
    expect(services[0].name).toBe("Massagem Relaxante");
  });
});

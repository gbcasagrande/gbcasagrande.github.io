import { describe, it, expect } from "vitest";
import { ADMIN_NAV_ITEMS, ADMIN_NAV_LAYOUT_CLASSES, getPendingBadgeLabel, getVisibleAdminNavItems } from "@shared/adminNavigation";

describe("navegação administrativa", () => {
  it("inclui Início como link exclusivo para a Home pública", () => {
    const homeItem = ADMIN_NAV_ITEMS.find((item) => item.type === "link");
    expect(homeItem).toMatchObject({ type: "link", label: "Início", href: "/" });
  });

  it("inclui todas as seções internas do painel", () => {
    const tabs = ADMIN_NAV_ITEMS.filter((item) => item.type === "tab").map((item) => item.tab);
    expect(tabs).toEqual(["agenda", "pendentes", "servicos", "profissionais", "usuarios", "pagina", "sobre", "imagens", "horarios", "relatorios", "postagens", "meu-usuario"]);
  });

  it("permite que usuários comuns vejam Gestão de Postagens", () => {
    const tabs = getVisibleAdminNavItems("user").filter((item) => item.type === "tab").map((item) => item.tab);
    expect(tabs).toContain("postagens");
  });

  it("mantém o menu administrativo na lateral esquerda em todos os dispositivos", () => {
    expect(ADMIN_NAV_LAYOUT_CLASSES.container).toContain("block");
    expect(ADMIN_NAV_LAYOUT_CLASSES.container).toContain("space-y-1");
    expect(ADMIN_NAV_LAYOUT_CLASSES.item).toContain("w-full");
  });

  it("mostra a agenda operacional, postagens e o próprio perfil para usuários comuns", () => {
    const tabs = getVisibleAdminNavItems("user").filter((item) => item.type === "tab").map((item) => item.tab);
    expect(tabs).toEqual(["agenda", "pendentes", "relatorios", "postagens", "meu-usuario"]);
  });

  it("mantém todas as seções para administradores", () => {
    expect(getVisibleAdminNavItems("admin")).toEqual(ADMIN_NAV_ITEMS);
  });

  it("identifica a aba de agendamentos pendentes para receber a notificação", () => {
    expect(ADMIN_NAV_ITEMS).toContainEqual(expect.objectContaining({ type: "tab", tab: "pendentes" }));
  });

  it("formata o contador de solicitações pendentes", () => {
    expect(getPendingBadgeLabel(0)).toBe("0");
    expect(getPendingBadgeLabel(4)).toBe("4");
    expect(getPendingBadgeLabel(120)).toBe("99+");
  });
});

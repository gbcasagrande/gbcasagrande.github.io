import { describe, expect, it } from "vitest";
import { filterAgendaAppointments } from "../shared/agendaFilters";

const appointments = [
  { clientName: "Ana Silva", clientPhone: "54999990000", serviceName: "Drenagem Linfática", professionalName: "Alana Maculan", professionalId: 3, status: "confirmado" as const },
  { clientName: "Bruna Costa", clientPhone: "54988881111", serviceName: "Massagem Relaxante", professionalName: "Ketlen Antunes", professionalId: 7, status: "pendente" as const },
  { clientName: "Carla Souza", clientPhone: "54977772222", serviceName: "Avaliação", professionalName: null, professionalId: null, status: "cancelado" as const },
];

describe("filtros da agenda", () => {
  it("busca por nome, telefone, serviço ou profissional sem diferenciar maiúsculas", () => {
    expect(filterAgendaAppointments(appointments, { search: "alana" })).toHaveLength(1);
    expect(filterAgendaAppointments(appointments, { search: "8888" })[0]?.clientName).toBe("Bruna Costa");
    expect(filterAgendaAppointments(appointments, { search: "drenagem" })[0]?.clientName).toBe("Ana Silva");
  });

  it("filtra por status", () => {
    expect(filterAgendaAppointments(appointments, { status: "pendente" }).map((appointment) => appointment.clientName)).toEqual(["Bruna Costa"]);
  });

  it("filtra pela profissional selecionada", () => {
    expect(filterAgendaAppointments(appointments, { professionalId: "7" })[0]?.professionalName).toBe("Ketlen Antunes");
  });

  it("encontra agendamentos sem profissional definida", () => {
    expect(filterAgendaAppointments(appointments, { professionalId: "none" })[0]?.clientName).toBe("Carla Souza");
  });
});

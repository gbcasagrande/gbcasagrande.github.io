import { describe, expect, it } from "vitest";
import { buildAvailabilitySlots, civilDateDayOfWeek } from "../shared/availability";

describe("availability", () => {
  it("calcula o dia da semana civil sem deslocamento de fuso", () => {
    expect(civilDateDayOfWeek("2026-08-17")).toBe(1);
    expect(civilDateDayOfWeek("2026-08-22")).toBe(6);
    expect(civilDateDayOfWeek("2026-08-23")).toBe(0);
  });

  it("marca slots ocupados considerando a duração do serviço", () => {
    const slots = buildAvailabilitySlots({
      hours: [{ startTime: "07:30", endTime: "10:00" }],
      duration: 60,
      appointments: [{ appointmentTime: "08:30", duration: 60, status: "confirmado" }],
      blocks: [],
    });

    expect(slots.find((slot) => slot.time === "07:30")?.status).toBe("available");
    expect(slots.find((slot) => slot.time === "08:00")?.status).toBe("occupied");
    expect(slots.find((slot) => slot.time === "08:30")?.status).toBe("occupied");
    expect(slots.find((slot) => slot.time === "09:00")?.status).toBe("occupied");
  });

  it("marca como bloqueados os slots que cruzam um bloqueio administrativo", () => {
    const slots = buildAvailabilitySlots({
      hours: [{ startTime: "13:30", endTime: "16:00" }],
      duration: 60,
      appointments: [],
      blocks: [{ startTime: "14:30", endTime: "15:30" }],
    });

    expect(slots.find((slot) => slot.time === "13:30")?.status).toBe("available");
    expect(slots.find((slot) => slot.time === "14:00")?.status).toBe("blocked");
    expect(slots.find((slot) => slot.time === "14:30")?.status).toBe("blocked");
  });

  it("não gera horários que ultrapassam o fim do intervalo", () => {
    const slots = buildAvailabilitySlots({
      hours: [{ startTime: "07:30", endTime: "08:30" }],
      duration: 60,
      appointments: [],
      blocks: [],
    });

    expect(slots.map((slot) => slot.time)).toEqual(["07:30"]);
  });

  it("marca horários anteriores ao momento atual como past no dia atual", () => {
    const slots = buildAvailabilitySlots({
      hours: [{ startTime: "08:00", endTime: "12:00" }],
      duration: 60,
      appointments: [],
      blocks: [],
      targetDate: "2026-08-15",
      currentDate: "2026-08-15",
      currentTime: "09:15",
    });

    expect(slots.find((s) => s.time === "08:00")?.status).toBe("past");
    expect(slots.find((s) => s.time === "08:30")?.status).toBe("past");
    expect(slots.find((s) => s.time === "09:00")?.status).toBe("past");
    expect(slots.find((s) => s.time === "09:30")?.status).toBe("available");
    expect(slots.find((s) => s.time === "10:00")?.status).toBe("available");
  });

  it("permite todos os horários quando a data alvo é futura em relação à data atual", () => {
    const slots = buildAvailabilitySlots({
      hours: [{ startTime: "08:00", endTime: "12:00" }],
      duration: 60,
      appointments: [],
      blocks: [],
      targetDate: "2026-08-20",
      currentDate: "2026-08-15",
      currentTime: "15:00",
    });

    expect(slots.find((s) => s.time === "08:00")?.status).toBe("available");
    expect(slots.find((s) => s.time === "09:00")?.status).toBe("available");
  });
});

import { describe, expect, it } from "vitest";
import { normalizeCivilDate, tomorrowCivilDate } from "./dateUtils";

describe("dateUtils", () => {
  it("preserva exatamente uma data válida do calendário", () => {
    expect(normalizeCivilDate("2026-08-13")).toBe("2026-08-13");
    expect(normalizeCivilDate("2026-02-28")).toBe("2026-02-28");
  });

  it("rejeita datas inválidas sem fazer conversão silenciosa", () => {
    expect(() => normalizeCivilDate("2026-02-30")).toThrow("Data inválida");
    expect(() => normalizeCivilDate("13/08/2026")).toThrow("YYYY-MM-DD");
  });

  it("calcula amanhã no formato civil sem deslocamento de fuso", () => {
    expect(tomorrowCivilDate(new Date(2026, 7, 13, 23, 30))).toBe("2026-08-14");
    expect(tomorrowCivilDate(new Date(2026, 11, 31, 12, 0))).toBe("2027-01-01");
  });
});

const CIVIL_DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;

/**
 * Valida uma data civil no formato usado pelo input HTML type="date".
 * A string é devolvida sem convertê-la para Date, evitando deslocamentos de fuso.
 */
export function normalizeCivilDate(value: string): string {
  const match = CIVIL_DATE_PATTERN.exec(value);
  if (!match) {
    throw new Error("Data inválida. Use o formato YYYY-MM-DD.");
  }

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const check = new Date(Date.UTC(year, month - 1, day));

  if (
    check.getUTCFullYear() !== year ||
    check.getUTCMonth() !== month - 1 ||
    check.getUTCDate() !== day
  ) {
    throw new Error("Data inválida.");
  }

  return value;
}

/** Retorna amanhã como YYYY-MM-DD sem depender do timezone do servidor. */
export function todayCivilDate(now = new Date()): string {
  return [
    now.getFullYear(),
    String(now.getMonth() + 1).padStart(2, "0"),
    String(now.getDate()).padStart(2, "0"),
  ].join("-");
}

export function currentTimeString(now = new Date()): string {
  return [
    String(now.getHours()).padStart(2, "0"),
    String(now.getMinutes()).padStart(2, "0"),
  ].join(":");
}

export function tomorrowCivilDate(now = new Date()): string {
  const tomorrow = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() + 1));
  return [
    tomorrow.getUTCFullYear(),
    String(tomorrow.getUTCMonth() + 1).padStart(2, "0"),
    String(tomorrow.getUTCDate()).padStart(2, "0"),
  ].join("-");
}

import { eq, and, gte, lte, desc, asc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, services, appointments, admins, adminConnections, businessHours, blockedSlots, InsertService, InsertAppointment, InsertAdmin, siteContent as siteContentTable, professionals, serviceProfessionals, InsertProfessional, professionalSchedules, posts, postServices, raffles, raffleParticipants, raffleNumbers, InsertRaffle } from "../drizzle/schema";
import { SITE_CONTENT_DEFAULTS, SiteContentKey, SiteContentValues } from "../shared/siteContent";
import { ENV } from './_core/env';
import * as crypto from 'crypto';
import { tomorrowCivilDate, todayCivilDate, currentTimeString } from './dateUtils';
import { buildAvailabilitySlots, civilDateDayOfWeek, intervalsOverlap, timeToMinutes } from '../shared/availability';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER FUNCTIONS ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ ADMIN AUTHENTICATION ============

function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

export async function verifyAdminCredentials(username: string, password: string) {
  const db = await getDb();
  if (!db) return null;

  const passwordHash = hashPassword(password);
  const result = await db.select().from(admins).where(
    and(eq(admins.username, username), eq(admins.passwordHash, passwordHash))
  ).limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function getAdminByUsername(username: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(admins).where(eq(admins.username, username)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAllAdmins() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: admins.id, username: admins.username, name: admins.name, email: admins.email, role: admins.role, professionalId: admins.professionalId, createdAt: admins.createdAt }).from(admins).orderBy(asc(admins.username));
}

export async function getAdminById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(admins).where(eq(admins.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createAdmin(admin: { username: string; password: string; name?: string; email?: string | null; role?: string; professionalId?: number | null }) {
  const db = await getDb();
  if (!db) return null;

  const passwordHash = hashPassword(admin.password);
  await db.insert(admins).values({
    username: admin.username,
    passwordHash,
    name: admin.name,
    email: admin.email ?? null,
    role: admin.role || "user",
    professionalId: admin.professionalId ?? null,
  });

  return getAdminByUsername(admin.username);
}

export async function countAdminsByRole(role = "admin") {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(admins).where(eq(admins.role, role));
  return Number(result[0]?.count ?? 0);
}

export async function updateAdminProfile(id: number, data: { username?: string; name?: string; email?: string | null; role?: string; professionalId?: number | null }) {
  const db = await getDb();
  if (!db) return null;
  const existing = await getAdminById(id);
  if (!existing) return null;
  if (existing.role === "admin" && data.role === "user" && await countAdminsByRole("admin") <= 1) {
    throw new Error("Não é possível rebaixar o último administrador da barbearia.");
  }
  await db.update(admins).set(data).where(eq(admins.id, id));
  return getAdminById(id);
}

export async function createAdminConnection(connection: { adminId: number; sessionId: string; ipAddress?: string | null; userAgent?: string | null }) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(adminConnections).values({ ...connection, ipAddress: connection.ipAddress ?? null, userAgent: connection.userAgent ?? null });
  return getAdminConnectionBySessionId(connection.sessionId);
}
export async function getAdminConnectionBySessionId(sessionId: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(adminConnections).where(eq(adminConnections.sessionId, sessionId)).limit(1);
  return result[0] ?? null;
}
export async function touchAdminConnection(sessionId: string) {
  const db = await getDb();
  if (!db) return false;
  await db.update(adminConnections).set({ lastSeenAt: new Date() }).where(and(eq(adminConnections.sessionId, sessionId), sql`${adminConnections.disconnectedAt} IS NULL`));
  return true;
}
export async function disconnectAdminConnection(sessionId: string) {
  const db = await getDb();
  if (!db) return false;
  await db.update(adminConnections).set({ disconnectedAt: new Date(), lastSeenAt: new Date() }).where(eq(adminConnections.sessionId, sessionId));
  return true;
}
export async function getAdminConnections(adminId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(adminConnections).where(eq(adminConnections.adminId, adminId)).orderBy(desc(adminConnections.connectedAt)).limit(10);
}
export async function getAdminWorkspaceProfile(adminId: number) {
  const admin = await getAdminById(adminId);
  if (!admin) return null;
  const professional = admin.professionalId ? await getProfessionalById(admin.professionalId) : null;
  const profileServices = professional ? await getServicesForProfessionalForAccount(professional.id) : [];
  return { admin, professional, services: profileServices };
}
async function getServicesForProfessionalForAccount(professionalId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: services.id, name: services.name, description: services.description, defaultPrice: services.defaultPrice, duration: services.duration, benefits: services.benefits, icon: services.icon, priceDisplayMode: services.priceDisplayMode })
    .from(serviceProfessionals).innerJoin(services, eq(serviceProfessionals.serviceId, services.id))
    .where(and(eq(serviceProfessionals.professionalId, professionalId), eq(services.active, 1))).orderBy(asc(services.name));
}

export async function updateAdminPassword(id: number, newPassword: string) {
  const db = await getDb();
  if (!db) return false;
  await db.update(admins).set({ passwordHash: hashPassword(newPassword) }).where(eq(admins.id, id));
  return true;
}

export async function deleteAdmin(id: number) {
  const db = await getDb();
  if (!db) return false;
  const existing = await getAdminById(id);
  if (!existing) return false;
  if (existing.role === "admin" && await countAdminsByRole("admin") <= 1) {
    throw new Error("Não é possível excluir o último administrador da barbearia.");
  }
  await db.delete(admins).where(eq(admins.id, id));
  return true;
}

export async function ensureDefaultAdmin() {
  const db = await getDb();
  if (!db) return;

  const existing = await getAdminByUsername('navalha');
  if (!existing) {
    await createAdmin({
      username: 'navalha',
      password: '1889@gByu/1m',
      name: 'Gb Barbearia Admin',
      role: 'admin',
    });
    console.log('[Database] Default admin created');
  } else if (!existing.role) {
    const db = await getDb();
    if (db) await db.update(admins).set({ role: 'admin' }).where(eq(admins.id, existing.id));
  }
}

// ============ SERVICES FUNCTIONS ============

export async function getAllServices() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(services).where(eq(services.active, 1)).orderBy(desc(services.isFeatured), asc(services.sortOrder), desc(services.id));
}

export async function getAllServicesWithProfessionals() {
  const activeServices = await getAllServices();
  return Promise.all(activeServices.map(async (service) => ({
    ...service,
    professionals: await getProfessionalsForService(service.id),
  })));
}

export async function getServiceById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(services).where(eq(services.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function createService(service: Omit<InsertService, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(services).values(service);
  return getServiceById(Number(result[0].insertId));
}

export async function updateService(id: number, service: Partial<Omit<InsertService, 'id' | 'createdAt' | 'updatedAt'>>) {
  const db = await getDb();
  if (!db) return null;

  await db.update(services).set(service).where(eq(services.id, id));
  return getServiceById(id);
}

export async function setFeaturedService(id: number) {
  const db = await getDb();
  if (!db) return null;
  await db.update(services).set({ isFeatured: 0 }).where(eq(services.isFeatured, 1));
  await db.update(services).set({ isFeatured: 1 }).where(eq(services.id, id));
  return getServiceById(id);
}

export async function deleteService(id: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(services).set({ active: 0 }).where(eq(services.id, id));
  return true;
}

// ============ PROFESSIONAL FUNCTIONS ============

export async function getAllProfessionals(includeInactive = true) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(professionals);
  return includeInactive ? query.orderBy(asc(professionals.name)) : query.where(eq(professionals.active, 1)).orderBy(asc(professionals.name));
}

export async function getProfessionalById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(professionals).where(eq(professionals.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getProfessionalPublicProfile(identifier: string) {
  const db = await getDb();
  if (!db) return null;
  const numericId = Number(identifier);
  const identityCondition = Number.isSafeInteger(numericId) && numericId > 0 ? eq(professionals.id, numericId) : eq(professionals.profileSlug, identifier);
  const professional = await db.select().from(professionals).where(and(identityCondition, eq(professionals.active, 1))).limit(1);
  if (professional.length === 0) return null;
  const linkedServices = await db.select({
    id: services.id,
    name: services.name,
    description: services.description,
    defaultPrice: services.defaultPrice,
    duration: services.duration,
    benefits: services.benefits,
    icon: services.icon,
    priceDisplayMode: services.priceDisplayMode,
    discountPercent: services.discountPercent,
    promotionLabel: services.promotionLabel,
    sortOrder: services.sortOrder,
    isFeatured: services.isFeatured,
  }).from(serviceProfessionals)
    .innerJoin(services, eq(serviceProfessionals.serviceId, services.id))
    .where(and(eq(serviceProfessionals.professionalId, professional[0].id), eq(services.active, 1)))
    .orderBy(desc(services.isFeatured), asc(services.sortOrder), asc(services.name));
  return { ...professional[0], services: linkedServices };
}

export async function createProfessional(professional: Omit<InsertProfessional, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(professionals).values(professional);
  return getProfessionalById(Number(result[0].insertId));
}

export async function updateProfessional(id: number, professional: Partial<Omit<InsertProfessional, "id" | "createdAt" | "updatedAt">>) {
  const db = await getDb();
  if (!db) return null;
  await db.update(professionals).set(professional).where(eq(professionals.id, id));
  return getProfessionalById(id);
}

export async function deleteProfessional(id: number) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(serviceProfessionals).where(eq(serviceProfessionals.professionalId, id));
  await db.update(appointments).set({ professionalId: null }).where(eq(appointments.professionalId, id));
  await db.delete(professionals).where(eq(professionals.id, id));
  return true;
}

export async function getProfessionalsForService(serviceId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: professionals.id,
    name: professionals.name,
    specialty: professionals.specialty,
    bio: professionals.bio,
    phone: professionals.phone,
    instagramUrl: professionals.instagramUrl,
    avatarUrl: professionals.avatarUrl,
  }).from(serviceProfessionals)
    .innerJoin(professionals, eq(serviceProfessionals.professionalId, professionals.id))
    .where(and(eq(serviceProfessionals.serviceId, serviceId), eq(professionals.active, 1)))
    .orderBy(asc(professionals.name));
}

export async function getServiceProfessionalIds(serviceId: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select({ professionalId: serviceProfessionals.professionalId })
    .from(serviceProfessionals)
    .where(eq(serviceProfessionals.serviceId, serviceId));
  return rows.map((row) => row.professionalId);
}

export async function setServiceProfessionals(serviceId: number, professionalIds: number[]) {
  const db = await getDb();
  if (!db) return [];
  await db.delete(serviceProfessionals).where(eq(serviceProfessionals.serviceId, serviceId));
  const uniqueIds = Array.from(new Set(professionalIds)).filter((id) => Number.isInteger(id) && id > 0);
  if (uniqueIds.length > 0) {
    await db.insert(serviceProfessionals).values(uniqueIds.map((professionalId) => ({ serviceId, professionalId })));
  }
  return getProfessionalsForService(serviceId);
}

export async function setProfessionalServices(professionalId: number, serviceIds: number[]) {
  const db = await getDb();
  if (!db) return [];
  await db.delete(serviceProfessionals).where(eq(serviceProfessionals.professionalId, professionalId));
  const uniqueIds = Array.from(new Set(serviceIds)).filter((id) => Number.isInteger(id) && id > 0);
  if (uniqueIds.length > 0) {
    await db.insert(serviceProfessionals).values(uniqueIds.map((serviceId) => ({ serviceId, professionalId })));
  }
  return getServicesForProfessionalForAccount(professionalId);
}

// ============ SITE CONTENT FUNCTIONS ============

export async function getSiteContent(): Promise<SiteContentValues> {
  const content = { ...SITE_CONTENT_DEFAULTS } as SiteContentValues;
  const db = await getDb();
  if (!db) return content;

  const rows = await db.select().from(siteContentTable);
  for (const row of rows) {
    if (row.key in content) {
      content[row.key as SiteContentKey] = row.value;
    }
  }
  return content;
}

export async function updateSiteContent(values: Partial<SiteContentValues>) {
  const db = await getDb();
  if (!db) return getSiteContent();

  for (const [key, value] of Object.entries(values)) {
    if (!(key in SITE_CONTENT_DEFAULTS) || typeof value !== "string") continue;
    await db.insert(siteContentTable).values({ key, value }).onDuplicateKeyUpdate({
      set: { value },
    });
  }
  return getSiteContent();
}

// ============ AVAILABILITY FUNCTIONS ============

export const DEFAULT_BUSINESS_HOURS = [
  ...[1, 2, 3, 4, 5, 6].map((dayOfWeek) => ({ dayOfWeek, startTime: "07:30:00", endTime: "12:00:00" })),
  ...[1, 2, 3, 4, 5, 6].map((dayOfWeek) => ({ dayOfWeek, startTime: "13:30:00", endTime: "19:00:00" })),
] as const;

export async function ensureDefaultBusinessHours() {
  const db = await getDb();
  if (!db) return;
  const existing = await db.select({ id: businessHours.id }).from(businessHours).limit(1);
  if (existing.length === 0) {
    await db.insert(businessHours).values(DEFAULT_BUSINESS_HOURS.map((slot) => ({ ...slot, active: 1 })));
  }
}

export async function getBusinessHours() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(businessHours).orderBy(asc(businessHours.dayOfWeek), asc(businessHours.startTime));
}

export async function updateBusinessHours(
  slots: Array<{ id?: number; dayOfWeek: number; startTime: string; endTime: string; active: number }>,
) {
  const db = await getDb();
  if (!db) return [];
  await db.update(businessHours).set({ active: 0 }).where(eq(businessHours.active, 1));
  for (const slot of slots) {
    if (slot.id) {
      await db.update(businessHours).set({
        dayOfWeek: slot.dayOfWeek,
        startTime: slot.startTime,
        endTime: slot.endTime,
        active: slot.active,
      }).where(eq(businessHours.id, slot.id));
    } else {
      await db.insert(businessHours).values({
        dayOfWeek: slot.dayOfWeek,
        startTime: slot.startTime,
        endTime: slot.endTime,
        active: slot.active,
      });
    }
  }
  return getBusinessHours();
}

export async function getProfessionalSchedules(professionalId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(professionalSchedules).where(eq(professionalSchedules.professionalId, professionalId)).orderBy(asc(professionalSchedules.dayOfWeek), asc(professionalSchedules.startTime));
}

export async function updateProfessionalSchedules(
  professionalId: number,
  slots: Array<{ id?: number; dayOfWeek: number; startTime: string; endTime: string; active: number }>,
) {
  const db = await getDb();
  if (!db) return [];
  // Remove registros inativos ou substitui a agenda do barbeiro
  await db.delete(professionalSchedules).where(eq(professionalSchedules.professionalId, professionalId));
  for (const slot of slots) {
    await db.insert(professionalSchedules).values({
      professionalId,
      dayOfWeek: slot.dayOfWeek,
      startTime: slot.startTime,
      endTime: slot.endTime,
      active: slot.active,
    });
  }
  return getProfessionalSchedules(professionalId);
}

export async function getBlockedSlots(date?: string) {
  const db = await getDb();
  if (!db) return [];
  const query = db.select().from(blockedSlots);
  if (date) {
    return query.where(eq(blockedSlots.blockedDate, date)).orderBy(asc(blockedSlots.startTime));
  }
  return query.orderBy(desc(blockedSlots.blockedDate), asc(blockedSlots.startTime));
}

export async function createBlockedSlot(slot: Omit<typeof blockedSlots.$inferInsert, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(blockedSlots).values(slot);
  const created = await db.select().from(blockedSlots).where(eq(blockedSlots.id, Number(result[0].insertId))).limit(1);
  return created[0] ?? null;
}

export async function deleteBlockedSlot(id: number) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(blockedSlots).where(eq(blockedSlots.id, id));
  return true;
}

export async function getAvailabilityForDate(date: string, serviceId?: number, professionalId?: number | null) {
  const db = await getDb();
  if (!db) return [];

  const dayOfWeek = civilDateDayOfWeek(date);
  
  // Determinar o expediente aplicável: se professionalId for informado, tenta usar a agenda individual do barbeiro.
  // Se o barbeiro não tiver horários cadastrados, faz fallback para o expediente global da barbearia.
  let hours: Array<{ startTime: string; endTime: string; active: number; dayOfWeek: number }> = [];
  if (professionalId !== undefined && professionalId !== null) {
    const proSchedules = (await getProfessionalSchedules(professionalId)).filter((slot) => slot.active === 1 && slot.dayOfWeek === dayOfWeek);
    if (proSchedules.length > 0) {
      hours = proSchedules;
    }
  }
  if (hours.length === 0) {
    hours = (await getBusinessHours()).filter((slot) => slot.active === 1 && slot.dayOfWeek === dayOfWeek);
  }

  const service = serviceId ? await getServiceById(serviceId) : null;
  const duration = service?.duration || 60;
  const appointmentsForDate = await getAppointmentsByDate(date);
  const blocks = await getBlockedSlots(date);
  const allServices = await db.select({ id: services.id, duration: services.duration }).from(services);
  const durationByService = new Map(allServices.map((item) => [item.id, item.duration || 60]));

  const currentDate = todayCivilDate();
  const currentTime = currentTimeString();

  if (professionalId !== undefined && professionalId !== null) {
    const activeAppointments = appointmentsForDate.filter((appointment) => appointment.status !== "cancelado" && (appointment.professionalId === professionalId || appointment.professionalId === null));
    return buildAvailabilitySlots({
      hours,
      duration,
      appointments: activeAppointments.map((appointment) => ({
        appointmentTime: appointment.appointmentTime,
        duration: appointment.serviceId ? durationByService.get(appointment.serviceId) || 60 : 60,
        status: appointment.status,
      })),
      blocks,
      targetDate: date,
      currentDate,
      currentTime,
    });
  }

  // Sem preferência: unificar os horários disponíveis de todas os barbeiros vinculadas (respeitando os horários individuais de cada uma, inclusive fora do expediente global se configurado)
  const pros = serviceId ? await getProfessionalsForService(serviceId) : await getAllProfessionals(true);
  const globalHours = (await getBusinessHours()).filter((slot) => slot.active === 1 && slot.dayOfWeek === dayOfWeek);

  if (pros.length === 0) {
    const activeAppointments = appointmentsForDate.filter((appointment) => appointment.status !== "cancelado");
    return buildAvailabilitySlots({
      hours: globalHours,
      duration,
      appointments: activeAppointments.map((appointment) => ({
        appointmentTime: appointment.appointmentTime,
        duration: appointment.serviceId ? durationByService.get(appointment.serviceId) || 60 : 60,
        status: appointment.status,
      })),
      blocks,
      targetDate: date,
      currentDate,
      currentTime,
    });
  }

  // Coleta todos os slots livres de todas os barbeiros vinculadas
  const unionAvailableTimes = new Set<string>();
  const allPossibleSlotsMap = new Map<string, { time: string; status: "available" | "booked" | "past" }>();

  for (const pro of pros) {
    const proSchedules = (await getProfessionalSchedules(pro.id)).filter((slot) => slot.active === 1 && slot.dayOfWeek === dayOfWeek);
    const proHours = proSchedules.length > 0 ? proSchedules : globalHours;
    const proAppointments = appointmentsForDate.filter((appointment) => appointment.status !== "cancelado" && (appointment.professionalId === pro.id || appointment.professionalId === null));
    const proSlots = buildAvailabilitySlots({
      hours: proHours,
      duration,
      appointments: proAppointments.map((appointment) => ({
        appointmentTime: appointment.appointmentTime,
        duration: appointment.serviceId ? durationByService.get(appointment.serviceId) || 60 : 60,
        status: appointment.status,
      })),
      blocks,
      targetDate: date,
      currentDate,
      currentTime,
    });

    for (const slot of proSlots) {
      const normalizedStatus = slot.status === "available" ? ("available" as const) : ("booked" as const);
      if (!allPossibleSlotsMap.has(slot.time)) {
        allPossibleSlotsMap.set(slot.time, { time: slot.time, status: normalizedStatus });
      }
      if (slot.status === "available") {
        unionAvailableTimes.add(slot.time);
        allPossibleSlotsMap.set(slot.time, { time: slot.time, status: "available" });
      }
    }
  }

  // Ordena os slots pelo horário
  const sortedSlots = Array.from(allPossibleSlotsMap.values()).sort((a, b) => timeToMinutes(a.time) - timeToMinutes(b.time));
  return sortedSlots.map((slot) => ({
    ...slot,
    status: unionAvailableTimes.has(slot.time) ? ("available" as const) : ("booked" as const),
  }));
}

export async function getRandomAvailableProfessionalForSlot(date: string, time: string, serviceId?: number) {
  const pros = serviceId ? await getProfessionalsForService(serviceId) : await getAllProfessionals(true);
  if (pros.length === 0) return null;

  const freePros: number[] = [];
  for (const pro of pros) {
    const val = await validateAppointmentSlot({
      date,
      time,
      serviceId,
      professionalId: pro.id,
    });
    if (val.ok) {
      freePros.push(pro.id);
    }
  }

  if (freePros.length === 0) return null;
  const randomIndex = Math.floor(Math.random() * freePros.length);
  return freePros[randomIndex];
}

export async function validateAppointmentSlot({
  date,
  time,
  serviceId,
  professionalId,
  ignoreAppointmentId,
  ignoreWorkingHours = false,
}: {
  date: string;
  time: string;
  serviceId?: number;
  professionalId?: number | null;
  ignoreAppointmentId?: number;
  ignoreWorkingHours?: boolean;
}) {
  const db = await getDb();
  if (!db) return { ok: true as const };
  const start = timeToMinutes(time);
  const service = serviceId ? await getServiceById(serviceId) : null;
  const duration = service?.duration || 60;
  const end = start + duration;
  const dayOfWeek = civilDateDayOfWeek(date);
  
  let hours: Array<{ startTime: string; endTime: string; active: number; dayOfWeek: number }> = [];
  if (professionalId !== undefined && professionalId !== null) {
    const proSchedules = (await getProfessionalSchedules(professionalId)).filter((slot) => slot.active === 1 && slot.dayOfWeek === dayOfWeek);
    if (proSchedules.length > 0) {
      hours = proSchedules;
    }
  }
  if (hours.length === 0) {
    hours = (await getBusinessHours()).filter((slot) => slot.active === 1 && slot.dayOfWeek === dayOfWeek);
  }

  const currentDate = todayCivilDate();
  const currentTime = currentTimeString();
  if (date === currentDate && start <= timeToMinutes(currentTime)) {
    return { ok: false as const, reason: "Não é permitido agendar em horários anteriores ou iguais ao momento atual." };
  }

  const insideWorkingHours = hours.some((slot) => start >= timeToMinutes(slot.startTime) && end <= timeToMinutes(slot.endTime));
  if (!insideWorkingHours && !ignoreWorkingHours) return { ok: false as const, reason: "O horário está fora do expediente configurado." };

  const blocks = await getBlockedSlots(date);
  if (blocks.some((block) => intervalsOverlap(start, end, timeToMinutes(block.startTime), timeToMinutes(block.endTime)))) {
    return { ok: false as const, reason: "O horário está bloqueado pela administradora." };
  }

  const appointmentsForDate = await getAppointmentsByDate(date);
  const activeAppointments = appointmentsForDate.filter((appointment) => appointment.status !== "cancelado" && appointment.id !== ignoreAppointmentId && (professionalId ? (appointment.professionalId === professionalId || appointment.professionalId === null) : true));
  const allServices = await db.select({ id: services.id, duration: services.duration }).from(services);
  const durationByService = new Map(allServices.map((item) => [item.id, item.duration || 60]));
  if (activeAppointments.some((appointment) => {
    const appointmentStart = timeToMinutes(appointment.appointmentTime);
    const appointmentEnd = appointmentStart + (appointment.serviceId ? durationByService.get(appointment.serviceId) || 60 : 60);
    return intervalsOverlap(start, end, appointmentStart, appointmentEnd);
  })) {
    return { ok: false as const, reason: "O horário já está ocupado por outro agendamento." };
  }
  return { ok: true as const };
}

// ============ APPOINTMENTS FUNCTIONS ============

export async function getAllAppointments(professionalId?: number | null) {
  const db = await getDb();
  if (!db) return [];

  const query = db.select().from(appointments);
  if (professionalId !== undefined && professionalId !== null) {
    return query.where(eq(appointments.professionalId, professionalId)).orderBy(desc(appointments.appointmentDate), asc(appointments.appointmentTime));
  }
  return query.orderBy(desc(appointments.appointmentDate), asc(appointments.appointmentTime));
}

export async function getPendingPublicAppointments(professionalId?: number | null) {
  const db = await getDb();
  if (!db) return [];

  const query = db.select().from(appointments).where(
    and(eq(appointments.source, "public"), eq(appointments.status, "pendente"))
  );
  if (professionalId !== undefined && professionalId !== null) {
    return db.select().from(appointments).where(
      and(eq(appointments.source, "public"), eq(appointments.status, "pendente"), eq(appointments.professionalId, professionalId))
    ).orderBy(asc(appointments.appointmentDate), asc(appointments.appointmentTime), asc(appointments.createdAt));
  }
  return query.orderBy(asc(appointments.appointmentDate), asc(appointments.appointmentTime), asc(appointments.createdAt));
}

export async function getAppointmentById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(appointments).where(eq(appointments.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getAppointmentsByDateRange(startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) return [];

  // appointmentDate é uma data civil YYYY-MM-DD; não converter para Date.
  return db.select().from(appointments).where(
    and(
      gte(appointments.appointmentDate, startDate),
      lte(appointments.appointmentDate, endDate)
    )
  ).orderBy(asc(appointments.appointmentDate), asc(appointments.appointmentTime));
}

export async function getAppointmentsByDate(date: string) {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(appointments).where(
    eq(appointments.appointmentDate, date)
  ).orderBy(asc(appointments.appointmentTime));
}

export async function createAppointment(appointment: Omit<InsertAppointment, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(appointments).values(appointment);
  return getAppointmentById(Number(result[0].insertId));
}

export async function updateAppointment(id: number, appointment: Partial<Omit<InsertAppointment, 'id' | 'createdAt' | 'updatedAt'>>) {
  const db = await getDb();
  if (!db) return null;

  await db.update(appointments).set(appointment).where(eq(appointments.id, id));
  return getAppointmentById(id);
}

export async function deleteAppointment(id: number) {
  const db = await getDb();
  if (!db) return false;

  await db.delete(appointments).where(eq(appointments.id, id));
  return true;
}

export async function updateAppointmentStatus(id: number, status: 'confirmado' | 'cancelado' | 'pendente', professionalId?: number | null) {
  const db = await getDb();
  if (!db) return null;

  await db.update(appointments).set({ status, professionalId: professionalId === undefined ? undefined : professionalId }).where(eq(appointments.id, id));
  return getAppointmentById(id);
}

// ============ REPORTS FUNCTIONS ============

export async function getAdvancedReport({ year, month, professionalId }: { year?: number; month?: number; professionalId?: number | null }) {
  const db = await getDb();
  if (!db) return null;

  const allPros = await getAllProfessionals(true);
  const proMap = new Map(allPros.map(p => [p.id, p.name]));

  let query = db.select().from(appointments);
  let appointmentsList = await query;

  if (year !== undefined && month !== undefined) {
    const monthValue = String(month).padStart(2, '0');
    const startDate = `${year}-${monthValue}-01`;
    const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
    const endDate = `${year}-${monthValue}-${String(lastDay).padStart(2, '0')}`;
    appointmentsList = appointmentsList.filter(a => a.appointmentDate >= startDate && a.appointmentDate <= endDate);
  }

  if (professionalId !== undefined && professionalId !== null) {
    appointmentsList = appointmentsList.filter(a => a.professionalId === professionalId);
  }

  const totalRevenue = appointmentsList
    .filter(a => a.status === 'confirmado')
    .reduce((sum, a) => sum + parseFloat(a.price), 0);

  const serviceCount: Record<string, { count: number; revenue: number }> = {};
  const professionalStats: Record<string, { professionalId: number | null; name: string; total: number; confirmed: number; revenue: number }> = {};

  appointmentsList.forEach(a => {
    const proKey = a.professionalId ? String(a.professionalId) : "none";
    const proName = a.professionalId ? (proMap.get(a.professionalId) || "Barbeiro #" + a.professionalId) : "Sem preferência / Barbearia";
    if (!professionalStats[proKey]) {
      professionalStats[proKey] = { professionalId: a.professionalId, name: proName, total: 0, confirmed: 0, revenue: 0 };
    }
    professionalStats[proKey].total++;

    if (a.status === 'confirmado') {
      professionalStats[proKey].confirmed++;
      professionalStats[proKey].revenue += parseFloat(a.price);

      if (!serviceCount[a.serviceName]) {
        serviceCount[a.serviceName] = { count: 0, revenue: 0 };
      }
      serviceCount[a.serviceName].count++;
      serviceCount[a.serviceName].revenue += parseFloat(a.price);
    }
  });

  const topServices = Object.entries(serviceCount)
    .map(([name, data]) => ({ name, ...data }))
    .sort((a, b) => b.count - a.count);

  const byProfessional = Object.values(professionalStats).sort((a, b) => b.confirmed - a.confirmed || b.revenue - a.revenue);

  return {
    year: year ?? null,
    month: month ?? null,
    totalAppointments: appointmentsList.length,
    confirmedAppointments: appointmentsList.filter(a => a.status === 'confirmado').length,
    canceledAppointments: appointmentsList.filter(a => a.status === 'cancelado').length,
    pendingAppointments: appointmentsList.filter(a => a.status === 'pendente').length,
    totalRevenue,
    topServices,
    byProfessional,
  };
}

export async function getMonthlyReport(year: number, month: number, professionalId?: number | null) {
  return getAdvancedReport({ year, month, professionalId });
}

export async function getAppointmentsForNotification() {
  const db = await getDb();
  if (!db) return [];

  // Busca agendamentos confirmados para amanhã que ainda não receberam notificação
  const tomorrowStr = tomorrowCivilDate();

  return db.select().from(appointments).where(
    and(
      eq(appointments.appointmentDate, tomorrowStr),
      eq(appointments.status, 'confirmado'),
      eq(appointments.notificationSent, 0)
    )
  );
}

export async function markNotificationSent(id: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(appointments).set({ notificationSent: 1 }).where(eq(appointments.id, id));
  return true;
}

// Inicializa o administrador padrão e o expediente padrão ao carregar o módulo
ensureDefaultAdmin().catch(console.error);
ensureDefaultBusinessHours().catch(console.error);

// ============ POSTS / ARTIGOS FUNCTIONS ============

export async function getAllPosts() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(posts).orderBy(desc(posts.createdAt));
  return Promise.all(rows.map(async (post) => ({
    ...post,
    services: await getServicesForPost(post.id),
  })));
}

export async function getHomePosts() {
  const db = await getDb();
  if (!db) return { featured: [], recent: [] };

  const featuredRows = await db.select().from(posts).where(eq(posts.isFeatured, 1)).orderBy(desc(posts.createdAt)).limit(2);
  const featuredIds = featuredRows.map(p => p.id);

  const allRows = await db.select().from(posts).orderBy(desc(posts.createdAt));
  const recentRows = allRows.filter(p => !featuredIds.includes(p.id)).slice(0, 3);

  const featured = await Promise.all(featuredRows.map(async (post) => ({
    ...post,
    services: await getServicesForPost(post.id),
  })));

  const recent = await Promise.all(recentRows.map(async (post) => ({
    ...post,
    services: await getServicesForPost(post.id),
  })));

  return { featured, recent };
}

export async function getPaginatedArticles(limit = 10, offset = 0) {
  const db = await getDb();
  if (!db) return { pinned: [], items: [], total: 0 };

  const pinnedRows = await db.select().from(posts).where(eq(posts.isPinned, 1)).orderBy(desc(posts.createdAt)).limit(4);
  const pinned = await Promise.all(pinnedRows.map(async (post) => ({
    ...post,
    services: await getServicesForPost(post.id),
  })));

  const allRows = await db.select().from(posts).orderBy(desc(posts.createdAt));
  const total = allRows.length;
  const slicedRows = allRows.slice(offset, offset + limit);
  const items = await Promise.all(slicedRows.map(async (post) => ({
    ...post,
    services: await getServicesForPost(post.id),
  })));

  return { pinned, items, total };
}

export async function getEarlierPosts(excludeId: number, limit = 4) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(posts).orderBy(desc(posts.createdAt));
  const filtered = rows.filter(p => p.id !== excludeId).slice(0, limit);
  return Promise.all(filtered.map(async (post) => ({
    ...post,
    services: await getServicesForPost(post.id),
  })));
}

export async function getPostById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(posts).where(eq(posts.id, id)).limit(1);
  if (result.length === 0) return null;
  const post = result[0];
  const postSvcs = await getServicesForPost(post.id);
  return { ...post, services: postSvcs };
}

export async function getServicesForPost(postId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: services.id,
    name: services.name,
    description: services.description,
    defaultPrice: services.defaultPrice,
    duration: services.duration,
    icon: services.icon,
    priceDisplayMode: services.priceDisplayMode,
  }).from(postServices)
    .innerJoin(services, eq(postServices.serviceId, services.id))
    .where(eq(postServices.postId, postId));
}

export async function createPost(post: {
  title: string;
  slug: string;
  summary: string;
  content: string;
  coverImageUrl?: string;
  authorName: string;
  isPinned?: number;
  isFeatured?: number;
  serviceIds?: number[];
}) {
  const db = await getDb();
  if (!db) return null;
  const { serviceIds, ...postData } = post;

  if (postData.isPinned === 1) {
    const pinnedCount = await db.select().from(posts).where(eq(posts.isPinned, 1));
    if (pinnedCount.length >= 4) {
      throw new Error("Já existem 4 artigos fixados no topo. Remova o destaque de um deles antes de fixar este.");
    }
  }

  if (postData.isFeatured === 1) {
    const featuredCount = await db.select().from(posts).where(eq(posts.isFeatured, 1));
    if (featuredCount.length >= 2) {
      throw new Error("Já existem 2 artigos destacados na página inicial. Remova o destaque de um deles antes de destacar este.");
    }
  }

  const result = await db.insert(posts).values({
    ...postData,
    coverImageUrl: postData.coverImageUrl || null,
    isPinned: postData.isPinned || 0,
    isFeatured: postData.isFeatured || 0,
    reactionsCount: 0,
  });
  const postId = Number(result[0].insertId);
  if (serviceIds && serviceIds.length > 0) {
    await setPostServices(postId, serviceIds);
  }
  return getPostById(postId);
}

export async function updatePost(id: number, post: {
  title?: string;
  slug?: string;
  summary?: string;
  content?: string;
  coverImageUrl?: string | null;
  authorName?: string;
  isPinned?: number;
  isFeatured?: number;
  serviceIds?: number[];
}) {
  const db = await getDb();
  if (!db) return null;
  const { serviceIds, ...postData } = post;

  if (postData.isPinned === 1) {
    const existing = await getPostById(id);
    if (!existing || existing.isPinned !== 1) {
      const pinnedCount = await db.select().from(posts).where(eq(posts.isPinned, 1));
      if (pinnedCount.length >= 4) {
        throw new Error("Já existem 4 artigos fixados no topo. Remova o destaque de um deles antes de fixar este.");
      }
    }
  }

  if (postData.isFeatured === 1) {
    const existing = await getPostById(id);
    if (!existing || existing.isFeatured !== 1) {
      const featuredCount = await db.select().from(posts).where(eq(posts.isFeatured, 1));
      if (featuredCount.length >= 2) {
        throw new Error("Já existem 2 artigos destacados na página inicial. Remova o destaque de um deles antes de destacar este.");
      }
    }
  }

  await db.update(posts).set({
    ...postData,
    coverImageUrl: postData.coverImageUrl !== undefined ? postData.coverImageUrl : undefined,
  }).where(eq(posts.id, id));

  if (serviceIds !== undefined) {
    await setPostServices(id, serviceIds);
  }
  return getPostById(id);
}

export async function deletePost(id: number) {
  const db = await getDb();
  if (!db) return false;
  await db.delete(postServices).where(eq(postServices.postId, id));
  await db.delete(posts).where(eq(posts.id, id));
  return true;
}

// ============ CLIENT DIRECTORY FUNCTIONS ============

function daysSinceCivilDate(dateValue: string) {
  const [year, month, day] = dateValue.split("-").map(Number);
  const [todayYear, todayMonth, todayDay] = todayCivilDate().split("-").map(Number);
  const source = Date.UTC(year, month - 1, day);
  const current = Date.UTC(todayYear, todayMonth - 1, todayDay);
  return Math.max(0, Math.floor((current - source) / 86_400_000));
}

export async function getClientDirectory() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(appointments).orderBy(desc(appointments.appointmentDate), desc(appointments.appointmentTime), desc(appointments.id));
  const clients = new Map<string, {
    name: string;
    phone: string;
    lastAppointmentDate: string;
    lastAppointmentTime: string;
    lastServiceName: string;
    totalAppointments: number;
  }>();
  for (const appointment of rows) {
    if (appointment.status === "cancelado") continue;
    const phone = appointment.clientPhone.replace(/\D/g, "");
    if (!phone) continue;
    const existing = clients.get(phone);
    if (existing) {
      existing.totalAppointments += 1;
      continue;
    }
    clients.set(phone, {
      name: appointment.clientName,
      phone,
      lastAppointmentDate: appointment.appointmentDate,
      lastAppointmentTime: appointment.appointmentTime,
      lastServiceName: appointment.serviceName,
      totalAppointments: 1,
    });
  }
  return Array.from(clients.values()).map((client) => ({
    ...client,
    daysSinceLastAppointment: daysSinceCivilDate(client.lastAppointmentDate),
  }));
}

export async function setPostServices(postId: number, serviceIds: number[]) {
  const db = await getDb();
  if (!db) return;
  await db.delete(postServices).where(eq(postServices.postId, postId));
  for (const serviceId of serviceIds) {
    await db.insert(postServices).values({ postId, serviceId });
  }
}

export async function reactToPost(postId: number) {
  const db = await getDb();
  if (!db) return null;
  await db.update(posts).set({
    reactionsCount: sql`reactionsCount + 1`,
  }).where(eq(posts.id, postId));
  return getPostById(postId);
}

// ============ RAFFLE FUNCTIONS ============

function normalizeRafflePhone(phone: string) {
  return phone.replace(/\D/g, "");
}

export function getRaffleDisplayName(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length <= 1) return parts[0] || "Participante";
  return `${parts[0]} ${parts[parts.length - 1].charAt(0).toUpperCase()}.`;
}

async function getRaffleWithService(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(raffles).where(eq(raffles.id, id)).limit(1);
  if (!rows[0]) return null;
  const service = await getServiceById(rows[0].serviceId);
  return { ...rows[0], serviceName: service?.name || "Serviço da barbearia" };
}

async function getRaffleParticipantCount(id: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`COUNT(*)` }).from(raffleParticipants).where(eq(raffleParticipants.raffleId, id));
  return Number(result[0]?.count || 0);
}

async function getRaffleNumberCount(id: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`COUNT(*)` }).from(raffleNumbers).where(eq(raffleNumbers.raffleId, id));
  return Number(result[0]?.count || 0);
}

export async function getActiveRaffle() {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(raffles).where(eq(raffles.status, "active")).orderBy(desc(raffles.id)).limit(1);
  if (!rows[0]) return null;
  const raffle = await getRaffleWithService(rows[0].id);
  if (!raffle) return null;
  return { ...raffle, participantCount: await getRaffleParticipantCount(raffle.id), numberCount: await getRaffleNumberCount(raffle.id) };
}

export async function getFeaturedRaffle() {
  const active = await getActiveRaffle();
  if (active) return active;
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(raffles).where(eq(raffles.status, "finalized")).orderBy(desc(raffles.id)).limit(1);
  if (!rows[0]) return null;
  const publicRaffle = await getPublicRaffle(rows[0].id);
  return publicRaffle ? { ...publicRaffle, participantCount: publicRaffle.participantCount, numberCount: publicRaffle.numberCount } : null;
}

export async function getPublicRaffle(id: number) {
  const raffle = await getRaffleWithService(id);
  if (!raffle) return null;
  let winnerName: string | null = null;
  if (raffle.winnerParticipantId) {
    const db = await getDb();
    const winner = db ? await db.select().from(raffleParticipants).where(eq(raffleParticipants.id, raffle.winnerParticipantId)).limit(1) : [];
    winnerName = winner[0] ? getRaffleDisplayName(winner[0].name) : null;
  }
  return { ...raffle, winnerName, participantCount: await getRaffleParticipantCount(id), numberCount: await getRaffleNumberCount(id) };
}

export async function getRaffleHistory() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(raffles).where(eq(raffles.status, "finalized")).orderBy(desc(raffles.drawDate), desc(raffles.drawTime), desc(raffles.id));
  return Promise.all(rows.map(async (raffle) => getPublicRaffle(raffle.id)));
}

export async function getAllRaffles() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(raffles).orderBy(desc(raffles.id));
  return Promise.all(rows.map(async (raffle) => {
    const details = await getRaffleWithService(raffle.id);
    const winner = raffle.winnerParticipantId ? await db.select().from(raffleParticipants).where(eq(raffleParticipants.id, raffle.winnerParticipantId)).limit(1) : [];
    return {
      ...details!,
      winnerName: winner[0] ? getRaffleDisplayName(winner[0].name) : null,
      winnerPhone: winner[0]?.phone || null,
      participantCount: await getRaffleParticipantCount(raffle.id),
      numberCount: await getRaffleNumberCount(raffle.id),
    };
  }));
}

export async function createRaffle(input: Omit<InsertRaffle, "id" | "createdAt" | "updatedAt" | "status" | "winnerNumber" | "winnerParticipantId">) {
  const db = await getDb();
  if (!db) return null;
  await db.update(raffles).set({ status: "cancelled" }).where(eq(raffles.status, "active"));
  const result = await db.insert(raffles).values({ ...input, status: "active" });
  return getRaffleWithService(Number(result[0].insertId));
}

export async function registerRaffleParticipant(raffleId: number, name: string, phone: string) {
  const db = await getDb();
  if (!db) return null;
  const normalizedPhone = normalizeRafflePhone(phone);
  const raffle = await getRaffleWithService(raffleId);
  if (!raffle || raffle.status !== "active") throw new Error("Este sorteio não está recebendo inscrições.");
  const existing = await db.select().from(raffleParticipants).where(and(eq(raffleParticipants.raffleId, raffleId), eq(raffleParticipants.phone, normalizedPhone))).limit(1);
  let participant = existing[0];
  if (!participant) {
    const participantResult = await db.insert(raffleParticipants).values({ raffleId, name: name.trim(), phone: normalizedPhone, shareToken: crypto.randomUUID() });
    const participantRows = await db.select().from(raffleParticipants).where(eq(raffleParticipants.id, Number(participantResult[0].insertId))).limit(1);
    participant = participantRows[0];
    const maxRows = await db.select({ max: sql<number>`COALESCE(MAX(${raffleNumbers.number}), 0)` }).from(raffleNumbers).where(eq(raffleNumbers.raffleId, raffleId));
    await db.insert(raffleNumbers).values({ raffleId, participantId: participant.id, number: Number(maxRows[0]?.max || 0) + 1, kind: "initial" });
  }
  const numbers = await db.select().from(raffleNumbers).where(eq(raffleNumbers.participantId, participant.id)).orderBy(asc(raffleNumbers.number));
  return { participantId: participant.id, displayName: getRaffleDisplayName(participant.name), shareToken: participant.shareToken, numbers: numbers.map((item) => item.number) };
}

export async function claimRaffleShareNumber(shareToken: string) {
  const db = await getDb();
  if (!db) return null;
  const participants = await db.select().from(raffleParticipants).where(eq(raffleParticipants.shareToken, shareToken)).limit(1);
  const participant = participants[0];
  if (!participant) throw new Error("Link de compartilhamento inválido.");
  const raffle = await getRaffleWithService(participant.raffleId);
  if (!raffle || raffle.status !== "active") throw new Error("Este sorteio já foi finalizado.");
  const current = await db.select().from(raffleNumbers).where(and(eq(raffleNumbers.participantId, participant.id), eq(raffleNumbers.kind, "share"))).limit(1);
  if (!current[0]) {
    const maxRows = await db.select({ max: sql<number>`COALESCE(MAX(${raffleNumbers.number}), 0)` }).from(raffleNumbers).where(eq(raffleNumbers.raffleId, participant.raffleId));
    await db.insert(raffleNumbers).values({ raffleId: participant.raffleId, participantId: participant.id, number: Number(maxRows[0]?.max || 0) + 1, kind: "share" });
  }
  const numbers = await db.select().from(raffleNumbers).where(eq(raffleNumbers.participantId, participant.id)).orderBy(asc(raffleNumbers.number));
  return { participantId: participant.id, displayName: getRaffleDisplayName(participant.name), numbers: numbers.map((item) => item.number), added: !current[0] };
}

export async function getRaffleNumbersByPhone(raffleId: number, phone: string) {
  const db = await getDb();
  if (!db) return null;
  const participants = await db.select().from(raffleParticipants).where(and(eq(raffleParticipants.raffleId, raffleId), eq(raffleParticipants.phone, normalizeRafflePhone(phone)))).limit(1);
  if (!participants[0]) return null;
  const numbers = await db.select().from(raffleNumbers).where(eq(raffleNumbers.participantId, participants[0].id)).orderBy(asc(raffleNumbers.number));
  const raffle = await getRaffleWithService(raffleId);
  const winnerNumber = raffle?.winnerNumber ?? null;
  return {
    displayName: getRaffleDisplayName(participants[0].name),
    numbers: numbers.map((item) => item.number),
    winnerNumber,
    isWinner: winnerNumber !== null && numbers.some((item) => item.number === winnerNumber),
  };
}

export async function getRaffleParticipants(raffleId: number) {
  const db = await getDb();
  if (!db) return [];
  const participants = await db.select().from(raffleParticipants).where(eq(raffleParticipants.raffleId, raffleId)).orderBy(asc(raffleParticipants.createdAt));
  return Promise.all(participants.map(async (participant) => ({
    id: participant.id,
    name: participant.name,
    phone: participant.phone,
    createdAt: participant.createdAt,
    numbers: (await db.select().from(raffleNumbers).where(eq(raffleNumbers.participantId, participant.id)).orderBy(asc(raffleNumbers.number))).map((item) => item.number),
  })));
}

export async function activateRaffle(raffleId: number) {
  const db = await getDb();
  if (!db) return null;
  const raffle = await getRaffleWithService(raffleId);
  if (!raffle || raffle.status === "finalized") throw new Error("Sorteios finalizados não podem ser reativados.");
  await db.update(raffles).set({ status: "cancelled" }).where(eq(raffles.status, "active"));
  await db.update(raffles).set({ status: "active" }).where(eq(raffles.id, raffleId));
  return getRaffleWithService(raffleId);
}

export async function finalizeRaffle(raffleId: number) {
  const db = await getDb();
  if (!db) return null;
  const raffle = await getRaffleWithService(raffleId);
  if (!raffle || raffle.status !== "active") throw new Error("Este sorteio não está ativo.");
  const numbers = await db.select().from(raffleNumbers).where(eq(raffleNumbers.raffleId, raffleId));
  if (numbers.length === 0) throw new Error("É preciso ter pelo menos uma inscrição para sortear.");
  const winningNumber = numbers[crypto.randomInt(0, numbers.length)];
  await db.update(raffles).set({ status: "finalized", winnerNumber: winningNumber.number, winnerParticipantId: winningNumber.participantId }).where(eq(raffles.id, raffleId));
  return getPublicRaffle(raffleId);
}

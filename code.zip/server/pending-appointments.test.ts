import { beforeEach, describe, expect, it, vi } from "vitest";
import { SignJWT } from "jose";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

vi.mock("./db", () => ({
  getServiceById: vi.fn(),
  getAdminById: vi.fn(),
  validateAppointmentSlot: vi.fn(),
  createAppointment: vi.fn(),
  getPendingPublicAppointments: vi.fn(),
  getAppointmentById: vi.fn(),
  updateAppointment: vi.fn(),
  updateAppointmentStatus: vi.fn(),
  getProfessionalsForService: vi.fn().mockResolvedValue([]),
  getRandomAvailableProfessionalForSlot: vi.fn().mockResolvedValue(1),
}));

import * as db from "./db";

const ADMIN_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "grazi-massoterapia-secret-key");

function createMockContext(cookies: Record<string, string> = {}): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
      cookies,
    } as unknown as TrpcContext["req"],
    res: {
      cookie: vi.fn(),
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

async function createAdminContext() {
  vi.mocked(db.getAdminById).mockResolvedValue({ id: 1, username: "grazi", name: "Grazi Batistela", role: "admin", professionalId: null } as any);
  const token = await new SignJWT({ id: 1, username: "grazi", name: "Grazi Batistela", role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("1h")
    .sign(ADMIN_SECRET);
  return createMockContext({ admin_session: token });
}

describe("solicitações públicas de agendamento", () => {
  beforeEach(() => vi.clearAllMocks());

  it("salva uma solicitação como pendente e com origem pública", async () => {
    vi.mocked(db.getServiceById).mockResolvedValue({
      id: 7,
      name: "Drenagem Linfática",
      description: "Descrição",
      defaultPrice: "150.00",
      duration: 60,
      active: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    vi.mocked(db.validateAppointmentSlot).mockResolvedValue({ ok: true });
    vi.mocked(db.createAppointment).mockResolvedValue({
      id: 42,
      clientName: "Ana Silva",
      clientPhone: "(54) 99999-0000",
      clientEmail: null,
      serviceName: "Drenagem Linfática",
      serviceId: 7,
      appointmentDate: "2026-08-20",
      appointmentTime: "14:30:00",
      price: "150.00",
      status: "pendente",
      notes: "Solicitação enviada pelo site.",
      notificationSent: 0,
      source: "public",
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    const caller = appRouter.createCaller(createMockContext());
    const result = await caller.appointments.request({
      serviceId: 7,
      appointmentDate: "2026-08-20",
      appointmentTime: "14:30",
      clientName: "Ana Silva",
      clientPhone: "(54) 99999-0000",
    });

    expect(result?.status).toBe("pendente");
    expect(result?.source).toBe("public");
    expect(db.createAppointment).toHaveBeenCalledWith(expect.objectContaining({
      serviceName: "Drenagem Linfática",
      appointmentDate: "2026-08-20",
      appointmentTime: "14:30",
      status: "pendente",
      source: "public",
    }));
  });

  it("salva o profissional escolhido junto com a solicitação", async () => {
    vi.mocked(db.getServiceById).mockResolvedValue({
      id: 7,
      name: "Drenagem Linfática",
      description: null,
      defaultPrice: "150.00",
      duration: 60,
      active: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    vi.mocked(db.getProfessionalsForService).mockResolvedValue([{ id: 12, name: "Dra. Marina" }] as any);
    vi.mocked(db.validateAppointmentSlot).mockResolvedValue({ ok: true });
    vi.mocked(db.createAppointment).mockResolvedValue({ status: "pendente" } as any);

    const caller = appRouter.createCaller(createMockContext());
    await caller.appointments.request({ serviceId: 7, professionalId: 12, appointmentDate: "2026-08-20", appointmentTime: "14:30", clientName: "Ana Silva", clientPhone: "(54) 99999-0000" });

    expect(db.createAppointment).toHaveBeenCalledWith(expect.objectContaining({ professionalId: 12 }));
  });

  it("não salva quando o horário deixa de estar disponível", async () => {
    vi.mocked(db.getServiceById).mockResolvedValue({
      id: 7,
      name: "Drenagem Linfática",
      description: null,
      defaultPrice: "150.00",
      duration: 60,
      active: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    vi.mocked(db.validateAppointmentSlot).mockResolvedValue({ ok: false, reason: "O horário já está ocupado por outro agendamento." });

    const caller = appRouter.createCaller(createMockContext());
    await expect(caller.appointments.request({
      serviceId: 7,
      appointmentDate: "2026-08-20",
      appointmentTime: "14:30",
      clientName: "Ana Silva",
      clientPhone: "(54) 99999-0000",
    })).rejects.toThrow("O horário já está ocupado");
    expect(db.createAppointment).not.toHaveBeenCalled();
  });
});

describe("revisão administrativa de solicitações", () => {
  beforeEach(() => vi.clearAllMocks());

  it("exige autenticação para listar pendentes", async () => {
    const caller = appRouter.createCaller(createMockContext());
    await expect(caller.appointments.pendingPublic()).rejects.toThrow("Não autorizado");
  });

  it("lista pendentes apenas para a administradora", async () => {
    vi.mocked(db.getPendingPublicAppointments).mockResolvedValue([
      {
        id: 42,
        clientName: "Ana Silva",
        clientPhone: "(54) 99999-0000",
        clientEmail: null,
        serviceName: "Drenagem Linfática",
        serviceId: 7,
        appointmentDate: "2026-08-20",
        appointmentTime: "14:30:00",
        price: "150.00",
        status: "pendente",
        notes: "Solicitação enviada pelo site.",
        notificationSent: 0,
        source: "public",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]);

    const caller = appRouter.createCaller(await createAdminContext());
    const result = await caller.appointments.pendingPublic();
    expect(result).toHaveLength(1);
    expect(result[0].source).toBe("public");
  });

  it("permite confirmar a solicitação com o profissional atribuído", async () => {
    vi.mocked(db.getAppointmentById).mockResolvedValue({ id: 42, serviceId: 7, appointmentDate: "2026-08-20", appointmentTime: "14:30:00", status: "pendente" } as any);
    vi.mocked(db.getProfessionalsForService).mockResolvedValue([{ id: 12, name: "Dra. Marina" }] as any);
    vi.mocked(db.validateAppointmentSlot).mockResolvedValue({ ok: true });
    vi.mocked(db.updateAppointmentStatus).mockResolvedValue({ status: "confirmado", professionalId: 12 } as any);

    const caller = appRouter.createCaller(await createAdminContext());
    await caller.appointments.updateStatus({ id: 42, status: "confirmado", professionalId: 12 });

    expect(db.updateAppointmentStatus).toHaveBeenCalledWith(42, "confirmado", 12);
  });

  it("permite confirmar a solicitação sem criar um segundo agendamento", async () => {
    vi.mocked(db.getAppointmentById).mockResolvedValue({
      id: 42,
      clientName: "Ana Silva",
      clientPhone: "(54) 99999-0000",
      clientEmail: null,
      serviceName: "Drenagem Linfática",
      serviceId: 7,
      appointmentDate: "2026-08-20",
      appointmentTime: "14:30:00",
      price: "150.00",
      status: "pendente",
      notes: "Solicitação enviada pelo site.",
      notificationSent: 0,
      source: "public",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    vi.mocked(db.validateAppointmentSlot).mockResolvedValue({ ok: true });
    vi.mocked(db.updateAppointmentStatus).mockResolvedValue({
      id: 42,
      clientName: "Ana Silva",
      clientPhone: "(54) 99999-0000",
      clientEmail: null,
      serviceName: "Drenagem Linfática",
      serviceId: 7,
      appointmentDate: "2026-08-20",
      appointmentTime: "14:30:00",
      price: "150.00",
      status: "confirmado",
      notes: "Solicitação enviada pelo site.",
      notificationSent: 0,
      source: "public",
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    const caller = appRouter.createCaller(await createAdminContext());
    const result = await caller.appointments.updateStatus({ id: 42, status: "confirmado" });
    expect(result?.status).toBe("confirmado");
    expect(db.updateAppointmentStatus).toHaveBeenCalledWith(42, "confirmado", undefined);
    expect(db.createAppointment).not.toHaveBeenCalled();
  });
});

import { getAppointmentStatusLabel } from "@shared/appointmentStatus";

describe("identificação visual de status", () => {
  it("usa Solicitação pendente para pedidos públicos ainda não confirmados", () => {
    expect(getAppointmentStatusLabel("pendente", "public")).toBe("Solicitação pendente");
    expect(getAppointmentStatusLabel("pendente", "admin")).toBe("Pendente");
    expect(getAppointmentStatusLabel("confirmado", "public")).toBe("Confirmado");
  });
});

describe("edição de solicitação pendente", () => {
  beforeEach(() => vi.clearAllMocks());

  it("permite editar data e horário antes de confirmar, respeitando conflitos", async () => {
    vi.mocked(db.getAppointmentById).mockResolvedValue({
      id: 42,
      clientName: "Ana Silva",
      clientPhone: "(54) 99999-0000",
      clientEmail: null,
      serviceName: "Drenagem Linfática",
      serviceId: 7,
      appointmentDate: "2026-08-20",
      appointmentTime: "14:30:00",
      price: "150.00",
      status: "pendente",
      notes: "Solicitação enviada pelo site.",
      notificationSent: 0,
      source: "public",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    vi.mocked(db.validateAppointmentSlot).mockResolvedValue({ ok: true });
    vi.mocked(db.updateAppointment).mockResolvedValue({
      id: 42,
      clientName: "Ana Silva",
      clientPhone: "(54) 99999-0000",
      clientEmail: null,
      serviceName: "Drenagem Linfática",
      serviceId: 7,
      appointmentDate: "2026-08-21",
      appointmentTime: "15:00",
      price: "150.00",
      status: "pendente",
      notes: "Solicitação enviada pelo site.",
      notificationSent: 0,
      source: "public",
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    const caller = appRouter.createCaller(await createAdminContext());
    const result = await caller.appointments.update({ id: 42, appointmentDate: "2026-08-21", appointmentTime: "15:00" });

    expect(result?.appointmentDate).toBe("2026-08-21");
    expect(db.validateAppointmentSlot).toHaveBeenCalledWith({
      date: "2026-08-21",
      time: "15:00",
      serviceId: 7,
      ignoreAppointmentId: 42,
      ignoreWorkingHours: false,
      professionalId: undefined,
    });
    expect(db.updateAppointment).toHaveBeenCalledWith(42, {
      appointmentDate: "2026-08-21",
      appointmentTime: "15:00",
    });
  });
});

describe("listagem completa de próximos horários", () => {
  it("não restringe os horários futuros a um limite máximo de itens", () => {
    const appointments = [
      { id: 1, appointmentDate: "2026-08-30", appointmentTime: "10:00", status: "confirmado" },
      { id: 2, appointmentDate: "2026-08-30", appointmentTime: "11:00", status: "pendente" },
      { id: 3, appointmentDate: "2026-08-30", appointmentTime: "12:00", status: "confirmado" },
      { id: 4, appointmentDate: "2026-08-30", appointmentTime: "13:00", status: "confirmado" },
      { id: 5, appointmentDate: "2026-08-30", appointmentTime: "14:00", status: "confirmado" },
      { id: 6, appointmentDate: "2026-08-30", appointmentTime: "15:00", status: "confirmado" },
      { id: 7, appointmentDate: "2026-08-30", appointmentTime: "16:00", status: "confirmado" },
    ];
    // Simula a lógica sem .slice(0, 6)
    const filtered = appointments.filter(a => a.status !== "cancelado");
    expect(filtered.length).toBe(7);
  });
});

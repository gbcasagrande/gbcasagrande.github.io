import { describe, expect, it, vi, beforeEach } from "vitest";
import { SignJWT } from "jose";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

vi.mock("./db", () => ({
  getAdminById: vi.fn(),
  getAllProfessionals: vi.fn(),
  getProfessionalById: vi.fn(),
  getProfessionalPublicProfile: vi.fn(),
  createProfessional: vi.fn(),
  updateProfessional: vi.fn(),
  deleteProfessional: vi.fn(),
  getProfessionalsForService: vi.fn(),
  getServiceProfessionalIds: vi.fn(),
  setServiceProfessionals: vi.fn(),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn(),
}));

import * as db from "./db";
import { storagePut } from "./storage";

const ADMIN_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "grazi-massoterapia-secret-key");

function createMockContext(cookies: Record<string, string> = {}): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {}, cookies } as unknown as TrpcContext["req"],
    res: { cookie: vi.fn(), clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

async function createAdminContext() {
  vi.mocked(db.getAdminById).mockResolvedValue({ id: 1, username: "grazi", name: "Grazi Batistela", role: "admin", professionalId: null } as any);
  const token = await new SignJWT({ id: 1, username: "grazi", name: "Grazi Batistela", role: "admin" })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("1h")
    .sign(ADMIN_SECRET);
  return createMockContext({ admin_session: token });
}

describe("gestão de profissionais", () => {
  beforeEach(() => vi.clearAllMocks());

  it("exclui definitivamente o profissional pela rota protegida", async () => {
    vi.mocked(db.deleteProfessional).mockResolvedValue(true);
    const caller = appRouter.createCaller(await createAdminContext());

    const result = await caller.professionals.delete({ id: 12 });

    expect(result).toBe(true);
    expect(db.deleteProfessional).toHaveBeenCalledWith(12);
  });

  it("retorna o perfil público com Instagram e serviços vinculados", async () => {
    vi.mocked(db.getProfessionalPublicProfile).mockResolvedValue({
      id: 12,
      name: "Ketlen Antunes",
      specialty: "Massoterapia",
      bio: "Atendimento acolhedor.",
      instagramUrl: "@ketlen.antunes",
      services: [{ id: 7, name: "Drenagem Linfática" }],
    } as any);
    const caller = appRouter.createCaller(createMockContext());

    const profile = await caller.professionals.profile({ slug: "ketlen-antunes" });

    expect(profile?.name).toBe("Ketlen Antunes");
    expect(profile?.instagramUrl).toBe("@ketlen.antunes");
    expect(profile?.services[0]?.name).toBe("Drenagem Linfática");
    expect(db.getProfessionalPublicProfile).toHaveBeenCalledWith("ketlen-antunes");
  });

  it("faz upload da foto e retorna a URL persistível", async () => {
    vi.mocked(storagePut).mockResolvedValue({ key: "benessere/professionals/avatar.jpg", url: "https://cdn.example/avatar.jpg" });
    const caller = appRouter.createCaller(await createAdminContext());

    const result = await caller.professionals.uploadAvatar({
      fileName: "avatar.jpg",
      contentType: "image/jpeg",
      dataBase64: "aGVsbG8=",
    });

    expect(result.url).toBe("https://cdn.example/avatar.jpg");
    expect(storagePut).toHaveBeenCalledWith(expect.stringContaining("benessere/professionals/"), expect.any(Buffer), "image/jpeg");
  });

  it("remove apenas a foto pela rota protegida e preserva o cadastro", async () => {
    vi.mocked(db.updateProfessional).mockResolvedValue({ id: 12, name: "Ketlen Antunes", avatarUrl: null } as any);
    const caller = appRouter.createCaller(await createAdminContext());

    const result = await caller.professionals.removeAvatar({ id: 12 });

    expect(result).toEqual({ id: 12, name: "Ketlen Antunes", avatarUrl: null });
    expect(db.updateProfessional).toHaveBeenCalledWith(12, { avatarUrl: null });
  });
});

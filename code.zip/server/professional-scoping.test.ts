import { describe, expect, it, vi, beforeEach } from "vitest";
import { SignJWT } from "jose";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

vi.mock("./db", () => ({
  getAdminById: vi.fn(),
  getAllAppointments: vi.fn(),
  getAppointmentById: vi.fn(),
  deleteAppointment: vi.fn(),
  getMonthlyReport: vi.fn(),
}));

import * as db from "./db";

const ADMIN_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "grazi-massoterapia-secret-key");

function createMockContext(cookies: Record<string, string> = {}): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {}, cookies } as unknown as TrpcContext["req"],
    res: { cookie: vi.fn(), clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

async function createUserContext(professionalId: number) {
  vi.mocked(db.getAdminById).mockResolvedValue({ id: 5, username: "marina", name: "Marina", role: "user", professionalId } as any);
  const token = await new SignJWT({ id: 5, username: "marina", name: "Marina", role: "user" })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("1h")
    .sign(ADMIN_SECRET);
  return createMockContext({ admin_session: token });
}

describe("escopo por profissional", () => {
  beforeEach(() => vi.clearAllMocks());

  it("restringe a listagem de agendamentos ao professionalId do usuário vinculado", async () => {
    vi.mocked(db.getAllAppointments).mockResolvedValue([
      { id: 10, professionalId: 12, serviceName: "Massagem", status: "confirmado", price: "100.00", appointmentDate: "2026-08-20", appointmentTime: "10:00" },
      { id: 11, professionalId: 15, serviceName: "Drenagem", status: "confirmado", price: "120.00", appointmentDate: "2026-08-20", appointmentTime: "11:00" },
    ] as any);

    const caller = appRouter.createCaller(await createUserContext(12));
    const appointments = await caller.appointments.list();

    expect(db.getAllAppointments).toHaveBeenCalledWith(12);
  });

  it("bloqueia exclusão de agendamento pertencente a outro profissional", async () => {
    vi.mocked(db.getAppointmentById).mockResolvedValue({
      id: 20,
      professionalId: 15,
      clientName: "Cliente Alheio",
      appointmentDate: "2026-08-20",
      appointmentTime: "14:00",
    } as any);

    const caller = appRouter.createCaller(await createUserContext(12));

    await expect(caller.appointments.delete({ id: 20 })).rejects.toThrow("Acesso restrito");
  });
});

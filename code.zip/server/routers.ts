import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import * as jwt from "jose";
import { normalizeCivilDate } from "./dateUtils";
import { storagePut } from "./storage";
import { randomUUID } from "node:crypto";

const ADMIN_JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || 'navalha-barbearia-secret-key');
const ADMIN_COOKIE_NAME = 'admin_session';
const toProfileSlug = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 150) || "barbeiro";

// Middleware para verificar autenticação de admin
const adminProcedure = publicProcedure.use(async ({ ctx, next }) => {
  const adminToken = ctx.req.cookies?.[ADMIN_COOKIE_NAME];
  
  if (!adminToken) {
    throw new Error('Não autorizado');
  }

  try {
    const { payload } = await jwt.jwtVerify(adminToken, ADMIN_JWT_SECRET);
    const adminId = Number(payload.id);
    if (!Number.isInteger(adminId) || adminId <= 0) throw new Error("Sessão inválida");
    const currentAdmin = await db.getAdminById(adminId);
    if (!currentAdmin) throw new Error("Usuário não encontrado");
    if (typeof payload.sid === "string") await db.touchAdminConnection(payload.sid);
    return next({
      ctx: {
        ...ctx,
        admin: {
          id: currentAdmin.id,
          username: currentAdmin.username,
          name: currentAdmin.name || currentAdmin.username,
          email: currentAdmin.email,
          role: currentAdmin.role || "user",
          professionalId: currentAdmin.professionalId,
        },
      },
    });
  } catch {
    throw new Error('Sessão expirada');
  }
});

// Middleware restrito somente a administradores (exclui usuários comuns)
const strictAdminProcedure = adminProcedure.use(async ({ ctx, next }) => {
  if (ctx.admin.role !== "admin") {
    throw new Error("Acesso restrito a administradores.");
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Autenticação administrativa
  adminAuth: router({
    login: publicProcedure
      .input(z.object({
        username: z.string().min(1),
        password: z.string().min(1),
      }))
      .mutation(async ({ input, ctx }) => {
        const admin = await db.verifyAdminCredentials(input.username.trim().toLowerCase(), input.password);
        
        if (!admin) {
          throw new Error('Credenciais inválidas');
        }

        const token = await new jwt.SignJWT({
          id: admin.id,
          username: admin.username,
          name: admin.name,
          role: admin.role || "user",
          professionalId: admin.professionalId,
          sid: randomUUID(),
        })
          .setProtectedHeader({ alg: 'HS256' })
          .setExpirationTime('7d')
          .sign(ADMIN_JWT_SECRET);

        ctx.res.cookie(ADMIN_COOKIE_NAME, token, {
          httpOnly: true,
          secure: true,
          sameSite: 'none',
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 dias
          path: '/',
        });
        const loginPayload = jwt.decodeJwt(token);
        if (typeof loginPayload.sid === "string") {
          await db.createAdminConnection?.({ adminId: admin.id, sessionId: loginPayload.sid, ipAddress: ctx.req.ip, userAgent: ctx.req.get?.("user-agent") });
        }

        return {
          success: true,
          admin: {
            id: admin.id,
            username: admin.username,
            name: admin.name,
            email: admin.email,
            role: admin.role || "user",
            professionalId: admin.professionalId,
          },
        };
      }),

    logout: publicProcedure.mutation(async ({ ctx }) => {
      const adminToken = ctx.req.cookies?.[ADMIN_COOKIE_NAME];
      if (adminToken) {
        try {
          const payload = jwt.decodeJwt(adminToken);
          if (typeof payload.sid === "string") await db.disconnectAdminConnection?.(payload.sid);
        } catch { /* cookie inválido: ainda deve ser removido */ }
      }
      ctx.res.clearCookie(ADMIN_COOKIE_NAME, { path: '/' });
      return { success: true };
    }),

    me: publicProcedure.query(async ({ ctx }) => {
      const adminToken = ctx.req.cookies?.[ADMIN_COOKIE_NAME];
      
      if (!adminToken) {
        return null;
      }

      try {
        const { payload } = await jwt.jwtVerify(adminToken, ADMIN_JWT_SECRET);
        const adminId = Number(payload.id);
        if (!Number.isInteger(adminId) || adminId <= 0) return null;
        const currentAdmin = await db.getAdminById(adminId);
        if (!currentAdmin) return null;
        return {
          id: currentAdmin.id,
          username: currentAdmin.username,
          name: currentAdmin.name || currentAdmin.username,
          email: currentAdmin.email,
          role: currentAdmin.role || "user",
          professionalId: currentAdmin.professionalId,
        };
      } catch {
        return null;
      }
    }),

    list: strictAdminProcedure.query(async () => db.getAllAdmins()),

    create: strictAdminProcedure
      .input(z.object({
        username: z.string().trim().min(3).max(64).regex(/^[a-zA-Z0-9._-]+$/),
        password: z.string().min(8).max(128),
        name: z.string().trim().min(2).max(255),
        email: z.string().email().max(320).nullable().optional(),
        role: z.enum(["admin", "user"]).default("user"),
        professionalId: z.number().int().positive().nullable().optional(),
      }))
      .mutation(async ({ input }) => {
        const username = input.username.toLowerCase();
        if (await db.getAdminByUsername(username)) throw new Error("Este usuário já existe.");
        if (input.professionalId) {
          const professional = await db.getProfessionalById(input.professionalId);
          if (!professional) throw new Error("Barbeiro não encontrado.");
        }
        let professionalId = input.professionalId ?? null;
        if (!professionalId) {
          const profile = await db.createProfessional({ name: input.name.trim(), profileSlug: toProfileSlug(username), verified: 0, profileAccepted: 0, active: 1 });
          professionalId = profile?.id ?? null;
        }
        const created = await db.createAdmin({ ...input, username, email: input.email ?? null, professionalId });
        if (!created) throw new Error("Não foi possível criar o usuário.");
        return { id: created.id, username: created.username, name: created.name, email: created.email, role: created.role, professionalId: created.professionalId };
      }),

    update: strictAdminProcedure
      .input(z.object({
        id: z.number().int().positive(),
        username: z.string().trim().min(3).max(64).regex(/^[a-zA-Z0-9._-]+$/).optional(),
        name: z.string().trim().min(2).max(255).optional(),
        email: z.string().email().max(320).nullable().optional(),
        role: z.enum(["admin", "user"]).optional(),
        professionalId: z.number().int().positive().nullable().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, username, ...data } = input;
        if (username) {
          const existing = await db.getAdminByUsername(username.toLowerCase());
          if (existing && existing.id !== id) throw new Error("Este nome de usuário já está em uso.");
        }
        return db.updateAdminProfile(id, { ...data, ...(username ? { username: username.toLowerCase() } : {}) });
      }),

    resetPassword: strictAdminProcedure
      .input(z.object({ id: z.number().int().positive(), newPassword: z.string().min(8).max(128) }))
      .mutation(async ({ input }) => {
        await db.updateAdminPassword(input.id, input.newPassword);
        return { success: true };
      }),

    delete: strictAdminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.admin.id === input.id) throw new Error("Você não pode excluir sua própria conta por aqui.");
        return db.deleteAdmin(input.id);
      }),

    updateProfile: adminProcedure
      .input(z.object({
        name: z.string().trim().min(2).max(255).optional(),
        username: z.string().trim().min(3).max(64).regex(/^[a-zA-Z0-9._-]+$/).optional(),
        email: z.string().email().max(320).nullable().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (input.username) {
          const existing = await db.getAdminByUsername(input.username.toLowerCase());
          if (existing && existing.id !== ctx.admin.id) throw new Error("Este nome de usuário já está em uso.");
        }
        return db.updateAdminProfile(ctx.admin.id, {
          ...(input.name ? { name: input.name } : {}),
          ...(input.username ? { username: input.username.toLowerCase() } : {}),
          ...(input.email !== undefined ? { email: input.email?.trim().toLowerCase() || null } : {}),
        }).then(async (updated) => {
          if (input.username && ctx.admin.professionalId) {
            await db.updateProfessional(ctx.admin.professionalId, { profileSlug: toProfileSlug(input.username) });
          }
          return updated;
        });
      }),

    deleteAccount: adminProcedure
      .mutation(async ({ ctx }) => {
        return db.deleteAdmin(ctx.admin.id);
      }),

    changePassword: adminProcedure
      .input(z.object({ currentPassword: z.string().min(1), newPassword: z.string().min(8).max(128) }))
      .mutation(async ({ ctx, input }) => {
        const currentAdmin = await db.getAdminById(ctx.admin.id);
        if (!currentAdmin || !await db.verifyAdminCredentials(currentAdmin.username, input.currentPassword)) throw new Error("A senha atual está incorreta.");
        await db.updateAdminPassword(currentAdmin.id, input.newPassword);
        return { success: true };
      }),
    workspace: adminProcedure.query(async ({ ctx }) => db.getAdminWorkspaceProfile(ctx.admin.id)),
    connections: adminProcedure.query(async ({ ctx }) => db.getAdminConnections(ctx.admin.id)),
    acceptProfile: adminProcedure.mutation(async ({ ctx }) => {
      if (!ctx.admin.professionalId) throw new Error("Esta conta ainda não possui um perfil barbeiro.");
      return db.updateProfessional(ctx.admin.professionalId, { profileAccepted: 1 });
    }),
    updateOwnProfile: adminProcedure
      .input(z.object({
        bio: z.string().max(5000).nullable().optional(),
        avatarUrl: z.string().url().nullable().optional(),
        coverUrl: z.string().url().nullable().optional(),
        address: z.string().max(500).nullable().optional(),
        instagramUrl: z.string().max(500).nullable().optional(),
        profileSlug: z.string().trim().min(2).max(160).optional(),
        serviceIds: z.array(z.number().int().positive()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.admin.professionalId) throw new Error("Esta conta ainda não possui um perfil barbeiro.");
        const profile = await db.updateProfessional(ctx.admin.professionalId, {
          bio: input.bio,
          avatarUrl: input.avatarUrl,
          coverUrl: input.coverUrl,
          address: input.address,
          instagramUrl: input.instagramUrl,
          profileSlug: input.profileSlug ? toProfileSlug(input.profileSlug) : undefined,
        });
        if (input.serviceIds) {
          await db.setProfessionalServices(ctx.admin.professionalId, input.serviceIds);
        }
        return profile;
      }),
    uploadOwnAvatar: adminProcedure
      .input(z.object({ contentType: z.enum(["image/jpeg", "image/png", "image/webp"]), dataBase64: z.string().min(1).max(8_000_000) }))
      .mutation(async ({ ctx, input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const image = await storagePut(`navalha/profiles/${ctx.admin.id}-${Date.now()}-${randomUUID()}.${extension}`, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return { url: image.url };
      }),
    uploadOwnCover: adminProcedure
      .input(z.object({ contentType: z.enum(["image/jpeg", "image/png", "image/webp"]), dataBase64: z.string().min(1).max(12_000_000) }))
      .mutation(async ({ ctx, input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const image = await storagePut(`navalha/profiles/covers/${ctx.admin.id}-${Date.now()}-${randomUUID()}.${extension}`, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return { url: image.url };
      }),
  }),

  // Serviços
  services: router({
    list: publicProcedure.query(async () => {
      return db.getAllServices();
    }),

    listWithProfessionals: publicProcedure.query(async () => {
      return db.getAllServicesWithProfessionals();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getServiceById(input.id);
      }),

    create: strictAdminProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        defaultPrice: z.string(),
        duration: z.number().optional(),
        benefits: z.string().optional(),
        icon: z.string().max(64).optional(),
        priceDisplayMode: z.enum(["price", "evaluation"]).optional(),
        discountPercent: z.number().int().min(0).max(100).optional(),
        promotionLabel: z.string().trim().max(120).nullable().optional(),
        sortOrder: z.number().int().min(0).max(9999).optional(),
        isFeatured: z.number().int().min(0).max(1).optional(),
        professionalIds: z.array(z.number().int().positive()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { professionalIds, ...serviceInput } = input;
        const service = await db.createService(serviceInput);
        if (service?.id && input.isFeatured === 1) await db.setFeaturedService(service.id);
        if (service && professionalIds) await db.setServiceProfessionals(service.id, professionalIds);
        return service;
      }),

    update: strictAdminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        defaultPrice: z.string().optional(),
        duration: z.number().optional(),
        benefits: z.string().optional(),
        icon: z.string().max(64).optional(),
        priceDisplayMode: z.enum(["price", "evaluation"]).optional(),
        discountPercent: z.number().int().min(0).max(100).optional(),
        promotionLabel: z.string().trim().max(120).nullable().optional(),
        sortOrder: z.number().int().min(0).max(9999).optional(),
        isFeatured: z.number().int().min(0).max(1).optional(),
        professionalIds: z.array(z.number().int().positive()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, professionalIds, ...data } = input;
        const service = await db.updateService(id, data);
        if (input.isFeatured === 1) await db.setFeaturedService(id);
        if (professionalIds) await db.setServiceProfessionals(id, professionalIds);
        return service;
      }),

    delete: strictAdminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.deleteService(input.id);
      }),
  }),

  // Barbeiros e vínculos de atendimento
  professionals: router({
    list: strictAdminProcedure.query(async () => db.getAllProfessionals()),
    listActive: publicProcedure.query(async () => db.getAllProfessionals(false)),
    profile: publicProcedure.input(z.object({ slug: z.string().trim().min(1).max(160) })).query(async ({ input }) => db.getProfessionalPublicProfile(input.slug)),
    forService: publicProcedure.input(z.object({ serviceId: z.number().int().positive() })).query(async ({ input }) => db.getProfessionalsForService(input.serviceId)),
    serviceIds: adminProcedure.input(z.object({ serviceId: z.number().int().positive() })).query(async ({ input }) => db.getServiceProfessionalIds(input.serviceId)),

    uploadAvatar: strictAdminProcedure
      .input(z.object({
        fileName: z.string().min(1).max(120),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        dataBase64: z.string().min(1).max(8_000_000),
      }))
      .mutation(async ({ input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const key = `navalha/professionals/${Date.now()}-${randomUUID()}.${extension}`;
        const image = await storagePut(key, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return { url: image.url };
      }),

    uploadCover: strictAdminProcedure
      .input(z.object({
        fileName: z.string().min(1).max(120),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        dataBase64: z.string().min(1).max(12_000_000),
      }))
      .mutation(async ({ input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const key = `navalha/professionals/covers/${Date.now()}-${randomUUID()}.${extension}`;
        const image = await storagePut(key, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return { url: image.url };
      }),

    create: strictAdminProcedure
      .input(z.object({
        name: z.string().trim().min(2),
        specialty: z.string().trim().optional(),
        bio: z.string().optional(),
        phone: z.string().trim().optional(),
        instagramUrl: z.string().trim().max(500).optional(),
        profileSlug: z.string().trim().max(160).optional(),
        coverUrl: z.string().url().optional().or(z.literal("")),
        verified: z.number().int().min(0).max(1).optional(),
        avatarUrl: z.string().url().optional().or(z.literal("")),
      }))
      .mutation(async ({ input }) => db.createProfessional({ ...input, name: input.name.trim(), specialty: input.specialty?.trim() || undefined, phone: input.phone?.trim() || undefined, instagramUrl: input.instagramUrl?.trim() || undefined, profileSlug: toProfileSlug(input.profileSlug || input.name), coverUrl: input.coverUrl || undefined, verified: input.verified ?? 1, avatarUrl: input.avatarUrl || undefined, active: 1 })),

    update: strictAdminProcedure
      .input(z.object({
        id: z.number().int().positive(),
        name: z.string().trim().min(2).optional(),
        specialty: z.string().trim().optional().nullable(),
        bio: z.string().optional().nullable(),
        phone: z.string().trim().optional().nullable(),
        instagramUrl: z.string().trim().max(500).optional().nullable(),
        profileSlug: z.string().trim().max(160).optional().nullable(),
        coverUrl: z.string().url().optional().or(z.literal("")).nullable(),
        verified: z.number().int().min(0).max(1).optional(),
        avatarUrl: z.string().url().optional().or(z.literal("")).nullable(),
        active: z.number().int().min(0).max(1).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updateProfessional(id, { ...data, name: data.name?.trim(), specialty: data.specialty?.trim() || null, phone: data.phone?.trim() || null, instagramUrl: data.instagramUrl?.trim() || null, profileSlug: data.profileSlug ? toProfileSlug(data.profileSlug) : undefined, coverUrl: data.coverUrl || null, avatarUrl: data.avatarUrl || null });
      }),

    removeAvatar: strictAdminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => db.updateProfessional(input.id, { avatarUrl: null })),

    delete: strictAdminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => db.deleteProfessional(input.id)),
    setServiceProfessionals: strictAdminProcedure
      .input(z.object({ serviceId: z.number().int().positive(), professionalIds: z.array(z.number().int().positive()) }))
      .mutation(async ({ input }) => db.setServiceProfessionals(input.serviceId, input.professionalIds)),

    schedules: strictAdminProcedure
      .input(z.object({ professionalId: z.number().int().positive() }))
      .query(async ({ input }) => db.getProfessionalSchedules(input.professionalId)),

    updateSchedules: strictAdminProcedure
      .input(z.object({
        professionalId: z.number().int().positive(),
        slots: z.array(z.object({
          id: z.number().optional(),
          dayOfWeek: z.number().int().min(0).max(6),
          startTime: z.string().regex(/^\d{2}:\d{2}$/),
          endTime: z.string().regex(/^\d{2}:\d{2}$/),
          active: z.number().int().min(0).max(1),
        })),
      }))
      .mutation(async ({ input }) => {
        for (const slot of input.slots) {
          if (slot.startTime >= slot.endTime) throw new Error("O início do expediente do barbeiro deve ser anterior ao fim.");
        }
        return db.updateProfessionalSchedules(input.professionalId, input.slots);
      }),
  }),

  // Postagens e artigos da barbearia
  posts: router({
    list: publicProcedure.query(async () => db.getAllPosts()),
    home: publicProcedure.query(async () => db.getHomePosts()),
    paginated: publicProcedure.input(z.object({ limit: z.number().int().min(1).max(50).default(10), offset: z.number().int().min(0).default(0) })).query(async ({ input }) => db.getPaginatedArticles(input.limit, input.offset)),
    earlier: publicProcedure.input(z.object({ excludeId: z.number().int().positive(), limit: z.number().int().min(1).max(10).default(4) })).query(async ({ input }) => db.getEarlierPosts(input.excludeId, input.limit)),
    getById: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => db.getPostById(input.id)),

    uploadCover: strictAdminProcedure
      .input(z.object({
        fileName: z.string().min(1).max(120),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        dataBase64: z.string().min(1).max(8_000_000),
      }))
      .mutation(async ({ input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const key = `navalha/posts/${Date.now()}-${randomUUID()}.${extension}`;
        const image = await storagePut(key, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return { url: image.url };
      }),

    create: strictAdminProcedure
      .input(z.object({
        title: z.string().trim().min(2),
        slug: z.string().trim().min(2),
        summary: z.string().trim().min(5),
        content: z.string().trim().min(10),
        coverImageUrl: z.string().url().optional().or(z.literal("")),
        authorName: z.string().trim().min(2),
        isPinned: z.number().int().min(0).max(1).optional(),
        isFeatured: z.number().int().min(0).max(1).optional(),
        serviceIds: z.array(z.number().int().positive()).optional(),
      }))
      .mutation(async ({ input }) => db.createPost({
        ...input,
        title: input.title.trim(),
        slug: input.slug.trim().toLowerCase().replace(/\s+/g, "-"),
        summary: input.summary.trim(),
        content: input.content.trim(),
        coverImageUrl: input.coverImageUrl || undefined,
        authorName: input.authorName.trim(),
      })),

    update: strictAdminProcedure
      .input(z.object({
        id: z.number().int().positive(),
        title: z.string().trim().min(2).optional(),
        slug: z.string().trim().min(2).optional(),
        summary: z.string().trim().min(5).optional(),
        content: z.string().trim().min(10).optional(),
        coverImageUrl: z.string().url().optional().or(z.literal("")).nullable(),
        authorName: z.string().trim().min(2).optional(),
        isPinned: z.number().int().min(0).max(1).optional(),
        isFeatured: z.number().int().min(0).max(1).optional(),
        serviceIds: z.array(z.number().int().positive()).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return db.updatePost(id, {
          ...data,
          title: data.title?.trim(),
          slug: data.slug?.trim().toLowerCase().replace(/\s+/g, "-"),
          summary: data.summary?.trim(),
          content: data.content?.trim(),
          coverImageUrl: data.coverImageUrl !== undefined ? (data.coverImageUrl || null) : undefined,
          authorName: data.authorName?.trim(),
        });
      }),

    delete: strictAdminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => db.deletePost(input.id)),

    react: publicProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => db.reactToPost(input.id)),
  }),

  // Conteúdo editável da página inicial
  siteContent: router({
    get: publicProcedure.query(async () => db.getSiteContent()),

    update: strictAdminProcedure
      .input(z.object({
        heroName: z.string().min(1).optional(),
        heroSubtitle: z.string().min(1).optional(),
        heroDescription: z.string().min(1).optional(),
        aboutTitle: z.string().min(1).optional(),
        aboutParagraph1: z.string().min(1).optional(),
        aboutParagraph2: z.string().min(1).optional(),
        aboutHighlightTitle: z.string().min(1).optional(),
        aboutHighlightDescription: z.string().min(1).optional(),
        aboutImageUrl: z.string().min(1).optional(),
        logoUrl: z.string().min(1).optional(),
        heroImageUrl: z.string().min(1).optional(),
        teamImageUrl: z.string().min(1).optional(),
        announcementText: z.string().optional(),
        announcementActive: z.string().optional(),
        announcementLinkText: z.string().optional(),
      }))
      .mutation(async ({ input }) => db.updateSiteContent(input)),

    uploadAboutImage: strictAdminProcedure
      .input(z.object({
        fileName: z.string().min(1).max(120),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        dataBase64: z.string().min(1).max(8_000_000),
      }))
      .mutation(async ({ input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const key = `navalha-cia/about-${Date.now()}-${randomUUID()}.${extension}`;
        const image = await storagePut(key, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return db.updateSiteContent({ aboutImageUrl: image.url });
      }),

    uploadLogoImage: strictAdminProcedure
      .input(z.object({
        fileName: z.string().min(1).max(120),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        dataBase64: z.string().min(1).max(8_000_000),
      }))
      .mutation(async ({ input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const key = `navalha-cia/logo-${Date.now()}-${randomUUID()}.${extension}`;
        const image = await storagePut(key, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return db.updateSiteContent({ logoUrl: image.url });
      }),

    uploadHeroImage: strictAdminProcedure
      .input(z.object({
        fileName: z.string().min(1).max(120),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        dataBase64: z.string().min(1).max(8_000_000),
      }))
      .mutation(async ({ input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const key = `navalha-cia/hero-${Date.now()}-${randomUUID()}.${extension}`;
        const image = await storagePut(key, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return db.updateSiteContent({ heroImageUrl: image.url });
      }),

    uploadTeamImage: strictAdminProcedure
      .input(z.object({
        fileName: z.string().min(1).max(120),
        contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        dataBase64: z.string().min(1).max(8_000_000),
      }))
      .mutation(async ({ input }) => {
        const extension = input.contentType.split("/")[1].replace("jpeg", "jpg");
        const key = `navalha-cia/team-${Date.now()}-${randomUUID()}.${extension}`;
        const image = await storagePut(key, Buffer.from(input.dataBase64, "base64"), input.contentType);
        return db.updateSiteContent({ teamImageUrl: image.url });
    }),
  }),

  // Base consolidada de clientes que já agendaram
  clients: router({
    list: strictAdminProcedure.query(() => db.getClientDirectory()),
  }),

  // Sorteios promocionais
  raffles: router({
    active: publicProcedure.query(() => db.getActiveRaffle()),
    featured: publicProcedure.query(() => db.getFeaturedRaffle()),

    list: publicProcedure.query(() => db.getRaffleHistory()),

    getById: publicProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(({ input }) => db.getPublicRaffle(input.id)),

    register: publicProcedure
      .input(z.object({
        raffleId: z.number().int().positive(),
        name: z.string().trim().min(2).max(255),
        phone: z.string().trim().min(8).max(30),
      }))
      .mutation(({ input }) => db.registerRaffleParticipant(input.raffleId, input.name, input.phone)),

    claimShare: publicProcedure
      .input(z.object({ shareToken: z.string().min(16).max(64) }))
      .mutation(({ input }) => db.claimRaffleShareNumber(input.shareToken)),

    numbersByPhone: publicProcedure
      .input(z.object({ raffleId: z.number().int().positive(), phone: z.string().trim().min(8).max(30) }))
      .query(({ input }) => db.getRaffleNumbersByPhone(input.raffleId, input.phone)),

    adminList: strictAdminProcedure.query(() => db.getAllRaffles()),

    participants: strictAdminProcedure
      .input(z.object({ raffleId: z.number().int().positive() }))
      .query(({ input }) => db.getRaffleParticipants(input.raffleId)),

    create: strictAdminProcedure
      .input(z.object({
        title: z.string().trim().min(2).max(255),
        description: z.string().trim().max(2000).optional(),
        drawDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        drawTime: z.string().regex(/^\d{2}:\d{2}$/),
        serviceId: z.number().int().positive(),
      }))
      .mutation(async ({ input, ctx }) => {
        const service = await db.getServiceById(input.serviceId);
        if (!service || service.active !== 1) throw new Error("Serviço não encontrado ou inativo.");
        return db.createRaffle({ ...input, description: input.description || null, createdBy: ctx.admin.id });
      }),

    activate: strictAdminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ input }) => db.activateRaffle(input.id)),

    finalize: strictAdminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ input }) => db.finalizeRaffle(input.id)),
  }),

  // Disponibilidade, expediente e bloqueios
  availability: router({
    slots: publicProcedure
      .input(z.object({ date: z.string(), serviceId: z.number().optional(), professionalId: z.number().int().positive().optional().nullable() }))
      .query(async ({ input }) => db.getAvailabilityForDate(normalizeCivilDate(input.date), input.serviceId, input.professionalId)),

    businessHours: strictAdminProcedure.query(async () => db.getBusinessHours()),

    updateBusinessHours: strictAdminProcedure
      .input(z.object({
        slots: z.array(z.object({
          id: z.number().optional(),
          dayOfWeek: z.number().int().min(0).max(6),
          startTime: z.string().regex(/^\d{2}:\d{2}$/),
          endTime: z.string().regex(/^\d{2}:\d{2}$/),
          active: z.number().int().min(0).max(1),
        })),
      }))
      .mutation(async ({ input }) => {
        for (const slot of input.slots) {
          if (slot.startTime >= slot.endTime) throw new Error("O início do expediente deve ser anterior ao fim.");
        }
        return db.updateBusinessHours(input.slots);
      }),

    blockedSlots: strictAdminProcedure.query(async () => db.getBlockedSlots()),

    createBlockedSlot: strictAdminProcedure
      .input(z.object({
        blockedDate: z.string(),
        startTime: z.string().regex(/^\d{2}:\d{2}$/),
        endTime: z.string().regex(/^\d{2}:\d{2}$/),
        reason: z.string().max(255).optional(),
      }))
      .mutation(async ({ input }) => {
        const blockedDate = normalizeCivilDate(input.blockedDate);
        if (input.startTime >= input.endTime) throw new Error("O início do bloqueio deve ser anterior ao fim.");
        return db.createBlockedSlot({ ...input, blockedDate });
      }),

    deleteBlockedSlot: strictAdminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => db.deleteBlockedSlot(input.id)),
  }),

  // Agendamentos
  appointments: router({
    list: adminProcedure.query(async ({ ctx }) => {
      const proId = ctx.admin.role === 'admin' ? null : ctx.admin.professionalId;
      return db.getAllAppointments(proId);
    }),

    getById: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const appointment = await db.getAppointmentById(input.id);
        if (!appointment) return null;
        if (ctx.admin.role !== 'admin' && ctx.admin.professionalId && appointment.professionalId !== ctx.admin.professionalId) {
          throw new Error("Acesso restrito aos seus próprios agendamentos.");
        }
        return appointment;
      }),

    getByDate: adminProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ ctx, input }) => {
        const list = await db.getAppointmentsByDate(input.date);
        if (ctx.admin.role === 'admin' || !ctx.admin.professionalId) return list;
        return list.filter(a => a.professionalId === ctx.admin.professionalId);
      }),

    getByDateRange: adminProcedure
      .input(z.object({
        startDate: z.string(),
        endDate: z.string(),
      }))
      .query(async ({ ctx, input }) => {
        const list = await db.getAppointmentsByDateRange(input.startDate, input.endDate);
        if (ctx.admin.role === 'admin' || !ctx.admin.professionalId) return list;
        return list.filter(a => a.professionalId === ctx.admin.professionalId);
      }),

    request: publicProcedure
      .input(z.object({
        serviceId: z.number().int().positive(),
        appointmentDate: z.string(),
        appointmentTime: z.string().regex(/^\d{2}:\d{2}$/),
        clientName: z.string().trim().min(2),
        clientPhone: z.string().trim().min(8),
        professionalId: z.number().int().positive().optional(),
        reason: z.string().trim().optional(),
      }))
      .mutation(async ({ input }) => {
        const service = await db.getServiceById(input.serviceId);
        if (!service || service.active !== 1) throw new Error("Serviço não encontrado.");
        const phoneDigits = input.clientPhone.replace(/\D/g, "");
        const assignedProfessionals = await db.getProfessionalsForService(service.id);
        if (input.professionalId && !assignedProfessionals.some((professional) => professional.id === input.professionalId)) {
          throw new Error("Barbeiro não atende este serviço.");
        }
        if (phoneDigits.length < 10 || phoneDigits.length > 13) {
          throw new Error("Informe um telefone válido para contato.");
        }

        const appointmentDate = normalizeCivilDate(input.appointmentDate);
        let assignedProfessionalId = input.professionalId ?? null;

        if (!assignedProfessionalId) {
          assignedProfessionalId = await db.getRandomAvailableProfessionalForSlot(appointmentDate, input.appointmentTime, service.id);
          if (!assignedProfessionalId) {
            throw new Error("Não há nenhum barbeiro disponível neste horário. Por favor, escolha outro horário.");
          }
        }

        const validation = await db.validateAppointmentSlot({
          date: appointmentDate,
          time: input.appointmentTime,
          serviceId: service.id,
          professionalId: assignedProfessionalId,
        });
        if (!validation.ok) throw new Error(validation.reason);

        return db.createAppointment({
          clientName: input.clientName.trim(),
          clientPhone: input.clientPhone.trim(),
          clientEmail: undefined,
          serviceName: service.name,
          serviceId: service.id,
          appointmentDate,
          appointmentTime: input.appointmentTime,
          price: (Number(service.defaultPrice) * (1 - (service.discountPercent || 0) / 100)).toFixed(2),
          status: "pendente",
          notes: "Solicitação enviada pelo site.",
          source: "public",
          professionalId: assignedProfessionalId,
          reason: input.reason || undefined,
        });
      }),

    pendingPublic: adminProcedure.query(async ({ ctx }) => {
      const proId = ctx.admin.role === 'admin' ? null : ctx.admin.professionalId;
      return db.getPendingPublicAppointments(proId);
    }),

    create: adminProcedure
      .input(z.object({
        clientName: z.string().min(1),
        clientPhone: z.string().min(1),
        clientEmail: z.string().email().optional(),
        serviceName: z.string().min(1),
        serviceId: z.number().optional(),
        appointmentDate: z.string(),
        appointmentTime: z.string(),
        price: z.string(),
        status: z.enum(['confirmado', 'cancelado', 'pendente']).optional(),
        notes: z.string().optional(),
        professionalId: z.number().int().positive().optional(),
        reason: z.string().optional().nullable(),
      }))
      .mutation(async ({ ctx, input }) => {
        let assignedProId = input.professionalId;
        if (ctx.admin.role !== 'admin') {
          if (ctx.admin.professionalId) {
            assignedProId = ctx.admin.professionalId;
          } else {
            throw new Error("Usuário sem barbeiro vinculado não pode criar agendamentos.");
          }
        }
        const appointmentDate = normalizeCivilDate(input.appointmentDate);
        const ignoreWorkingHours = ctx.admin.role !== 'admin' && Boolean(ctx.admin.professionalId);
        const validation = await db.validateAppointmentSlot({ date: appointmentDate, time: input.appointmentTime, serviceId: input.serviceId, professionalId: assignedProId, ignoreWorkingHours });
        if (!validation.ok) throw new Error(validation.reason);
        if (assignedProId && input.serviceId) {
          const assignedProfessionals = await db.getProfessionalsForService(input.serviceId);
          if (!assignedProfessionals.some((professional) => professional.id === assignedProId)) throw new Error("Barbeiro não atende este serviço.");
        }
        return db.createAppointment({
          clientName: input.clientName,
          clientPhone: input.clientPhone,
          clientEmail: input.clientEmail,
          serviceName: input.serviceName,
          serviceId: input.serviceId,
          appointmentDate,
          appointmentTime: input.appointmentTime,
          price: input.price,
          status: input.status || 'pendente',
          notes: input.notes,
          professionalId: assignedProId,
          reason: input.reason,
        });
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        clientName: z.string().min(1).optional(),
        clientPhone: z.string().min(1).optional(),
        clientEmail: z.string().email().optional().nullable(),
        serviceName: z.string().min(1).optional(),
        serviceId: z.number().optional().nullable(),
        appointmentDate: z.string().optional(),
        appointmentTime: z.string().optional(),
        price: z.string().optional(),
        status: z.enum(['confirmado', 'cancelado', 'pendente']).optional(),
        notes: z.string().optional().nullable(),
        professionalId: z.number().int().positive().optional().nullable(),
        reason: z.string().optional().nullable(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, appointmentDate, ...data } = input;
        const existing = await db.getAppointmentById(id);
        if (!existing) throw new Error("Agendamento não encontrado.");
        if (ctx.admin.role !== 'admin' && ctx.admin.professionalId && existing.professionalId !== ctx.admin.professionalId) {
          throw new Error("Acesso restrito aos seus próprios agendamentos.");
        }
        const nextDate = appointmentDate ? normalizeCivilDate(appointmentDate) : existing.appointmentDate;
        const nextTime = data.appointmentTime ?? existing.appointmentTime;
        const nextServiceId = data.serviceId === undefined ? existing.serviceId ?? undefined : data.serviceId ?? undefined;
        let nextProfessionalId = data.professionalId === undefined ? existing.professionalId : data.professionalId;
        if (ctx.admin.role !== 'admin') {
          nextProfessionalId = ctx.admin.professionalId;
        }
        const ignoreWorkingHours = ctx.admin.role !== 'admin' && Boolean(ctx.admin.professionalId);
        const validation = await db.validateAppointmentSlot({ date: nextDate, time: nextTime, serviceId: nextServiceId, professionalId: nextProfessionalId, ignoreAppointmentId: id, ignoreWorkingHours });
        if (!validation.ok) throw new Error(validation.reason);
        if (nextProfessionalId && nextServiceId) {
          const assignedProfessionals = await db.getProfessionalsForService(nextServiceId);
          if (!assignedProfessionals.some((professional) => professional.id === nextProfessionalId)) throw new Error("Barbeiro não atende este serviço.");
        }
        const updateData: Record<string, unknown> = { ...data, appointmentDate: nextDate, professionalId: nextProfessionalId };
        return db.updateAppointment(id, updateData);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const existing = await db.getAppointmentById(input.id);
        if (!existing) throw new Error("Agendamento não encontrado.");
        if (ctx.admin.role !== 'admin' && ctx.admin.professionalId && existing.professionalId !== ctx.admin.professionalId) {
          throw new Error("Acesso restrito aos seus próprios agendamentos.");
        }
        return db.deleteAppointment(input.id);
      }),

    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['confirmado', 'cancelado', 'pendente']),
        professionalId: z.number().int().positive().optional().nullable(),
      }))
      .mutation(async ({ ctx, input }) => {
        const existing = await db.getAppointmentById(input.id);
        if (!existing) throw new Error("Agendamento não encontrado.");
        if (ctx.admin.role !== 'admin' && ctx.admin.professionalId && existing.professionalId !== ctx.admin.professionalId) {
          throw new Error("Acesso restrito aos seus próprios agendamentos.");
        }
        let targetProfessionalId = input.professionalId;
        if (ctx.admin.role !== 'admin') {
          targetProfessionalId = ctx.admin.professionalId;
        }
        if (input.status === "confirmado") {
          const validation = await db.validateAppointmentSlot({
            date: existing.appointmentDate,
            time: existing.appointmentTime,
            serviceId: existing.serviceId ?? undefined,
            ignoreAppointmentId: existing.id,
          });
          if (!validation.ok) throw new Error(validation.reason);
        }
        if (input.professionalId) {
          const assignedProfessionals = existing.serviceId ? await db.getProfessionalsForService(existing.serviceId) : [];
          if (!assignedProfessionals.some((professional) => professional.id === input.professionalId)) {
            throw new Error("Barbeiro não atende este serviço.");
          }
        }
        return db.updateAppointmentStatus(input.id, input.status, targetProfessionalId);
      }),
  }),

  // Relatórios
  reports: router({
    monthly: adminProcedure
      .input(z.object({
        year: z.number(),
        month: z.number().min(1).max(12),
      }))
      .query(async ({ ctx, input }) => {
        const proId = ctx.admin.role === 'admin' ? null : ctx.admin.professionalId;
        return db.getMonthlyReport(input.year, input.month, proId);
      }),

    advancedGlobal: strictAdminProcedure
      .input(z.object({
        year: z.number().optional(),
        month: z.number().min(1).max(12).optional(),
        allTime: z.boolean().optional(),
      }))
      .query(async ({ input }) => {
        const year = input.allTime ? undefined : (input.year ?? new Date().getFullYear());
        const month = input.allTime ? undefined : (input.month ?? (new Date().getMonth() + 1));
        return db.getAdvancedReport({ year, month, professionalId: null });
      }),
  }),

  // Notificações
  notifications: router({
    getPendingNotifications: adminProcedure.query(async () => {
      return db.getAppointmentsForNotification();
    }),

    markAsSent: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return db.markNotificationSent(input.id);
      }),

    sendReminder: adminProcedure
      .input(z.object({
        appointmentId: z.number(),
        clientName: z.string(),
        clientPhone: z.string(),
        serviceName: z.string(),
        appointmentDate: z.string(),
        appointmentTime: z.string(),
      }))
      .mutation(async ({ input }) => {
        // Marca como enviado no banco
        await db.markNotificationSent(input.appointmentId);
        
        // Retorna os dados formatados para exibição
        return {
          success: true,
          message: `Lembrete preparado para ${input.clientName} - ${input.serviceName} em ${input.appointmentDate} às ${input.appointmentTime}`,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;

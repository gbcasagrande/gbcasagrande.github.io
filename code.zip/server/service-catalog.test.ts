import { describe, expect, it } from "vitest";
import {
  DEFAULT_SERVICE_ICON,
  SERVICE_ICON_OPTIONS,
  parseServiceBenefits,
  serializeServiceBenefits,
} from "../shared/serviceCatalog";

describe("service catalog helpers", () => {
  it("normaliza benefícios digitados em linhas ou separados por vírgulas", () => {
    expect(serializeServiceBenefits("Redução de inchaço\n\nMelhora da circulação, Relaxamento"))
      .toBe("Redução de inchaço\nMelhora da circulação\nRelaxamento");
    expect(parseServiceBenefits("Redução de inchaço\nMelhora da circulação"))
      .toEqual(["Redução de inchaço", "Melhora da circulação"]);
  });

  it("usa benefícios de fallback quando o serviço ainda não tem cadastro", () => {
    expect(parseServiceBenefits(null, ["Atendimento personalizado"]))
      .toEqual(["Atendimento personalizado"]);
  });

  it("expõe um ícone padrão e opções não vazias para o editor", () => {
    expect(DEFAULT_SERVICE_ICON).toBe("Sparkles");
    expect(SERVICE_ICON_OPTIONS.length).toBeGreaterThan(5);
    expect(SERVICE_ICON_OPTIONS.every((option) => option.value && option.label)).toBe(true);
  });
});

import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

vi.mock("./db", () => ({
  getAllServicesWithProfessionals: vi.fn(),
}));

import * as db from "./db";

function createMockContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {}, cookies: {} } as unknown as TrpcContext["req"],
    res: { cookie: vi.fn(), clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("serviços com profissionais", () => {
  it("retorna profissionais disponíveis para cada serviço na rota pública", async () => {
    vi.mocked(db.getAllServicesWithProfessionals).mockResolvedValue([
      {
        id: 7,
        name: "Drenagem Linfática",
        professionals: [
          { id: 2, name: "Ketlen Antunes", specialty: "Massoterapia", avatarUrl: "https://example.com/ketlen.webp" },
        ],
      },
    ] as any);

    const caller = appRouter.createCaller(createMockContext());
    const services = await caller.services.listWithProfessionals();

    expect(services[0].professionals).toHaveLength(1);
    expect(services[0].professionals[0].name).toBe("Ketlen Antunes");
  });
});

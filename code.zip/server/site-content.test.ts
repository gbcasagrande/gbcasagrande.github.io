import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
vi.mock("./db", () => {
  const defaults = {
    heroName: "Grazi Batistela",
    heroSubtitle: "Massoterapia Avançada",
    heroDescription: "Desfrute de momentos de relaxamento e bem-estar. Com 7 anos de experiência, oferecemos tratamentos personalizados para promover o equilíbrio físico e mental.",
    aboutTitle: "Sobre a Grazi Batistela",
    aboutParagraph1: "Primeiro parágrafo",
    aboutParagraph2: "Segundo parágrafo",
    aboutHighlightTitle: "Profissional Qualificada",
    aboutHighlightDescription: "Especializada em bem-estar integral",
    aboutImageUrl: "https://example.com/about.webp",
    heroImageUrl: "https://example.com/hero.webp",
    teamImageUrl: "https://example.com/team.webp",
  };
  return {
    getSiteContent: vi.fn().mockResolvedValue(defaults),
    updateSiteContent: vi.fn().mockResolvedValue({
      ...defaults,
      heroName: "Grazi Batistela Studio",
    }),
  };
});

import * as db from "./db";

function createMockContext(cookies: Record<string, string> = {}): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
      cookies,
    } as unknown as TrpcContext["req"],
    res: {
      cookie: vi.fn(),
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("siteContent", () => {
  it("expõe o conteúdo padrão da Home publicamente", async () => {
    const caller = appRouter.createCaller(createMockContext());
    const content = await caller.siteContent.get();

    expect(content.heroName).toBe("Grazi Batistela");
    expect(content.heroSubtitle).toBe("Massoterapia Avançada");
    expect(content.heroDescription).toContain("7 anos de experiência");
    expect(content.aboutImageUrl).toBe("https://example.com/about.webp");
  });

  it("protege a atualização do conteúdo para administradores", async () => {
    const caller = appRouter.createCaller(createMockContext());

    await expect(
      caller.siteContent.update({ heroName: "Nome não autorizado" }),
    ).rejects.toThrow("Não autorizado");
    expect(db.updateSiteContent).not.toHaveBeenCalled();
  });
});

import { describe, expect, it } from "vitest";
import { DEFAULT_TOP_BAR_HEIGHT, TOP_BAR_CONTENT_GAP, getHomeHeaderVisibility, getHomeTopPadding, getLoadedHomeImageUrl, getRequestedBookingServiceId, getRequestedProfessionalId, getRequestedProfessionalOnly, LOCATION_SECTION_LABEL } from "@shared/siteLayout";

describe("Home fixed header layout", () => {
  it("reserva o cabeçalho padrão e um espaço visual antes do hero", () => {
    expect(getHomeTopPadding(DEFAULT_TOP_BAR_HEIGHT)).toBe(DEFAULT_TOP_BAR_HEIGHT + TOP_BAR_CONTENT_GAP);
  });

  it("acomoda a altura real da barra de avisos no mobile", () => {
    expect(getHomeTopPadding(125)).toBe(149);
  });

  it("usa uma altura segura quando a medição ainda não está disponível", () => {
    expect(getHomeTopPadding(0)).toBe(100);
    expect(getHomeTopPadding(Number.NaN)).toBe(100);
  });

  it("não expõe uma imagem padrão antes do conteúdo persistido carregar", () => {
    expect(getLoadedHomeImageUrl(undefined)).toBeNull();
    expect(getLoadedHomeImageUrl("  ")).toBeNull();
    expect(getLoadedHomeImageUrl("https://example.com/massagem.webp")).toBe("https://example.com/massagem.webp");
  });

  it("mantém o título da seção do mapa", () => {
    expect(LOCATION_SECTION_LABEL).toBe("Nossa localização");
  });

  it("extrai apenas IDs de serviço válidos do link de agendamento", () => {
    expect(getRequestedBookingServiceId("?bookingServiceId=12")).toBe(12);
    expect(getRequestedBookingServiceId("?bookingServiceId=0")).toBeNull();
    expect(getRequestedBookingServiceId("?bookingServiceId=abc")).toBeNull();
    expect(getRequestedBookingServiceId("?other=value")).toBeNull();
  });

  it("extrai apenas IDs de profissional válidos do link de perfil", () => {
    expect(getRequestedProfessionalId("?professionalId=12")).toBe(12);
    expect(getRequestedProfessionalId("?professionalId=0")).toBeNull();
    expect(getRequestedProfessionalId("?professionalId=abc")).toBeNull();
  });

  it("identifica links de agendamento exclusivo do perfil", () => {
    expect(getRequestedProfessionalOnly("?professionalId=12&professionalOnly=1")).toBe(true);
    expect(getRequestedProfessionalOnly("?professionalId=12")).toBe(false);
  });

  it("oculta o cabeçalho durante o agendamento e o restaura ao fechar", () => {
    expect(getHomeHeaderVisibility(true)).toBe("hidden");
    expect(getHomeHeaderVisibility(false)).toBe("visible");
  });
});

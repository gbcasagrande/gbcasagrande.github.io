import { describe, expect, it } from "vitest";
import {
  buildAppointmentCancelledMessage,
  buildAppointmentConfirmedMessage,
  buildAppointmentConfirmationMessage,
  buildAppointmentRescheduledMessage,
  buildServiceBookingMessage,
  buildWhatsAppUrl,
  formatCivilDateForWhatsApp,
  formatTimeForWhatsApp,
  normalizeBrazilianPhone,
  resolveProfessionalWhatsAppTarget,
} from "../client/src/lib/whatsapp";

describe("whatsapp helpers", () => {
  it("normaliza telefones brasileiros com DDI", () => {
    expect(normalizeBrazilianPhone("(54) 9139-9264")).toBe("555491399264");
    expect(normalizeBrazilianPhone("(54) 99139-9264")).toBe("5554991399264");
    expect(normalizeBrazilianPhone("5511999999999")).toBe("5511999999999");
    expect(normalizeBrazilianPhone("123")).toBeNull();
  });

  it("resolve o telefone da profissional atribuída ao agendamento", () => {
    expect(resolveProfessionalWhatsAppTarget([
      { id: 7, name: "Alana", phone: "54991973203" },
    ], 7)).toEqual({ professionalName: "Alana", phone: "5554991973203" });
  });

  it("não usa telefone de profissional quando não há atribuição", () => {
    expect(resolveProfessionalWhatsAppTarget([
      { id: 7, name: "Alana", phone: "54991973203" },
    ], null)).toEqual({ professionalName: null, phone: null });
  });

  it("cria URL codificada para agendamento por serviço", () => {
    const url = buildWhatsAppUrl(buildServiceBookingMessage("Drenagem Linfática"));
    expect(url).toContain("https://wa.me/5554991399264?text=");
    expect(decodeURIComponent(url)).toContain("Drenagem Linfática");
  });

  it("inclui serviço, data e horário na mensagem pública de agendamento", () => {
    const url = buildWhatsAppUrl(buildServiceBookingMessage("Avaliação", "2026-08-14", "07:30"));
    const decoded = decodeURIComponent(url);
    expect(url).toContain("https://wa.me/5554991399264?text=");
    expect(decoded).toContain("serviço de Avaliação");
    expect(decoded).toContain("14/08/2026");
    expect(decoded).toContain("07:30");
  });

  it("formata confirmação com nome, serviço, data e horário", () => {
    expect(formatCivilDateForWhatsApp("2026-08-15")).toBe("15/08/2026");
    expect(formatTimeForWhatsApp("14:30:00")).toBe("14:30");
    expect(buildAppointmentConfirmationMessage({
      clientName: "Ana",
      serviceName: "Drenagem Linfática",
      appointmentDate: "2026-08-15",
      appointmentTime: "14:30:00",
    })).toBe("Olá, Ana! Você tem um horário marcado para Drenagem Linfática no dia 15/08/2026, às 14:30. Posso confirmar?");
  });

  it("menciona o profissional definido nas mensagens do cliente", () => {
    const appointment = {
      clientName: "Ana",
      serviceName: "Drenagem Linfática",
      appointmentDate: "2026-08-20",
      appointmentTime: "16:00:00",
      professionalName: "Dra. Marina",
    };

    expect(buildAppointmentConfirmedMessage(appointment)).toContain("com o profissional Dra. Marina");
    expect(buildAppointmentRescheduledMessage(appointment)).toContain("O atendimento será realizado por Dra. Marina");
    expect(buildAppointmentCancelledMessage(appointment)).toContain("com o profissional Dra. Marina");
  });

  it("cria mensagens distintas para confirmar, alterar e cancelar um horário", () => {
    const appointment = {
      clientName: "Ana",
      serviceName: "Massagem Relaxante",
      appointmentDate: "2026-08-20",
      appointmentTime: "16:00:00",
    };

    expect(buildAppointmentConfirmedMessage(appointment)).toContain("foi confirmado");
    expect(buildAppointmentRescheduledMessage(appointment)).toContain("foi alterado");
    expect(buildAppointmentRescheduledMessage(appointment)).toContain("20/08/2026");
    expect(buildAppointmentCancelledMessage(appointment)).toContain("foi cancelado");

    const clientPhone = normalizeBrazilianPhone("(54) 99999-8888")!;
    const confirmationUrl = buildWhatsAppUrl(buildAppointmentConfirmedMessage(appointment), clientPhone);
    const rescheduledUrl = buildWhatsAppUrl(buildAppointmentRescheduledMessage(appointment), clientPhone);
    const cancelledUrl = buildWhatsAppUrl(buildAppointmentCancelledMessage(appointment), clientPhone);

    expect(confirmationUrl).toContain("https://wa.me/5554999998888");
    expect(decodeURIComponent(confirmationUrl)).toContain("foi confirmado");
    expect(decodeURIComponent(rescheduledUrl)).toContain("foi alterado");
    expect(decodeURIComponent(rescheduledUrl)).toContain("16:00");
    expect(decodeURIComponent(cancelledUrl)).toContain("foi cancelado");
  });
});

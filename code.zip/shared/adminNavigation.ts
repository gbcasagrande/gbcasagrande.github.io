import type { LucideIcon } from "lucide-react";
import {
  AlertCircle,
  BarChart3,
  CalendarDays,
  Clock3,
  FileText,
  Gift,
  Home,
  Settings,
  UserRound,
  UsersRound,
} from "lucide-react";

export type AdminTab = "agenda" | "pendentes" | "servicos" | "profissionais" | "usuarios" | "clientes" | "meu-usuario" | "pagina" | "sobre" | "horarios" | "relatorios" | "imagens" | "postagens" | "sorteios";

type AdminNavItem =
  | { type: "link"; label: string; href: string; icon: LucideIcon }
  | { type: "tab"; label: string; tab: AdminTab; icon: LucideIcon };

export const ADMIN_NAV_ITEMS: AdminNavItem[] = [
  { type: "link", label: "Início", href: "/", icon: Home },
  { type: "tab", label: "Agenda", tab: "agenda", icon: CalendarDays },
  { type: "tab", label: "Agendamentos Pendentes", tab: "pendentes", icon: AlertCircle },
  { type: "tab", label: "Serviços", tab: "servicos", icon: Settings },
  { type: "tab", label: "Profissionais", tab: "profissionais", icon: UsersRound },
  { type: "tab", label: "Usuários", tab: "usuarios", icon: UserRound },
  { type: "tab", label: "Clientes", tab: "clientes", icon: UsersRound },
  { type: "tab", label: "Página Inicial", tab: "pagina", icon: FileText },
  { type: "tab", label: "Sobre", tab: "sobre", icon: UserRound },
  { type: "tab", label: "Imagens do Site", tab: "imagens", icon: FileText },
  { type: "tab", label: "Horários", tab: "horarios", icon: Clock3 },
  { type: "tab", label: "Relatórios", tab: "relatorios", icon: BarChart3 },
  { type: "tab", label: "Gestão de Postagens", tab: "postagens", icon: FileText },
  { type: "tab", label: "Sorteios", tab: "sorteios", icon: Gift },
  { type: "tab", label: "Meu Usuário", tab: "meu-usuario", icon: UserRound },
];

export const ADMIN_NAV_LAYOUT_CLASSES = {
  container: "block space-y-1 overflow-y-auto p-2 md:p-4",
  item: "w-full justify-start gap-3",
};

export function getVisibleAdminNavItems(role?: string) {
  const isAdmin = role === "admin";
  return ADMIN_NAV_ITEMS.filter((item) => {
    if (item.type === "link") return true;
    if (isAdmin) return true;
    return item.tab === "agenda" || item.tab === "pendentes" || item.tab === "relatorios" || item.tab === "meu-usuario" || item.tab === "postagens";
  });
}

export function getPendingBadgeLabel(count: number) {
  if (!Number.isFinite(count) || count <= 0) return "0";
  return count > 99 ? "99+" : String(Math.floor(count));
}

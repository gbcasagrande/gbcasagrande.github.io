export type AgendaAppointmentStatus = "confirmado" | "cancelado" | "pendente";

export type AgendaFilterableAppointment = {
  clientName: string;
  clientPhone: string;
  serviceName: string;
  professionalName?: string | null;
  professionalId: number | null;
  status: AgendaAppointmentStatus;
};

export type AgendaFilters = {
  search?: string;
  status?: "all" | AgendaAppointmentStatus;
  professionalId?: "all" | "none" | string;
};

export function filterAgendaAppointments<T extends AgendaFilterableAppointment>(
  appointments: T[],
  filters: AgendaFilters,
): T[] {
  const search = (filters.search ?? "").trim().toLocaleLowerCase();
  const status = filters.status ?? "all";
  const professionalId = filters.professionalId ?? "all";

  return appointments.filter((appointment) => {
    const matchesSearch = !search || [
      appointment.clientName,
      appointment.clientPhone,
      appointment.serviceName,
      appointment.professionalName ?? "",
    ].some((value) => value.toLocaleLowerCase().includes(search));
    const matchesStatus = status === "all" || appointment.status === status;
    const matchesProfessional = professionalId === "all"
      || (professionalId === "none" && appointment.professionalId === null)
      || String(appointment.professionalId) === professionalId;

    return matchesSearch && matchesStatus && matchesProfessional;
  });
}

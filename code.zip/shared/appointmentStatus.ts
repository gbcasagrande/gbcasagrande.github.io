export type AppointmentStatus = "confirmado" | "cancelado" | "pendente";
export type AppointmentSource = "admin" | "public";

const defaultLabels: Record<AppointmentStatus, string> = {
  confirmado: "Confirmado",
  cancelado: "Cancelado",
  pendente: "Pendente",
};

export function getAppointmentStatusLabel(status: AppointmentStatus, source: AppointmentSource = "admin") {
  if (source === "public" && status === "pendente") return "Solicitação pendente";
  return defaultLabels[status];
}

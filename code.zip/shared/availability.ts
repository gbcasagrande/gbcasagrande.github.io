export type AvailabilityStatus = "available" | "occupied" | "blocked" | "past";

export type AvailabilityInterval = {
  startTime: string;
  endTime: string;
};

export type AvailabilityAppointment = {
  appointmentTime: string;
  duration: number;
  status: "confirmado" | "cancelado" | "pendente";
};

export type AvailabilitySlot = {
  time: string;
  endTime: string;
  status: AvailabilityStatus;
  label: string;
};

export function timeToMinutes(value: string): number {
  const [hours, minutes] = value.slice(0, 5).split(":").map(Number);
  return hours * 60 + minutes;
}

export function minutesToTime(value: number): string {
  return `${String(Math.floor(value / 60)).padStart(2, "0")}:${String(value % 60).padStart(2, "0")}`;
}

export function civilDateDayOfWeek(date: string): number {
  const [year, month, day] = date.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay();
}

export function intervalsOverlap(start: number, end: number, otherStart: number, otherEnd: number): boolean {
  return start < otherEnd && end > otherStart;
}

export function buildAvailabilitySlots({
  hours,
  duration,
  appointments,
  blocks,
  targetDate,
  currentDate,
  currentTime,
}: {
  hours: AvailabilityInterval[];
  duration: number;
  appointments: AvailabilityAppointment[];
  blocks: AvailabilityInterval[];
  targetDate?: string; // YYYY-MM-DD
  currentDate?: string; // YYYY-MM-DD
  currentTime?: string; // HH:mm
}): AvailabilitySlot[] {
  const slots: AvailabilitySlot[] = [];
  const isToday = targetDate && currentDate && targetDate === currentDate;
  const currentMinutes = currentTime ? timeToMinutes(currentTime) : -1;

  for (const hour of hours) {
    const start = timeToMinutes(hour.startTime);
    const end = timeToMinutes(hour.endTime);
    for (let cursor = start; cursor + duration <= end; cursor += 30) {
      const slotEnd = cursor + duration;
      const slotTimeMinutes = cursor;

      let status: AvailabilityStatus = "available";
      if (isToday && currentMinutes >= 0 && slotTimeMinutes <= currentMinutes) {
        status = "past";
      } else {
        const blocked = blocks.some((block) => intervalsOverlap(cursor, slotEnd, timeToMinutes(block.startTime), timeToMinutes(block.endTime)));
        const occupied = appointments
          .filter((appointment) => appointment.status !== "cancelado")
          .some((appointment) => intervalsOverlap(cursor, slotEnd, timeToMinutes(appointment.appointmentTime), timeToMinutes(appointment.appointmentTime) + appointment.duration));
        
        if (blocked) status = "blocked";
        else if (occupied) status = "occupied";
        else status = "available";
      }

      slots.push({
        time: minutesToTime(cursor),
        endTime: minutesToTime(slotEnd),
        status,
        label: status === "available" ? "Disponível" : status === "occupied" ? "Ocupado" : status === "past" ? "Horário já passou" : "Indisponível",
      });
    }
  }
  return slots;
}

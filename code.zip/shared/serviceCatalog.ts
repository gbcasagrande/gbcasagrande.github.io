export const SERVICE_ICON_OPTIONS = [
  { value: "Sparkles", label: "Brilho" },
  { value: "Droplets", label: "Gotas" },
  { value: "Heart", label: "Coração" },
  { value: "Activity", label: "Movimento" },
  { value: "Shield", label: "Proteção" },
  { value: "Zap", label: "Energia" },
  { value: "Snowflake", label: "Floco de neve" },
  { value: "Sun", label: "Sol" },
  { value: "Flower2", label: "Flor" },
  { value: "Waves", label: "Ondas" },
  { value: "HandHeart", label: "Cuidado" },
  { value: "Leaf", label: "Folha" },
] as const;

export type ServiceIconName = (typeof SERVICE_ICON_OPTIONS)[number]["value"];

export const DEFAULT_SERVICE_ICON: ServiceIconName = "Sparkles";

export function parseServiceBenefits(value: string | null | undefined, fallback: string[] = ["Atendimento personalizado", "Acabamento preciso"]) {
  const benefits = (value ?? "")
    .split(/\r?\n|,/) 
    .map((benefit) => benefit.trim())
    .filter(Boolean);

  return benefits.length > 0 ? benefits : fallback;
}

export function serializeServiceBenefits(benefits: string) {
  return benefits
    .split(/\r?\n|,/) 
    .map((benefit) => benefit.trim())
    .filter(Boolean)
    .join("\n");
}

export function getServicePromotionalPrice(defaultPrice: string | number, discountPercent = 0) {
  const price = Number(defaultPrice);
  const discount = Math.min(100, Math.max(0, Number(discountPercent) || 0));
  if (!Number.isFinite(price) || discount <= 0) return Number.isFinite(price) ? price : 0;
  return Math.round((price * (1 - discount / 100) + Number.EPSILON) * 100) / 100;
}

export const SITE_CONTENT_DEFAULTS = {
  heroName: "Gb Barbearia",
  heroSubtitle: "Barbearia Premium",
  heroDescription:
    "Um endereço para quem valoriza corte preciso, barba bem desenhada e um ritual de cuidado sem pressa. Na Gb Barbearia, cada horário é pensado para deixar você pronto para a próxima ocasião.",
  aboutTitle: "Sobre a Gb Barbearia",
  aboutParagraph1:
    "Em Marau, a Gb Barbearia combina técnica clássica, ferramentas bem cuidadas e um ambiente de personalidade para transformar o corte em parte do seu estilo.",
  aboutParagraph2:
    "Nossa equipe de barbeiros trabalha com escuta, precisão e acabamento impecável. Você escolhe o serviço, o barbeiro e o horário; a gente cuida de cada detalhe na cadeira.",
  aboutHighlightTitle: "Ofício que se reconhece",
  aboutHighlightDescription: "Cortes, barba e rituais masculinos com técnica, presença e atendimento próximo",
  aboutImageUrl: "/manus-storage/async-images/7nbz0XRv9oSS0QZ78a286j/image-1.webp",
  logoUrl: "/manus-storage/gb-barbearia-logo-transparent_77dbd48f.png",
  heroImageUrl: "/manus-storage/async-images/7nbz0XRv9oSS0QZ78a286j/image-1.webp",
  teamImageUrl: "/manus-storage/async-images/7nbz0XRv9oSS0QZ78a286j/image-1.webp",
  announcementText: "Agenda aberta: reserve seu próximo corte e saia renovado.",
  announcementActive: "1",
  announcementLinkText: "Agendar horário",
  siteVersion: "v0",
} as const;

export type SiteContentKey = keyof typeof SITE_CONTENT_DEFAULTS;
export type SiteContentValues = Record<SiteContentKey, string>;

export const DEFAULT_TOP_BAR_HEIGHT = 76;
export const TOP_BAR_CONTENT_GAP = 24;
export const LOCATION_SECTION_LABEL = "Nossa localização";

/**
 * Returns the minimum top padding needed to keep Home content below the
 * fixed announcement/header stack.
 */
export function getHomeTopPadding(topBarHeight: number): number {
  const safeHeight = Number.isFinite(topBarHeight) && topBarHeight > 0 ? topBarHeight : DEFAULT_TOP_BAR_HEIGHT;
  return Math.ceil(safeHeight) + TOP_BAR_CONTENT_GAP;
}

/**
 * Only exposes the Home image after the persisted site content has loaded.
 * This prevents the default image from flashing before the configured image.
 */
export function getLoadedHomeImageUrl(imageUrl: string | undefined): string | null {
  const normalizedUrl = imageUrl?.trim();
  return normalizedUrl ? normalizedUrl : null;
}

/**
 * Reads a valid service id from a Home booking URL query string.
 * Invalid, missing or non-positive values are ignored.
 */
export function getRequestedBookingServiceId(search: string): number | null {
  const rawValue = new URLSearchParams(search).get("bookingServiceId");
  if (!rawValue || !/^\d+$/.test(rawValue)) return null;
  const serviceId = Number(rawValue);
  return Number.isSafeInteger(serviceId) && serviceId > 0 ? serviceId : null;
}

export function getRequestedProfessionalId(search: string): number | null {
  const rawValue = new URLSearchParams(search).get("professionalId");
  if (!rawValue || !/^\d+$/.test(rawValue)) return null;
  const professionalId = Number(rawValue);
  return Number.isSafeInteger(professionalId) && professionalId > 0 ? professionalId : null;
}

export function getRequestedProfessionalOnly(search: string): boolean {
  return new URLSearchParams(search).get("professionalOnly") === "1";
}

/**
 * Keeps the public fixed header out of the booking dialog while it is open.
 * The hidden state preserves the measured header space and prevents layout jumps.
 */
export function getHomeHeaderVisibility(isBookingOpen: boolean): "visible" | "hidden" {
  return isBookingOpen ? "hidden" : "visible";
}

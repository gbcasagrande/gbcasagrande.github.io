# Grazi Batistela - Massoterapia Avançada - TODO

## Banco de Dados
- [x] Tabela de serviços com valores padrão
- [x] Tabela de agendamentos com status
- [x] Sistema de autenticação administrativa com credenciais fixas

## Página Inicial
- [x] Design elegante e profissional
- [x] Apresentação da Grazi Batistela
- [x] Descrição completa dos serviços (drenagem linfática, massagem relaxante, terapêutica, pré/pós-operatória, tapping, criolipólise, terapia com LED)
- [x] Benefícios de cada serviço
- [x] Integração com Google Maps (Rua Nicandro Oltramari, 309, Marau RS)
- [x] Informações de contato

## Sistema de Autenticação
- [x] Login com credenciais fixas (usuário: grazi, senha: 1889@gByu/1m)
- [x] Proteção da rota /agenda
- [x] Logout funcional

## Painel Administrativo (/agenda)
- [x] Visualização em calendário dos agendamentos
- [x] Formulário de criação de agendamento (serviço, data, horário, nome, telefone, valor)
- [x] Seleção de serviço com sugestões ou digitação livre
- [x] Auto-preenchimento do valor ao selecionar serviço cadastrado
- [x] Edição de agendamentos existentes
- [x] Exclusão de agendamentos
- [x] Sistema de status (confirmado/cancelado)
- [x] Alteração de status a qualquer momento

## Gestão de Serviços
- [x] Cadastro de serviços com valores padrão
- [x] Listagem de serviços cadastrados
- [x] Edição de serviços e valores
- [x] Exclusão de serviços

## Notificações
- [x] Sistema de notificações (estrutura preparada para integração)
- [x] Marcação de lembretes enviados

## Relatórios
- [x] Relatório mensal de faturamento
- [x] Análise de serviços mais procurados
- [x] Análise de receita por período

## Solicitação posterior — sidebar lateral em todos os dispositivos
- [x] Manter o menu administrativo na lateral esquerda também em telas menores
- [x] Posicionar o conteúdo do painel ao lado da sidebar sem barra horizontal no topo
- [x] Manter o item Início acessível dentro da sidebar lateral
- [x] Validar a sidebar em desktop e viewport estreito
- [x] Criar e executar testes da sidebar lateral
- [x] Salvar checkpoint da correção

## Solicitação posterior — drawer lateral estilo mobile
- [x] Criar botão de menu para abrir a navegação lateral em telas menores
- [x] Exibir a navegação como drawer sobreposto com fundo escurecido
- [x] Fechar o drawer ao clicar fora dele
- [x] Fechar o drawer ao selecionar uma aba administrativa ou o link Início
- [x] Manter a sidebar fixa no desktop
- [x] Validar o comportamento no mobile e executar testes
- [x] Salvar checkpoint da atualização

## Solicitação posterior — notificações de agendamento pendente
- [x] Exibir a quantidade de solicitações pendentes no item Agendamentos Pendentes
- [x] Atualizar automaticamente a quantidade após novas solicitações ou confirmações
- [x] Destacar visualmente o contador quando houver solicitações
- [x] Exibir o contador na sidebar desktop e no drawer mobile
- [x] Criar e executar testes para o contador de pendências
- [x] Salvar checkpoint da atualização

## Solicitação posterior — notificações de confirmação, alteração e cancelamento
- [x] Abrir o WhatsApp do cliente após confirmar/agendar um horário
- [x] Exibir mensagem de confirmação com serviço, data e hora
- [x] Perguntar se a administradora deseja notificar o cliente após alterar data ou horário
- [x] Abrir o WhatsApp com mensagem de alteração contendo a nova data e horário
- [x] Perguntar se a administradora deseja notificar o cliente ao cancelar um horário
- [x] Abrir o WhatsApp com mensagem de cancelamento do agendamento
- [x] Criar e executar testes para as mensagens e URLs dos três fluxos
- [x] Salvar checkpoint da atualização

## Solicitação posterior — detalhes dos serviços e imagem Sobre
- [x] Adicionar valor editável aos serviços exibidos na Home
- [x] Adicionar duração editável aos serviços exibidos na Home
- [x] Adicionar benefícios editáveis aos serviços exibidos na Home
- [x] Permitir escolher o ícone de cada serviço
- [x] Exibir valor, duração, benefícios e ícone na Home
- [x] Permitir substituir a imagem da seção Sobre no painel admin
- [x] Persistir e exibir a nova imagem na Home
- [x] Criar ou atualizar testes para serviços e imagem Sobre
- [x] Validar TypeScript e suíte Vitest
- [x] Salvar checkpoint da atualização

## Solicitação posterior — reformulação profissional da Home
- [x] Redefinir a hierarquia visual e a composição do hero da Home
- [x] Refinar cabeçalho, navegação e chamadas para ação
- [x] Reformular a seção Sobre mantendo a imagem editável
- [x] Reformular os cartões de serviços mantendo valor, duração, benefícios, ícones e agendamento
- [x] Refinar seções de benefícios, localização, contato e rodapé
- [x] Preservar todos os links e mensagens do WhatsApp
- [x] Validar agendamento, disponibilidade, responsividade e acessibilidade
- [x] Executar testes Vitest e verificação TypeScript
- [x] Salvar checkpoint da reformulação

## Solicitação posterior — rebrandificação para Clínica Benessere
- [x] Aplicar o logo anexado da Benessere no cabeçalho e rodapé
- [x] Atualizar o nome e a identidade textual da Home para Benessere
- [x] Adicionar chamada “Siga-nos no Instagram” com @benesseremarau
- [x] Adicionar link funcional para o Instagram da clínica
- [x] Manter os fluxos de agendamento e disponibilidade
- [x] Manter todas as mensagens e links de WhatsApp
- [x] Preservar painel administrativo, login e funções existentes
- [x] Validar desktop, mobile, TypeScript e testes Vitest
- [x] Salvar checkpoint da atualização

## Solicitação posterior — clínica multiprofissional com profissionais e WhatsApp
- [x] Criar tabela de profissionais e tabela de associação com serviços
- [x] Adicionar campo de profissional (ou sem preferência) nos agendamentos e solicitações pendentes
- [x] Criar aba no painel admin para cadastrar e gerenciar profissionais e especialidades
- [x] Permitir vincular quais profissionais atendem cada serviço
- [x] Permitir ao cliente escolher um profissional ou deixar "Sem preferência" na Home
- [x] Permitir à administradora definir ou alterar o profissional nas solicitações pendentes e agendamentos
- [x] Incluir o nome do profissional nas mensagens do WhatsApp de confirmação e agendamento
- [x] Atualizar a seção Sobre da Home para apresentar a equipe de profissionais da clínica Benessere
- [x] Executar testes Vitest, verificação TypeScript e salvar checkpoint

## Solicitação posterior — exclusão, foto de profissionais e novos usuários admin
- [x] Permitir excluir profissionais definitivamente (com limpeza de vínculos)
- [x] Permitir enviar foto do profissional por upload direto no painel
- [x] Permitir à administradora criar novos usuários administrativos para gerenciar agendamentos
- [x] Permitir a alteração de senha para os usuários administrativos/profissionais
- [x] Executar testes Vitest e verificação TypeScript
- [x] Salvar checkpoint da atualização

## Solicitação posterior — permissões por perfil, módulo Meu usuário e painel Benessere
- [x] Adicionar campo role (admin ou user) na tabela admins
- [x] Restringir criação, edição e exclusão de usuários apenas a administradores
- [x] Restringir acesso a Profissionais, Serviços, Sobre e Horários apenas a administradores
- [x] Criar o módulo Meu usuário para edição de nome, username, senha e exclusão da própria conta
- [x] Atualizar o título do painel de administração para Benessere
- [x] Executar testes Vitest, verificação TypeScript e salvar checkpoint

## Ajuste de segurança identificado na revisão final
- [x] Impedir a exclusão da última conta com role admin
- [x] Impedir o rebaixamento do último administrador
- [x] Reexecutar testes e salvar checkpoint final após a salvaguarda

## Solicitação posterior — escopo por profissional em agenda, pendências e relatórios
- [x] Filtrar agendamentos e solicitações pendentes no servidor por profissional para contas vinculadas
- [x] Permitir que administradores vejam todos os profissionais e relatórios globais
- [x] Adicionar gráficos e indicadores por profissional no painel de relatórios para administradores
- [x] Ocultar abas gerenciais irrelevantes para usuários vinculados à equipe e exibir relatórios focados
- [x] Atualizar testes Vitest e validar o isolamento por profissional
- [x] Salvar checkpoint da atualização

## Ajustes corretivos de escopo por profissional
- [x] Restringir mutações de agendamentos (`create`, `update`, `delete`, `updateStatus`) para que usuários vinculados só possam gerenciar seus próprios agendamentos
- [x] Adicionar testes unitários Vitest específicos para validação de escopo profissional nas rotas de agendamento e relatórios
- [x] Salvar checkpoint final da clínica multiprofissional com escopo estrito por profissional

## Solicitação posterior — vínculo automático de profissional no novo agendamento
- [x] Atualizar o modal de novo agendamento na Agenda para fixar o profissional do usuário comum e permitir seleção livre apenas para administradores
- [x] Validar e garantir que o backend força o professionalId do usuário vinculado na criação e edição de agendamentos
- [x] Reexecutar testes Vitest e salvar checkpoint publicado

## Solicitação posterior — flexibilidade de expediente para profissional e linguagem feminina
- [x] Atualizar validateAppointmentSlot no servidor para ignorar a restrição de horário de expediente quando a solicitação vier de uma profissional vinculada (role === 'user'), mantendo a checagem de conflitos de horário com outros agendamentos e bloqueios
- [x] Atualizar os textos do painel e do modal de agendamento de "o profissional" para "a profissional" ou "profissional responsável"
- [x] Reexecutar a suíte de testes Vitest e salvar o checkpoint publicado

## Solicitação posterior — fotos das profissionais no agendamento público da página inicial
- [x] Atualizar o modal de agendamento na página inicial (Home.tsx) para exibir a foto da profissional selecionada ou galeria com fotos das profissionais disponíveis
- [x] Garantir fallbacks visuais adequados quando a profissional não tiver foto cadastrada
- [x] Executar suíte Vitest e salvar checkpoint publicado

## Solicitação posterior — motivo opcional no agendamento público
- [x] Adicionar o campo motivo opcional ("Nos conte um pouco por que você escolheu esse serviço") no schema, no formulário público da Home.tsx e nas rotas de request/create/update
- [x] Incluir o motivo opcional na mensagem gerada para o WhatsApp quando preenchido
- [x] Exibir o motivo na aba de Agendamentos Pendentes (e detalhes do agendamento) no painel admin
- [x] Executar suíte Vitest e salvar checkpoint publicado

## Solicitação posterior — relatório administrativo avançado (ranking, todo o tempo vs mês, serviços e faturamento)
- [x] Criar procedimento tRPC estritamente administrativo (advancedGlobal) com métricas globais por profissional, por tipo de serviço, totais e faturamento com suporte a todo o tempo ou mês específico
- [x] Atualizar o componente ReportsTab na Agenda para exibir restritamente para administradores o ranking de profissionais que mais prestaram serviços, seletor de período (todo o tempo vs mês) e tabela/cards detalhados de serviços realizados com quantidade e valor
- [x] Executar suíte Vitest e salvar checkpoint publicado

## Solicitação posterior — opção de exibir valor ou "Agendar uma avaliação" por serviço
- [x] Adicionar coluna showPrice (ou priceDisplayMode: 'price' | 'evaluation') na tabela services no schema Drizzle e migrar o banco
- [x] Atualizar as rotas tRPC de serviços para salvar e retornar essa preferência
- [x] Adicionar opção no formulário de serviços da aba Serviços no painel admin para escolher entre "Exibir valor monetário" e "Exibir 'Agendar uma avaliação'"
- [x] Atualizar os cards de serviços na página inicial (Home.tsx) para respeitar essa escolha (mostrando o preço formatado ou o texto "Agendar uma avaliação")
- [x] Executar suíte Vitest e salvar checkpoint publicado

## Solicitação posterior — vincular serviços à profissional Ketlen Antunes
- [x] Remover os serviços e vínculos antigos da base
- [x] Cadastrar a profissional Ketlen Antunes
- [x] Inserir exatamente os serviços e pacotes dos prints (Drenagem Linfática, Modeladora, Relaxante, Terapêutica, Terapêutica Masculina, Micropigmentação, Pacote Experiência, Pacote Terapêutico, Reiki, Remoção à laser e VOLCHER)
- [x] Vincular todos os serviços à profissional Ketlen Antunes
- [x] Executar suíte Vitest e salvar checkpoint publicado

## Solicitação posterior — cadastrar Tanize Agostineto e vincular serviços dos novos prints
- [x] Cadastrar a profissional Tanize Agostineto caso não exista
- [x] Inserir serviços específicos dos novos prints que ainda não constem na base (como Limpeza de pele e Ventosa terapia) e garantir que os demais serviços comuns estejam cadastrados
- [x] Vincular todos esses serviços à profissional Tanize Agostineto na tabela service_professionals
- [x] Executar testes Vitest e salvar checkpoint publicado

## Solicitação posterior — cadastrar Marlene Ferreira Santos Alves e vincular serviços dos prints
- [x] Cadastrar a profissional Marlene Ferreira Santos Alves caso não exista
- [x] Vincular todos os serviços correspondentes aos prints à profissional Marlene Ferreira Santos Alves na tabela service_professionals
- [x] Executar testes Vitest e salvar checkpoint publicado

## Solicitação posterior — cadastrar Alana Maculan e vincular serviços dos novos prints
- [x] Cadastrar a profissional Alana Maculan caso não exista
- [x] Inserir serviços específicos dos novos prints que ainda não constem na base (Avaliação Estética, Design de sobrancelhas, Design de sobrancelhas com henna, Manicure, Pedicure) e garantir os demais comuns
- [x] Vincular todos esses serviços à profissional Alana Maculan na tabela service_professionals
- [x] Executar testes Vitest e salvar checkpoint publicado

## Solicitação posterior — menu visual selecionável com fotos e "Sem preferência" no agendamento público
- [x] Substituir o seletor padrão no modal de agendamento público (Home.tsx) por um componente visual de cartões com fotos das profissionais e a opção "Sem preferência"
- [x] Garantir que a seleção visual atualize corretamente o estado do agendamento e envie o professionalId adequado
- [x] Executar testes Vitest e salvar checkpoint publicado

## Solicitação posterior — lógica de "Sem preferência" com disponibilidade agregada e escolha aleatória
- [x] Atualizar getAvailabilityForDate no servidor para retornar horários disponíveis quando pelo menos uma profissional do serviço estiver livre
- [x] Atualizar createPublicAppointmentRequest para que, se professionalId for nulo (Sem preferência), o sistema selecione aleatoriamente uma profissional disponível para aquele serviço no horário solicitado
- [x] Executar testes Vitest e salvar checkpoint publicado

## Solicitação posterior — horários de atendimento personalizados por profissional
- [x] Adicionar tabela professional_schedules no schema Drizzle (professionalId, dayOfWeek, startTime, endTime, active)
- [x] Criar procedimentos tRPC para gerenciar os horários por profissional (admin/strictAdmin)
- [x] Atualizar getAvailabilityForDate e validateAppointmentSlot para respeitar o expediente individual da profissional selecionada
- [x] Adicionar aba/seção no painel administrativo para configurar os horários de cada profissional
- [x] Executar suíte Vitest e salvar checkpoint publicado

## Solicitação posterior — indisponibilidade de horários passados
- [x] Bloquear no backend agendamentos em horários anteriores ao momento atual
- [x] Exibir como indisponíveis na seleção pública os horários já passados do dia atual
- [x] Adicionar testes de regressão para horário passado, horário futuro e datas futuras
- [x] Validar TypeScript, suíte Vitest e publicar checkpoint

## Solicitação posterior — profissionais disponíveis por serviço
- [x] Exibir no cartão de cada serviço as profissionais vinculadas, com nome e foto quando disponível
- [x] Criar consulta pública agregada de serviços e profissionais
- [x] Cobrir a associação serviço-profissional com teste Vitest
- [x] Validar TypeScript e suíte Vitest

## Correção — Aba Horários no painel admin
- [x] Corrigir conversão de ID de profissional ("global" vs número) na aba Horários para evitar requisições tRPC inválidas
- [x] Validar testes Vitest e verificação TypeScript sem erros

## Solicitação posterior — tipografia unificada e alternância de tema
- [x] Atualizar a fonte de títulos e seções em todo o site para a elegante Cormorant Garamond
- [x] Habilitar alternância de tema claro/escuro com persistência local
- [x] Adicionar botão de alternância de tema no topo da página inicial (Home)
- [x] Validar testes Vitest e verificação TypeScript sem erros

## Correção — botão de tema no mobile
- [x] Exibir o alternador claro/escuro também no cabeçalho mobile da Home
- [x] Ajustar o espaço do botão WhatsApp para telas estreitas
- [x] Validar testes Vitest e verificação TypeScript sem erros

## Solicitação posterior — remoção de imagem redundante na seção Sobre
- [x] Remover o selo e a segunda imagem redundante "Cuidar é presença" da seção Sobre
- [x] Validar testes Vitest e verificação TypeScript sem erros

## Solicitação posterior — barra de avisos editável no topo
- [x] Adicionar campos de texto e visibilidade do aviso em SITE_CONTENT_DEFAULTS e no router Zod
- [x] Permitir a edição do aviso na aba de configurações da Home no painel administrativo
- [x] Exibir a barra de avisos responsiva no topo da página inicial (Home)
- [x] Validar testes Vitest e verificação TypeScript sem erros

## Solicitação posterior — botão no aviso, remoção de imagem Sobre e tema escuro global
- [x] Adicionar botão de agendamento rápido clicável e texto de link no Zod schema, banco e painel admin
- [x] Destacar a barra de avisos com gradiente e botão interativo no topo da Home
- [x] Validar testes Vitest e verificação TypeScript sem erros

## Solicitação posterior — logo editável e cabeçalho fixo
- [x] Adicionar configuração e upload da logo no painel administrativo
- [x] Exibir a logo configurada no cabeçalho público
- [x] Manter a logo e o botão do WhatsApp fixos no topo em desktop e mobile
- [x] Validar testes Vitest, TypeScript e publicação

## Solicitação posterior — logo editável, barra fixa com WhatsApp e modo escuro global
- [x] Adicionar upload e edição de logo no painel administrativo (Gerenciador de Imagens)
- [x] Manter a logo e o botão do WhatsApp fixos e acessíveis no cabeçalho superior (desktop e mobile)
- [x] Remover a imagem redundante da seção Sobre a clínica
- [x] Estender o modo escuro para funcionar em todo o site e no painel administrativo
- [x] Validar suíte Vitest (52 testes) e verificação TypeScript sem erros

## Solicitação posterior — cabeçalho realmente fixo durante a rolagem
- [x] Ajustar o cabeçalho da Home para permanecer preso ao topo durante a rolagem em mobile e desktop
- [x] Garantir que a barra de avisos e o cabeçalho não se sobreponham nem desloquem o conteúdo
- [x] Validar responsividade, testes Vitest, TypeScript e publicar checkpoint

## Solicitação posterior — remover imagem intermediária no carregamento
- [x] Identificar a imagem que aparece antes da imagem principal de massagem
- [x] Remover o carregamento intermediário sem quebrar o layout da Home
- [x] Validar responsividade, testes Vitest, TypeScript e publicar checkpoint

## Solicitação posterior — título da localização acima do mapa
- [x] Adicionar o título “Nossa localização” imediatamente acima do mapa na Home
- [x] Validar o alinhamento visual, testes Vitest, TypeScript e publicar checkpoint

## Solicitação posterior — remover foto da profissional
- [x] Adicionar ação administrativa para remover a foto definida de uma profissional
- [x] Preservar o cadastro, vínculos com serviços e fallback visual após a remoção
- [x] Validar permissões, testes Vitest, TypeScript e publicar checkpoint

## Solicitação posterior — módulo de postagens e artigos da clínica
- [x] Criar tabela de postagens (posts) e postagens relacionadas a serviços (post_services) no banco
- [x] Implementar procedimentos tRPC para criar, editar, listar e remover postagens (estrito para administradores e profissionais)
- [x] Criar aba de Gestão de Postagens no painel administrativo com upload de capa e seleção de serviços vinculados
- [x] Criar seção pública de postagens na Home e página de leitura detalhada com autoria
- [x] Adicionar botões de compartilhamento (Facebook, WhatsApp, Instagram e Copiar link)
- [x] Exibir serviços vinculados à postagem com opção de agendamento rápido
- [x] Adicionar contador/botão de reações nas postagens
- [x] Criar testes Vitest, validar TypeScript e publicar checkpoint

## Solicitação posterior — agendamento direto a partir de serviço da postagem
- [x] Fazer o botão do serviço relacionado abrir o diálogo de agendamento automaticamente
- [x] Pré-selecionar o serviço e levar a cliente diretamente à escolha de profissional e horário
- [x] Validar o fluxo, testes Vitest, TypeScript e publicar checkpoint

## Solicitação posterior — rótulo público unificado dos artigos
- [x] Substituir “Destaque na Home” e “Fixado no topo” por “Em destaque” nas áreas públicas
- [x] Manter os controles administrativos de destaque e fixação sem alterar suas regras
- [x] Validar Home, artigos, detalhe, testes Vitest, TypeScript e publicar checkpoint

## Solicitação posterior — erro ao abrir artigo pela página inicial
- [x] Reproduzir o erro ao clicar nos cards ou botões de artigos na Home
- [x] Corrigir a rota/link sem quebrar a página de detalhe, reações ou serviços relacionados
- [x] Validar o fluxo, testes Vitest, TypeScript e publicar checkpoint

## Solicitação posterior — ocultar cabeçalho durante a escolha de horário
- [x] Ocultar o cabeçalho da Home quando a janela “Escolha seu horário” estiver aberta
- [x] Restaurar o cabeçalho ao fechar a janela de agendamento
- [x] Validar desktop, mobile, testes Vitest, TypeScript e publicar checkpoint

## Solicitação posterior — suporte a quebras de linha e negrito ao colar texto nas postagens
- [x] Permitir colar texto com formatação (quebras de linha e negrito) no editor administrativo
- [x] Renderizar a formatação com segurança na página pública do artigo (`PostDetail.tsx`)
- [x] Validar testes Vitest, TypeScript e publicar checkpoint
